-- ============================================================
-- Migration 034: member admin tools (deactivate instead of delete, suspend login, temporary passwords)
-- ------------------------------------------------------------
-- Run AFTER 033_protect_profiles.sql. Then run 034_verify.sql (changes nothing, ends in ROLLBACK).
--
-- WHY
--  * Deleting a member failed for anyone with history (transactions, notifications, approvals... reference profiles
--    with no ON DELETE rule) and, even when it worked, their LOGIN kept working. Members are now DEACTIVATED:
--    their financial history stays, their login is blocked, and they stop receiving group notifications.
--  * process_withdrawal_approval() completes a withdrawal only when EVERY approval row is approved, so a departed
--    member's pending vote blocked withdrawals forever. Deactivation now removes their PENDING votes on PENDING
--    withdrawals (recorded in the audit log) and re-checks each affected withdrawal.
--
-- WHAT THIS DOES
--  1. profiles gets: is_active, login_disabled, must_change_password, deactivated_at, deactivated_by,
--     deactivation_reason. Rules: an admin is always active and can sign in (demote first); an inactive member
--     always has login_disabled = true.
--  2. protect_profiles_update() (from 033) is replaced. New rules for browser (signed-in) updates:
--       - nobody, admins included, can change role, email or the account fields above from the browser.
--         Those changes go through the admin-manage-member server function, which checks the admin's password,
--         keeps the login (auth) in step with the profile, writes the audit log and notifies the member.
--       - everything from 033 still applies (members edit only their own profile, equity recalculation allowed).
--     The last-admin guard now applies to EVERY update, including the server function and the SQL editor.
--  3. Profiles can no longer be deleted from the browser (the "Admin can delete profiles" policy is dropped).
--  4. When a member changes their password (including through a reset link), must_change_password is cleared
--     by a trigger on auth.users. It is only cleared by a REAL password change, never by the browser.
--  5. New withdrawal approval rows for inactive members are silently skipped (protects older cached app versions),
--     and notifications to inactive members are skipped (except the account notice telling them about it).
--  6. Server-only functions (service role): admin_deactivate_member, admin_reactivate_member,
--     admin_set_login_disabled, admin_member_summary. Nobody signed in to the app can call them.
--
-- ROLLBACK (only if needed; keeps the new columns, which are harmless):
--   re-run 033_protect_profiles.sql (restores its trigger function)
--   DROP TRIGGER IF EXISTS trg_clear_must_change_password ON auth.users;
--   DROP TRIGGER IF EXISTS trg_skip_inactive_approver ON withdrawal_approvals;
--   DROP TRIGGER IF EXISTS trg_skip_inactive_notification ON notifications;
-- ============================================================

-- ── 1. new columns ──────────────────────────────────────────
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_active            BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS login_disabled       BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS deactivated_at       TIMESTAMPTZ;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS deactivated_by       UUID REFERENCES profiles(id) ON DELETE SET NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS deactivation_reason  TEXT;

ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_admin_is_active;
ALTER TABLE profiles ADD  CONSTRAINT profiles_admin_is_active
  CHECK (role <> 'admin' OR (is_active AND NOT login_disabled));
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_inactive_cannot_sign_in;
ALTER TABLE profiles ADD  CONSTRAINT profiles_inactive_cannot_sign_in
  CHECK (is_active OR login_disabled);

CREATE INDEX IF NOT EXISTS idx_profiles_is_active ON profiles (is_active);

-- ── 2. guard profile updates (replaces the 033 version) ─────
CREATE OR REPLACE FUNCTION protect_profiles_update()
RETURNS TRIGGER AS $$
DECLARE
  v_uid          UUID := auth.uid();
  v_is_admin     BOOLEAN := FALSE;
  v_other_admins INT;
BEGIN
  IF NEW.id IS DISTINCT FROM OLD.id THEN
    RAISE EXCEPTION 'A profile id cannot be changed' USING ERRCODE = '42501';
  END IF;

  -- applies everywhere, including the server function and the SQL editor
  IF OLD.role = 'admin' AND NEW.role IS DISTINCT FROM 'admin' THEN
    SELECT COUNT(*) INTO v_other_admins FROM profiles WHERE role = 'admin' AND id <> OLD.id;
    IF v_other_admins = 0 THEN
      RAISE EXCEPTION 'You cannot remove the last admin' USING ERRCODE = '42501';
    END IF;
  END IF;

  IF v_uid IS NULL THEN RETURN NEW; END IF;                       -- trusted: SQL editor / service role

  -- A real password change clears must_change_password (trigger on auth.users, step 4). If that ever runs with a
  -- signed-in user's id, allow exactly that one change and nothing else.
  IF current_setting('nitalink.password_changed_for', true) = OLD.id::text
     AND OLD.must_change_password AND NOT NEW.must_change_password
     AND (to_jsonb(NEW) - 'must_change_password' - 'updated_at') = (to_jsonb(OLD) - 'must_change_password' - 'updated_at') THEN
    RETURN NEW;
  END IF;

  -- account fields: server function only, for everyone
  IF NEW.role IS DISTINCT FROM OLD.role THEN
    RAISE EXCEPTION 'Roles are changed from Admin Panel > Manage members' USING ERRCODE = '42501';
  END IF;
  IF NEW.email IS DISTINCT FROM OLD.email THEN
    RAISE EXCEPTION 'Email addresses are changed from Admin Panel > Manage members' USING ERRCODE = '42501';
  END IF;
  IF NEW.is_active            IS DISTINCT FROM OLD.is_active
  OR NEW.login_disabled       IS DISTINCT FROM OLD.login_disabled
  OR NEW.must_change_password IS DISTINCT FROM OLD.must_change_password
  OR NEW.deactivated_at       IS DISTINCT FROM OLD.deactivated_at
  OR NEW.deactivated_by       IS DISTINCT FROM OLD.deactivated_by
  OR NEW.deactivation_reason  IS DISTINCT FROM OLD.deactivation_reason THEN
    RAISE EXCEPTION 'Account status is changed from Admin Panel > Manage members' USING ERRCODE = '42501';
  END IF;

  SELECT (role = 'admin') INTO v_is_admin FROM profiles WHERE id = v_uid;
  IF COALESCE(v_is_admin, FALSE) THEN RETURN NEW; END IF;

  -- the caller is an ordinary member from here on (same rule as 033)
  IF OLD.id <> v_uid THEN
    IF (to_jsonb(NEW) - 'equity_status' - 'loan_balance' - 'updated_at')
       IS DISTINCT FROM (to_jsonb(OLD) - 'equity_status' - 'loan_balance' - 'updated_at') THEN
      RAISE EXCEPTION 'You can only edit your own profile' USING ERRCODE = '42501';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;
-- (trigger trg_protect_profiles from 033 already points at this function)

-- ── 3. no deleting profiles from the browser ────────────────
DROP POLICY IF EXISTS "Admin can delete profiles" ON profiles;

-- ── 4. a real password change clears must_change_password ───
CREATE OR REPLACE FUNCTION clear_must_change_password()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.encrypted_password IS DISTINCT FROM OLD.encrypted_password THEN
    BEGIN
      PERFORM set_config('nitalink.password_changed_for', NEW.id::text, true);
      UPDATE public.profiles SET must_change_password = FALSE
       WHERE id = NEW.id AND must_change_password;
      PERFORM set_config('nitalink.password_changed_for', '', true);
    EXCEPTION WHEN OTHERS THEN
      -- never let this break a password change or a sign-in
      RAISE WARNING 'clear_must_change_password: %', SQLERRM;
    END;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_clear_must_change_password ON auth.users;
CREATE TRIGGER trg_clear_must_change_password
  AFTER UPDATE OF encrypted_password ON auth.users
  FOR EACH ROW EXECUTE FUNCTION clear_must_change_password();

-- ── 5a. never create a withdrawal vote for an inactive member ──
CREATE OR REPLACE FUNCTION skip_inactive_approver()
RETURNS TRIGGER AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM profiles WHERE id = NEW.approver_id AND NOT is_active) THEN
    RETURN NULL;   -- silently skipped: older app versions still send every member
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_skip_inactive_approver ON withdrawal_approvals;
CREATE TRIGGER trg_skip_inactive_approver
  BEFORE INSERT ON withdrawal_approvals
  FOR EACH ROW EXECUTE FUNCTION skip_inactive_approver();

-- ── 5b. inactive members stop receiving group notifications (and their emails) ──
CREATE OR REPLACE FUNCTION skip_inactive_notification()
RETURNS TRIGGER AS $$
BEGIN
  IF COALESCE(NEW.metadata->>'account_notice', '') = 'true' THEN RETURN NEW; END IF;
  IF EXISTS (SELECT 1 FROM profiles WHERE id = NEW.user_id AND NOT is_active) THEN
    RETURN NULL;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_skip_inactive_notification ON notifications;
CREATE TRIGGER trg_skip_inactive_notification
  BEFORE INSERT ON notifications
  FOR EACH ROW EXECUTE FUNCTION skip_inactive_notification();

-- ── 6. server-only functions ────────────────────────────────

-- What the admin should know before acting (pending votes, own pending withdrawals).
CREATE OR REPLACE FUNCTION admin_member_summary(p_member UUID)
RETURNS JSONB AS $$
  SELECT jsonb_build_object(
    'pending_votes', (SELECT COUNT(*) FROM withdrawal_approvals wa JOIN transactions t ON t.id = wa.transaction_id
                       WHERE wa.approver_id = p_member AND wa.status = 'pending' AND t.status = 'pending' AND t.type = 'withdrawal'),
    'own_pending_withdrawals', (SELECT COUNT(*) FROM transactions WHERE user_id = p_member AND type = 'withdrawal' AND status = 'pending'),
    'available_equity', (SELECT available_equity FROM member_equity_summary WHERE id = p_member)
  );
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public;

CREATE OR REPLACE FUNCTION admin_deactivate_member(p_member UUID, p_admin UUID, p_reason TEXT DEFAULT NULL)
RETURNS JSONB AS $$
DECLARE
  v_p         profiles%ROWTYPE;
  v_removed   JSONB;
  v_tx        UUID;
  v_res       JSONB;
  v_affected  INT := 0;
  v_completed INT := 0;
  v_rejected  INT := 0;
  v_stuck     UUID[] := '{}';
BEGIN
  SELECT * INTO v_p FROM profiles WHERE id = p_member FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('error', 'Member not found'); END IF;
  IF v_p.role = 'admin' THEN RETURN jsonb_build_object('error', 'Change this admin to a member before deactivating'); END IF;
  IF NOT v_p.is_active THEN RETURN jsonb_build_object('error', 'This member is already deactivated'); END IF;

  -- tell them first (the notification filter lets account notices through either way)
  INSERT INTO notifications (user_id, title, message, type, metadata)
  VALUES (p_member, 'Your Nitalink account was deactivated',
          'An admin deactivated your Nitalink account, so you can no longer sign in. Your contribution history is kept. '
          || 'If you think this is a mistake, contact a group admin.',
          'warning', jsonb_build_object('account_notice', true));

  UPDATE profiles
     SET is_active = FALSE, login_disabled = TRUE, must_change_password = FALSE,
         deactivated_at = NOW(), deactivated_by = p_admin,
         deactivation_reason = NULLIF(LEFT(TRIM(COALESCE(p_reason, '')), 500), ''),
         updated_at = NOW()
   WHERE id = p_member;

  -- their PENDING votes on PENDING withdrawals would block those withdrawals forever
  WITH del AS (
    DELETE FROM withdrawal_approvals wa
     USING transactions t
     WHERE wa.transaction_id = t.id AND t.type = 'withdrawal' AND t.status = 'pending'
       AND wa.approver_id = p_member AND wa.status = 'pending'
    RETURNING wa.id, wa.transaction_id, wa.created_at
  )
  SELECT COALESCE(jsonb_agg(to_jsonb(del)), '[]'::jsonb) INTO v_removed FROM del;

  FOR v_tx IN SELECT DISTINCT (x->>'transaction_id')::uuid FROM jsonb_array_elements(v_removed) x LOOP
    v_affected := v_affected + 1;
    IF NOT EXISTS (SELECT 1 FROM withdrawal_approvals WHERE transaction_id = v_tx) THEN
      v_stuck := v_stuck || v_tx;          -- nobody left to vote: an admin must decide
      CONTINUE;
    END IF;
    v_res := process_withdrawal_approval(v_tx);
    IF v_res->>'status' = 'completed' THEN v_completed := v_completed + 1;
    ELSIF v_res->>'status' = 'rejected' THEN v_rejected := v_rejected + 1;
    END IF;
  END LOOP;

  INSERT INTO audit_logs (user_id, action, table_name, record_id, change_type, old_values, new_values)
  VALUES (p_admin, 'Admin deactivated member: ' || v_p.name, 'profiles', p_member, 'update',
          jsonb_build_object('is_active', true, 'removed_pending_votes', v_removed),
          jsonb_build_object('is_active', false, 'reason', NULLIF(LEFT(TRIM(COALESCE(p_reason, '')), 500), ''),
                             'withdrawals_rechecked', v_affected, 'withdrawals_completed', v_completed,
                             'withdrawals_rejected', v_rejected, 'withdrawals_needing_decision', to_jsonb(v_stuck)));

  RETURN jsonb_build_object('ok', true, 'removed_votes', jsonb_array_length(v_removed),
                            'withdrawals_rechecked', v_affected, 'withdrawals_completed', v_completed,
                            'withdrawals_rejected', v_rejected, 'withdrawals_needing_decision', to_jsonb(v_stuck));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE OR REPLACE FUNCTION admin_reactivate_member(p_member UUID, p_admin UUID)
RETURNS JSONB AS $$
DECLARE v_p profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_p FROM profiles WHERE id = p_member FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('error', 'Member not found'); END IF;
  IF v_p.is_active THEN RETURN jsonb_build_object('error', 'This member is already active'); END IF;

  UPDATE profiles
     SET is_active = TRUE, login_disabled = FALSE,
         deactivated_at = NULL, deactivated_by = NULL, deactivation_reason = NULL, updated_at = NOW()
   WHERE id = p_member;

  INSERT INTO notifications (user_id, title, message, type, metadata)
  VALUES (p_member, 'Your Nitalink account is active again',
          'An admin reactivated your Nitalink account. You can sign in again.',
          'success', jsonb_build_object('account_notice', true));

  INSERT INTO audit_logs (user_id, action, table_name, record_id, change_type, old_values, new_values)
  VALUES (p_admin, 'Admin reactivated member: ' || v_p.name, 'profiles', p_member, 'update',
          jsonb_build_object('is_active', false, 'deactivated_at', v_p.deactivated_at, 'reason', v_p.deactivation_reason),
          jsonb_build_object('is_active', true));
  RETURN jsonb_build_object('ok', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Suspend / restore sign-in only. The member stays a member (still votes, still notified).
CREATE OR REPLACE FUNCTION admin_set_login_disabled(p_member UUID, p_admin UUID, p_disabled BOOLEAN, p_reason TEXT DEFAULT NULL)
RETURNS JSONB AS $$
DECLARE v_p profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_p FROM profiles WHERE id = p_member FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('error', 'Member not found'); END IF;
  IF NOT v_p.is_active THEN RETURN jsonb_build_object('error', 'This member is deactivated. Reactivate them instead.'); END IF;
  IF p_disabled AND v_p.role = 'admin' THEN RETURN jsonb_build_object('error', 'Change this admin to a member before suspending'); END IF;
  IF v_p.login_disabled = p_disabled THEN
    RETURN jsonb_build_object('error', CASE WHEN p_disabled THEN 'Sign-in is already suspended' ELSE 'Sign-in is not suspended' END);
  END IF;

  UPDATE profiles SET login_disabled = p_disabled, updated_at = NOW() WHERE id = p_member;

  INSERT INTO notifications (user_id, title, message, type, metadata)
  VALUES (p_member,
          CASE WHEN p_disabled THEN 'Sign-in to your Nitalink account was suspended' ELSE 'You can sign in to Nitalink again' END,
          CASE WHEN p_disabled
               THEN 'An admin suspended sign-in to your Nitalink account. You are still a member. Contact a group admin for details.'
               ELSE 'An admin restored sign-in to your Nitalink account.' END,
          CASE WHEN p_disabled THEN 'warning' ELSE 'success' END,
          jsonb_build_object('account_notice', true));

  INSERT INTO audit_logs (user_id, action, table_name, record_id, change_type, old_values, new_values)
  VALUES (p_admin,
          CASE WHEN p_disabled THEN 'Admin suspended sign-in: ' ELSE 'Admin restored sign-in: ' END || v_p.name,
          'profiles', p_member, 'update',
          jsonb_build_object('login_disabled', v_p.login_disabled),
          jsonb_build_object('login_disabled', p_disabled, 'reason', NULLIF(LEFT(TRIM(COALESCE(p_reason, '')), 500), '')));
  RETURN jsonb_build_object('ok', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Server only. SECURITY DEFINER functions are callable by everyone unless revoked.
REVOKE ALL ON FUNCTION admin_member_summary(UUID)                           FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION admin_deactivate_member(UUID, UUID, TEXT)            FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION admin_reactivate_member(UUID, UUID)                  FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION admin_set_login_disabled(UUID, UUID, BOOLEAN, TEXT)  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION admin_member_summary(UUID)                          TO service_role;
GRANT EXECUTE ON FUNCTION admin_deactivate_member(UUID, UUID, TEXT)           TO service_role;
GRANT EXECUTE ON FUNCTION admin_reactivate_member(UUID, UUID)                 TO service_role;
GRANT EXECUTE ON FUNCTION admin_set_login_disabled(UUID, UUID, BOOLEAN, TEXT) TO service_role;
