-- ============================================================
-- Migration 033: close the privilege-escalation holes on profiles
-- ------------------------------------------------------------
-- BEFORE this migration:
--  (a) handle_new_user() copied the role from sign-up metadata, which the BROWSER supplies. Anyone on the internet
--      could call the public sign-up API with {"role":"admin"} and receive an admin account.
--  (b) The UPDATE policy "Authenticated can update profiles" is USING(true) WITH CHECK(true), so any logged-in
--      member could change any profile row, including setting their own role to 'admin'.
--  (c) The INSERT policy "Allow profile creation" was WITH CHECK(true).
--  (d) Nothing stopped the last admin from being demoted or deleted.
--
-- WHAT THIS DOES (no existing feature changes):
--  1. handle_new_user(): the role is ALWAYS 'member'. Admins are made by an existing admin (or the service role).
--  2. A BEFORE UPDATE trigger: only admins can change role/email or edit other members' rows. The only thing a
--     non-admin may change on another member's row is the cached equity_status / loan_balance, because
--     recalculate_equity_status() does that when deposits happen. Members can still edit their own profile.
--  3. The INSERT policy now only allows a user to insert their OWN row as a plain member.
--  4. The last admin cannot be demoted or deleted.
-- Trusted contexts (SQL editor, migrations, service-role Edge Functions) have no end-user JWT (auth.uid() is NULL)
-- and are not restricted.
--
-- ROLLBACK:
--   DROP TRIGGER IF EXISTS trg_protect_profiles ON profiles;
--   DROP TRIGGER IF EXISTS trg_protect_last_admin_delete ON profiles;
--   DROP FUNCTION IF EXISTS protect_profiles_update();
--   DROP FUNCTION IF EXISTS protect_last_admin_delete();
--   (the old handle_new_user() body is in 001_initial_schema.sql)
-- ============================================================

-- 1. never trust a role supplied at sign-up
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, name, email, role)
  VALUES (
    NEW.id,
    LEFT(COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data->>'name'), ''), split_part(NEW.email, '@', 1)), 80),
    NEW.email,
    'member'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 2. guard profile updates
CREATE OR REPLACE FUNCTION protect_profiles_update()
RETURNS TRIGGER AS $$
DECLARE
  v_uid          UUID := auth.uid();
  v_is_admin     BOOLEAN := FALSE;
  v_other_admins INT;
BEGIN
  IF v_uid IS NULL THEN RETURN NEW; END IF;                       -- trusted: SQL editor / service role

  SELECT (role = 'admin') INTO v_is_admin FROM profiles WHERE id = v_uid;
  v_is_admin := COALESCE(v_is_admin, FALSE);

  IF NEW.id IS DISTINCT FROM OLD.id THEN
    RAISE EXCEPTION 'A profile id cannot be changed' USING ERRCODE = '42501';
  END IF;

  IF OLD.role = 'admin' AND NEW.role IS DISTINCT FROM 'admin' THEN  -- applies to admins too
    SELECT COUNT(*) INTO v_other_admins FROM profiles WHERE role = 'admin' AND id <> OLD.id;
    IF v_other_admins = 0 THEN
      RAISE EXCEPTION 'You cannot remove the last admin' USING ERRCODE = '42501';
    END IF;
  END IF;

  IF v_is_admin THEN RETURN NEW; END IF;

  -- the caller is an ordinary member from here on
  IF NEW.role IS DISTINCT FROM OLD.role THEN
    RAISE EXCEPTION 'Only an admin can change a role' USING ERRCODE = '42501';
  END IF;
  IF NEW.email IS DISTINCT FROM OLD.email THEN
    RAISE EXCEPTION 'Only an admin can change an email address' USING ERRCODE = '42501';
  END IF;
  IF OLD.id <> v_uid THEN
    IF (to_jsonb(NEW) - 'equity_status' - 'loan_balance' - 'updated_at')
       IS DISTINCT FROM (to_jsonb(OLD) - 'equity_status' - 'loan_balance' - 'updated_at') THEN
      RAISE EXCEPTION 'You can only edit your own profile' USING ERRCODE = '42501';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_protect_profiles ON profiles;
CREATE TRIGGER trg_protect_profiles
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION protect_profiles_update();

-- 3. the last admin cannot be deleted
CREATE OR REPLACE FUNCTION protect_last_admin_delete()
RETURNS TRIGGER AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND OLD.role = 'admin'
     AND NOT EXISTS (SELECT 1 FROM profiles WHERE role = 'admin' AND id <> OLD.id) THEN
    RAISE EXCEPTION 'You cannot delete the last admin' USING ERRCODE = '42501';
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_protect_last_admin_delete ON profiles;
CREATE TRIGGER trg_protect_last_admin_delete
  BEFORE DELETE ON profiles
  FOR EACH ROW EXECUTE FUNCTION protect_last_admin_delete();

-- 4. tighten the INSERT policy (new profiles are created by the handle_new_user trigger, not by the browser)
DROP POLICY IF EXISTS "Allow profile creation" ON profiles;
CREATE POLICY "Allow profile creation" ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid() AND role = 'member');
