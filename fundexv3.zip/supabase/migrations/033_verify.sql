-- Run this in the Supabase SQL editor AFTER 033_protect_profiles.sql. It changes NOTHING (it ends in ROLLBACK).
-- Each test prints a PASS notice. If one prints "TEST FAILED" the protection is not working: stop and tell me.
-- Needs at least one admin and one non-admin member to exist.
BEGIN;

DO $$ DECLARE m UUID; BEGIN
  SELECT id INTO m FROM profiles WHERE role = 'member' ORDER BY created_at LIMIT 1;
  IF m IS NULL THEN RAISE NOTICE 'SKIP: no member found'; RETURN; END IF;
  PERFORM set_config('request.jwt.claim.sub', m::text, true);
  SET LOCAL ROLE authenticated;
  BEGIN
    UPDATE profiles SET role = 'admin' WHERE id = m;
    RAISE EXCEPTION 'TEST FAILED 1: a member made themselves admin';
  EXCEPTION WHEN insufficient_privilege THEN RAISE NOTICE 'PASS 1: a member cannot promote themselves to admin';
  END;
  BEGIN
    UPDATE profiles SET email = 'hijack@example.com' WHERE id = m;
    RAISE EXCEPTION 'TEST FAILED 2: a member changed their own email';
  EXCEPTION WHEN insufficient_privilege THEN RAISE NOTICE 'PASS 2: a member cannot change their email';
  END;
  UPDATE profiles SET phone = phone WHERE id = m;
  RAISE NOTICE 'PASS 3: a member can still update their own profile';
  RESET ROLE;
END $$;

DO $$ DECLARE m UUID; o UUID; BEGIN
  SELECT id INTO m FROM profiles WHERE role = 'member' ORDER BY created_at LIMIT 1;
  SELECT id INTO o FROM profiles WHERE id <> m ORDER BY created_at LIMIT 1;
  IF m IS NULL OR o IS NULL THEN RAISE NOTICE 'SKIP: need two profiles'; RETURN; END IF;
  PERFORM set_config('request.jwt.claim.sub', m::text, true);
  SET LOCAL ROLE authenticated;
  BEGIN
    UPDATE profiles SET name = 'Hacked' WHERE id = o;
    RAISE EXCEPTION 'TEST FAILED 4: a member edited someone else''s profile';
  EXCEPTION WHEN insufficient_privilege THEN RAISE NOTICE 'PASS 4: a member cannot edit another member''s profile';
  END;
  UPDATE profiles SET equity_status = equity_status, loan_balance = loan_balance WHERE id = o;
  RAISE NOTICE 'PASS 5: system equity recalculation on another member''s row is still allowed';
  RESET ROLE;
END $$;

DO $$ DECLARE a UUID; n INT; BEGIN
  SELECT COUNT(*) INTO n FROM profiles WHERE role = 'admin';
  SELECT id INTO a FROM profiles WHERE role = 'admin' LIMIT 1;
  IF n <> 1 THEN RAISE NOTICE 'SKIP 6: last-admin test needs exactly one admin (you have %)', n; RETURN; END IF;
  PERFORM set_config('request.jwt.claim.sub', a::text, true);
  SET LOCAL ROLE authenticated;
  BEGIN
    UPDATE profiles SET role = 'member' WHERE id = a;
    RAISE EXCEPTION 'TEST FAILED 6: the last admin was demoted';
  EXCEPTION WHEN insufficient_privilege THEN RAISE NOTICE 'PASS 6: the last admin cannot be demoted';
  END;
  RESET ROLE;
END $$;

ROLLBACK;
