-- READ-ONLY. Run these in the Supabase SQL editor to see whether the old holes were already used.
-- 1. Everyone who is an admin right now. Do you recognise every one of them?
select id, email, name, role, created_at from profiles where role = 'admin' order by created_at;

-- 2. Accounts whose sign-up asked for a role (the attack, or your own admin-created accounts)
select id, email, created_at, last_sign_in_at, raw_user_meta_data->>'role' as requested_role
from auth.users where raw_user_meta_data ? 'role' order by created_at desc;

-- 3. The 50 newest accounts. Any you do not recognise?
select id, email, created_at, last_sign_in_at, email_confirmed_at from auth.users order by created_at desc limit 50;

-- 4. Accounts with no profile, or profiles with no login
select u.id, u.email, 'login without profile' as problem from auth.users u left join profiles p on p.id = u.id where p.id is null
union all
select p.id, p.email, 'profile without login' from profiles p left join auth.users u on u.id = p.id where u.id is null;

-- 5. Recent actions by admins (look for admins or actions you do not recognise)
select a.created_at, p.name, p.email, a.action from audit_logs a join profiles p on p.id = a.user_id
where p.role = 'admin' order by a.created_at desc limit 100;
