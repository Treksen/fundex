-- Run this in the Supabase SQL editor AFTER 034_member_admin_tools.sql.
--
-- It changes NOTHING. All the checks run inside ONE block, and the block always ends with an error on purpose,
-- which undoes every test change (so no notification or email from the tests is ever sent).
--
-- What you want to see at the end, shown by the editor as an "error":
--     ALL CHECKS PASSED (16 of 16) ... Nothing was saved.
--   (or "15 of 15 ... SKIP 16" if you have more than one admin, which is fine)
-- Anything starting with "TEST FAILED", or any other error: stop and tell me.
-- Needs at least one admin and two active non-admin members.

DO $$
DECLARE
  v_admin     UUID;
  v_requester UUID;
  v_leaver    UUID;
  v_tx        UUID;
  v_res       JSONB;
  v_st        TEXT;
  v_n         INT;
  v_b         BOOLEAN;
  v_passed    INT := 0;
  v_skip16    BOOLEAN := FALSE;
BEGIN
  SELECT id INTO v_admin     FROM profiles WHERE role = 'admin'  AND is_active ORDER BY created_at LIMIT 1;
  SELECT id INTO v_requester FROM profiles WHERE role = 'member' AND is_active ORDER BY created_at LIMIT 1;
  SELECT id INTO v_leaver    FROM profiles WHERE role = 'member' AND is_active ORDER BY created_at OFFSET 1 LIMIT 1;
  IF v_admin IS NULL OR v_requester IS NULL OR v_leaver IS NULL THEN
    RAISE EXCEPTION 'CANNOT RUN: needs one admin and two active members';
  END IF;

  -- 1-3: a member cannot change their own account status, but can still edit their profile
  PERFORM set_config('request.jwt.claim.sub', v_requester::text, true);
  SET LOCAL ROLE authenticated;
  BEGIN
    UPDATE profiles SET must_change_password = NOT must_change_password WHERE id = v_requester;
    RAISE EXCEPTION 'TEST FAILED 1: a member changed their own account status';
  EXCEPTION WHEN insufficient_privilege THEN v_passed := v_passed + 1;
  END;
  BEGIN
    UPDATE profiles SET login_disabled = TRUE, deactivated_at = NOW() WHERE id = v_requester;
    RAISE EXCEPTION 'TEST FAILED 2: a member changed their sign-in status';
  EXCEPTION WHEN insufficient_privilege THEN v_passed := v_passed + 1;
  END;
  UPDATE profiles SET phone = phone WHERE id = v_requester;
  v_passed := v_passed + 1;                                                     -- 3
  RESET ROLE;

  -- 4-7: an admin in the browser can edit details, but role/status go through the server function only
  PERFORM set_config('request.jwt.claim.sub', v_admin::text, true);
  SET LOCAL ROLE authenticated;
  BEGIN
    UPDATE profiles SET role = 'admin' WHERE id = v_requester;
    RAISE EXCEPTION 'TEST FAILED 4: a role was changed from the browser';
  EXCEPTION WHEN insufficient_privilege THEN v_passed := v_passed + 1;
  END;
  BEGIN
    UPDATE profiles SET is_active = FALSE, login_disabled = TRUE WHERE id = v_requester;
    RAISE EXCEPTION 'TEST FAILED 5: account status was changed from the browser';
  EXCEPTION WHEN insufficient_privilege THEN v_passed := v_passed + 1;
  END;
  UPDATE profiles SET name = name, phone = phone WHERE id = v_requester;
  v_passed := v_passed + 1;                                                     -- 6
  WITH d AS (DELETE FROM profiles WHERE id = v_requester RETURNING 1) SELECT COUNT(*) INTO v_n FROM d;
  IF v_n <> 0 THEN RAISE EXCEPTION 'TEST FAILED 7: a profile was deleted from the browser'; END IF;
  v_passed := v_passed + 1;                                                     -- 7

  -- 8: signed-in users cannot call the server-only functions
  BEGIN
    PERFORM admin_deactivate_member(v_leaver, v_admin, 'test');
    RAISE EXCEPTION 'TEST FAILED 8: a signed-in user called admin_deactivate_member directly';
  EXCEPTION WHEN insufficient_privilege THEN v_passed := v_passed + 1;
  END;
  RESET ROLE;
  PERFORM set_config('request.jwt.claim.sub', '', true);                        -- back to the trusted SQL-editor context

  -- 9: only a real password change clears "must change password"
  UPDATE profiles SET must_change_password = TRUE WHERE id = v_requester;
  UPDATE auth.users SET encrypted_password = encrypted_password WHERE id = v_requester;   -- same hash: no change
  SELECT must_change_password INTO v_b FROM profiles WHERE id = v_requester;
  IF NOT v_b THEN RAISE EXCEPTION 'TEST FAILED 9a: flag cleared without a password change'; END IF;
  UPDATE auth.users SET encrypted_password = 'changed-in-test' WHERE id = v_requester;    -- undone at the end
  SELECT must_change_password INTO v_b FROM profiles WHERE id = v_requester;
  IF v_b THEN RAISE EXCEPTION 'TEST FAILED 9b: a password change did not clear the flag'; END IF;
  v_passed := v_passed + 1;

  -- 10-14: deactivating the last member who still had to vote unblocks the withdrawal
  INSERT INTO transactions (user_id, amount, type, status, created_by, description)
  VALUES (v_requester, 1, 'withdrawal', 'pending', v_requester, '034_verify test (undone)') RETURNING id INTO v_tx;
  INSERT INTO withdrawal_approvals (transaction_id, approver_id, status)
  SELECT v_tx, id, 'pending' FROM profiles WHERE id <> v_requester AND is_active;
  UPDATE withdrawal_approvals SET status = 'approved', voted_at = NOW() WHERE transaction_id = v_tx AND approver_id <> v_leaver;
  IF (process_withdrawal_approval(v_tx))->>'status' <> 'pending' THEN RAISE EXCEPTION 'TEST FAILED 10a: test setup'; END IF;

  v_res := admin_deactivate_member(v_leaver, v_admin, 'verify test');
  IF v_res ? 'error' THEN RAISE EXCEPTION 'TEST FAILED 10b: %', v_res->>'error'; END IF;
  SELECT status INTO v_st FROM transactions WHERE id = v_tx;
  IF v_st <> 'completed' THEN RAISE EXCEPTION 'TEST FAILED 10: withdrawal still % after the last voter left', v_st; END IF;
  v_passed := v_passed + 1;

  SELECT COUNT(*) INTO v_n FROM profiles WHERE id = v_leaver AND NOT is_active AND login_disabled AND deactivated_by = v_admin;
  IF v_n <> 1 THEN RAISE EXCEPTION 'TEST FAILED 11: profile not marked inactive'; END IF;
  SELECT COUNT(*) INTO v_n FROM audit_logs WHERE record_id = v_leaver AND action LIKE 'Admin deactivated member:%';
  IF v_n < 1 THEN RAISE EXCEPTION 'TEST FAILED 11b: no audit entry'; END IF;
  v_passed := v_passed + 1;

  INSERT INTO withdrawal_approvals (transaction_id, approver_id, status) VALUES (v_tx, v_leaver, 'pending');
  SELECT COUNT(*) INTO v_n FROM withdrawal_approvals WHERE transaction_id = v_tx AND approver_id = v_leaver;
  IF v_n <> 0 THEN RAISE EXCEPTION 'TEST FAILED 12: a vote was created for an inactive member'; END IF;
  v_passed := v_passed + 1;

  INSERT INTO notifications (user_id, title, message) VALUES (v_leaver, '034_verify', 'test');
  SELECT COUNT(*) INTO v_n FROM notifications WHERE user_id = v_leaver AND title = '034_verify';
  IF v_n <> 0 THEN RAISE EXCEPTION 'TEST FAILED 13: an inactive member still gets notifications'; END IF;
  SELECT COUNT(*) INTO v_n FROM notifications WHERE user_id = v_leaver AND metadata->>'account_notice' = 'true';
  IF v_n < 1 THEN RAISE EXCEPTION 'TEST FAILED 13b: the deactivation notice was not created'; END IF;
  v_passed := v_passed + 1;

  v_res := admin_reactivate_member(v_leaver, v_admin);
  SELECT COUNT(*) INTO v_n FROM profiles WHERE id = v_leaver AND is_active AND NOT login_disabled AND deactivated_at IS NULL;
  IF v_res ? 'error' OR v_n <> 1 THEN RAISE EXCEPTION 'TEST FAILED 14: reactivation'; END IF;
  v_passed := v_passed + 1;

  -- 15-16: admins are protected
  v_res := admin_deactivate_member(v_admin, v_admin, 'x');
  IF NOT v_res ? 'error' THEN RAISE EXCEPTION 'TEST FAILED 15: an admin was deactivated'; END IF;
  v_res := admin_set_login_disabled(v_admin, v_admin, TRUE, 'x');
  IF NOT v_res ? 'error' THEN RAISE EXCEPTION 'TEST FAILED 15b: an admin''s sign-in was suspended'; END IF;
  v_passed := v_passed + 1;

  SELECT COUNT(*) INTO v_n FROM profiles WHERE role = 'admin';
  IF v_n = 1 THEN
    BEGIN
      UPDATE profiles SET role = 'member' WHERE id = v_admin;
      RAISE EXCEPTION 'TEST FAILED 16: the last admin was demoted by the server';
    EXCEPTION WHEN insufficient_privilege THEN v_passed := v_passed + 1;
    END;
  ELSE
    v_skip16 := TRUE;
  END IF;

  -- Always end with an error: this is what undoes every test change above.
  RAISE EXCEPTION 'ALL CHECKS PASSED (% of %)%. Nothing was saved: this message is how the test undoes itself.',
    v_passed, CASE WHEN v_skip16 THEN 15 ELSE 16 END,
    CASE WHEN v_skip16 THEN ', SKIP 16 (needs exactly one admin, you have ' || v_n || ')' ELSE '' END;
END $$;
