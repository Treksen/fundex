import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { handle, type Deps } from "./logic.ts";

// Uses the service role. This key never leaves the server; the browser only holds the public anon key.
const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const deps: Deps = {
  async getCallerId(jwt) {
    const { data, error } = await admin.auth.getUser(jwt);
    return error ? null : data.user?.id ?? null;
  },
  async getRole(userId) {
    const { data } = await admin.from("profiles").select("role").eq("id", userId).maybeSingle();
    return data?.role ?? null;
  },
  async createUser({ email, password, name }) {
    const { data, error } = await admin.auth.admin.createUser({
      email, password, email_confirm: true, user_metadata: { name },   // no role here: roles are set below, server-side
    });
    if (error) return { error: error.message, duplicate: /already|registered|exists/i.test(error.message) };
    return { id: data.user?.id };
  },
  async setProfile(userId, patch) {
    const { error } = await admin.from("profiles").update({ ...patch, updated_at: new Date().toISOString() }).eq("id", userId);
    return error ? error.message : null;
  },
  async deleteUser(userId) { await admin.auth.admin.deleteUser(userId); },
  async record({ adminId, memberId, email, name, role }) {
    await admin.from("member_invitations").insert({ email, name, role, invited_by: adminId, accepted_at: new Date().toISOString() });
    await admin.from("audit_logs").insert({
      user_id: adminId, action: `Admin registered new user: ${name} (${role})`, table_name: "profiles", record_id: memberId, change_type: "create",
    });
  },
  log: (m) => {
    console.error(m);
    // Also into the app's Error Log. Messages never contain passwords (covered by the security tests).
    admin.from("error_logs").insert({
      severity: "error", source: "edge_function", context: "admin-create-member", message: String(m).slice(0, 500),
    }).then(({ error }) => { if (error) console.error("error_logs insert failed:", error.message); });
  },
};

serve((req) => handle(req, deps));
