// All decisions for "an admin creates a member". No remote imports, so it can be unit-tested outside Deno.
// The password is used once to create the login and is NEVER logged, stored by us, or returned.

export interface Deps {
  getCallerId(jwt: string): Promise<string | null>
  getRole(userId: string): Promise<string | null>
  createUser(a: { email: string; password: string; name: string }): Promise<{ id?: string; error?: string; duplicate?: boolean }>
  setProfile(userId: string, patch: { name: string; role: string }): Promise<string | null>
  deleteUser(userId: string): Promise<void>
  record(a: { adminId: string; memberId: string; email: string; name: string; role: string }): Promise<void>
  log(message: string): void
}

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}
const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } })

export function validateNewMember(body: any): { error?: string; value?: { email: string; name: string; role: string; password: string } } {
  const email = String(body?.email ?? '').trim().toLowerCase()
  const name = String(body?.name ?? '').trim()
  const role = String(body?.role ?? 'member')
  const password = String(body?.password ?? '')
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return { error: 'Enter a valid email address' }
  if (name.length < 2 || name.length > 80) return { error: 'Name must be 2 to 80 characters' }
  if (!['member', 'admin'].includes(role)) return { error: 'Role must be member or admin' }
  if (password.length < 8) return { error: 'Password must be at least 8 characters' }
  if (password.length > 72) return { error: 'Password must be at most 72 characters' }
  return { value: { email, name, role, password } }
}

export async function handle(req: Request, deps: Deps): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS })
  if (req.method !== 'POST') return json(405, { error: 'Method not allowed' })

  const jwt = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '').trim()
  if (!jwt) return json(401, { error: 'Sign in first' })
  const adminId = await deps.getCallerId(jwt)
  if (!adminId) return json(401, { error: 'Your session is not valid. Sign in again.' })

  // The role is read from the database with the service role, never from anything the browser sends.
  if ((await deps.getRole(adminId)) !== 'admin') return json(403, { error: 'Only an admin can add members' })

  let body: any
  try { body = await req.json() } catch { return json(400, { error: 'Invalid request' }) }
  const v = validateNewMember(body)
  if (v.error || !v.value) return json(400, { error: v.error })
  const { email, name, role, password } = v.value

  const created = await deps.createUser({ email, password, name })
  if (created.duplicate) return json(409, { error: 'A member with this email already exists' })
  if (created.error || !created.id) { deps.log(`createUser failed: ${created.error}`); return json(500, { error: 'Could not create the account' }) }
  const memberId = created.id

  const profileError = await deps.setProfile(memberId, { name, role })
  if (profileError) {
    deps.log(`setProfile failed, removing the new login: ${profileError}`)
    try { await deps.deleteUser(memberId) } catch (e) { deps.log(`cleanup failed: ${e}`) }
    return json(500, { error: 'Could not finish creating the account. Nothing was saved.' })
  }

  try { await deps.record({ adminId, memberId, email, name, role }) } catch (e) { deps.log(`record failed (account was created): ${e}`) }
  return json(200, { id: memberId, email, name, role })   // the password is deliberately not echoed back
}
