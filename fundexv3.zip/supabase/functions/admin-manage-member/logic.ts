// All decisions for "an admin manages a member's account". No remote imports, so it can be unit-tested outside Deno.
//
// Rules
//  * Only an admin (role read from the database, never from the request) can call this.
//  * Sensitive actions need the admin to re-enter THEIR OWN password.
//  * An admin cannot use these tools on their own account (they use Profile / Security instead).
//  * An admin cannot suspend, deactivate, reset or change the email of ANOTHER ADMIN: demote them first.
//  * Every change is audit-logged and the member is notified.
//  * Passwords (the admin's and any temporary one) are never logged or stored. A temporary password is returned
//    ONCE in the response so the admin can pass it on; the member must change it at their next sign-in.
//  * There is deliberately no way to see a member's current password.

export interface Caller { id: string; email: string }
export interface Member {
  id: string; name: string; email: string; phone: string | null; role: string
  is_active: boolean; login_disabled: boolean
}
export interface Deps {
  getCaller(jwt: string): Promise<Caller | null>
  getMember(id: string): Promise<Member | null>
  verifyPassword(email: string, password: string): Promise<'ok' | 'wrong' | 'rate_limited'>
  setBanned(userId: string, banned: boolean): Promise<string | null>
  setAuthPassword(userId: string, password: string): Promise<string | null>
  setAuthEmail(userId: string, email: string): Promise<{ error?: string; duplicate?: boolean }>
  updateProfile(userId: string, patch: Record<string, unknown>): Promise<string | null>
  rpc(fn: string, args: Record<string, unknown>): Promise<{ data?: any; error?: string }>
  sendResetEmail(email: string, redirectTo?: string): Promise<string | null>
  notify(userId: string, n: { title: string; message: string; type: string }): Promise<void>
  audit(a: { adminId: string; memberId: string; action: string; oldValues?: unknown; newValues?: unknown }): Promise<void>
  randomBytes(n: number): Uint8Array
  log(message: string): void
}

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}
const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } })

export const ACTIONS = ['summary', 'edit_details', 'set_role', 'suspend', 'restore_login', 'deactivate', 'reactivate', 'send_reset', 'temp_password'] as const
type Action = typeof ACTIONS[number]

// Actions that need the admin's own password. edit_details needs it only when the email changes.
const NEEDS_PASSWORD: Action[] = ['set_role', 'suspend', 'restore_login', 'deactivate', 'reactivate', 'send_reset', 'temp_password']
// Actions not allowed on another admin (demote first).
const NOT_ON_ADMINS: Action[] = ['suspend', 'deactivate', 'send_reset', 'temp_password']
// Actions allowed on a deactivated member.
const ALLOWED_WHEN_INACTIVE: Action[] = ['summary', 'edit_details', 'reactivate']

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const PHONE = /^[+0-9 ()-]{0,20}$/

// 12 characters from an alphabet without look-alikes (no 0/O, 1/l/I), shown as xxxx-xxxx-xxxx. ~70 bits.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
export function makeTemporaryPassword(randomBytes: (n: number) => Uint8Array): string {
  const out: string[] = []
  const limit = 256 - (256 % ALPHABET.length)          // reject biased bytes
  while (out.length < 12) {
    for (const b of randomBytes(32)) {
      if (b < limit && out.length < 12) out.push(ALPHABET[b % ALPHABET.length])
    }
  }
  return `${out.slice(0, 4).join('')}-${out.slice(4, 8).join('')}-${out.slice(8).join('')}`
}

export function safeRedirect(value: unknown): string | undefined {
  try {
    const u = new URL(String(value ?? ''))
    const local = u.protocol === 'http:' && (u.hostname === 'localhost' || u.hostname === '127.0.0.1')
    if ((u.protocol === 'https:' || local) && u.pathname === '/reset-password' && !u.username && !u.password) {
      return `${u.origin}/reset-password`
    }
  } catch { /* not a URL */ }
  return undefined   // Supabase then uses the Site URL
}

export async function handle(req: Request, deps: Deps): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS })
  if (req.method !== 'POST') return json(405, { error: 'Method not allowed' })

  const jwt = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '').trim()
  if (!jwt) return json(401, { error: 'Sign in first' })
  const caller = await deps.getCaller(jwt)
  if (!caller) return json(401, { error: 'Your session is not valid. Sign in again.' })
  const me = await deps.getMember(caller.id)
  if (!me || me.role !== 'admin' || !me.is_active || me.login_disabled) return json(403, { error: 'Only an admin can manage members' })

  let body: any
  try { body = await req.json() } catch { return json(400, { error: 'Invalid request' }) }
  const action = String(body?.action ?? '') as Action
  if (!ACTIONS.includes(action)) return json(400, { error: 'Unknown action' })
  const memberId = String(body?.member_id ?? '')
  if (!UUID.test(memberId)) return json(400, { error: 'Choose a member' })
  if (memberId === caller.id) return json(400, { error: 'Use your own Profile and Security pages for your account' })

  const m = await deps.getMember(memberId)
  if (!m) return json(404, { error: 'Member not found' })

  // what exactly is being asked for edit_details
  let newEmail: string | null = null
  if (action === 'edit_details' && body?.email !== undefined) {
    const e = String(body.email ?? '').trim().toLowerCase()
    if (e !== String(m.email || '').toLowerCase()) newEmail = e
  }

  if (m.role === 'admin' && (NOT_ON_ADMINS.includes(action) || newEmail)) {
    return json(403, { error: `${m.name} is an admin. Change them to a member first.` })
  }
  if (!m.is_active && !ALLOWED_WHEN_INACTIVE.includes(action)) {
    return json(409, { error: `${m.name} is deactivated. Reactivate them first.` })
  }
  if (!m.is_active && newEmail) return json(409, { error: `${m.name} is deactivated. Reactivate them first.` })
  if (m.login_disabled && (action === 'send_reset' || action === 'temp_password' || action === 'suspend')) {
    return json(409, { error: action === 'suspend' ? 'Sign-in is already suspended' : `${m.name}'s sign-in is suspended. Restore sign-in first.` })
  }
  if (action === 'reactivate' && m.is_active) return json(409, { error: `${m.name} is already active` })
  if (action === 'restore_login' && (!m.login_disabled || !m.is_active)) {
    return json(409, { error: m.is_active ? 'Sign-in is not suspended' : `${m.name} is deactivated. Reactivate them instead.` })
  }

  if (NEEDS_PASSWORD.includes(action) || newEmail) {
    const pw = String(body?.admin_password ?? '')
    if (!pw) return json(401, { error: 'Enter your own password to confirm', needs_password: true })
    if (pw.length > 72) return json(401, { error: 'Your password is not correct', needs_password: true })
    const check = await deps.verifyPassword(caller.email, pw)
    if (check === 'rate_limited') return json(429, { error: 'Too many attempts. Wait a few minutes and try again.' })
    if (check !== 'ok') return json(401, { error: 'Your password is not correct', needs_password: true })
  }

  const reason = String(body?.reason ?? '').trim().slice(0, 500) || null
  const first = (s: string) => String(s || '').split(' ')[0]

  try {
    switch (action) {
      case 'summary': {
        const { data, error } = await deps.rpc('admin_member_summary', { p_member: m.id })
        if (error) { deps.log(`summary failed: ${error}`); return json(500, { error: 'Could not load the member' }) }
        return json(200, { ok: true, summary: data })
      }

      case 'edit_details': {
        const name = body?.name === undefined ? m.name : String(body.name ?? '').trim()
        const phoneRaw = body?.phone === undefined ? m.phone : String(body.phone ?? '').trim()
        const phone = phoneRaw ? phoneRaw : null
        if (name.length < 2 || name.length > 80) return json(400, { error: 'Name must be 2 to 80 characters' })
        if (phone && !PHONE.test(phone)) return json(400, { error: 'Enter a valid phone number' })
        if (newEmail !== null && (!EMAIL.test(newEmail) || newEmail.length > 254)) return json(400, { error: 'Enter a valid email address' })

        const patch: Record<string, unknown> = {}
        if (name !== m.name) patch.name = name
        if (phone !== (m.phone || null)) patch.phone = phone
        if (newEmail === null && Object.keys(patch).length === 0) return json(400, { error: 'Nothing to change' })

        if (newEmail !== null) {
          const r = await deps.setAuthEmail(m.id, newEmail)
          if (r.duplicate) return json(409, { error: 'Another account already uses this email' })
          if (r.error) { deps.log(`setAuthEmail failed: ${r.error}`); return json(500, { error: 'Could not change the email' }) }
          patch.email = newEmail
        }
        const err = await deps.updateProfile(m.id, patch)
        if (err) {
          deps.log(`edit_details profile update failed: ${err}`)
          if (newEmail !== null) {
            const back = await deps.setAuthEmail(m.id, m.email)
            if (back.error) deps.log(`could not restore the sign-in email: ${back.error}`)
          }
          return json(500, { error: 'Could not save the changes. Nothing was changed.' })
        }
        const old: Record<string, unknown> = {}
        for (const k of Object.keys(patch)) old[k] = (m as any)[k] ?? null
        await deps.audit({ adminId: caller.id, memberId: m.id, action: `Admin edited member details: ${m.name}`, oldValues: old, newValues: patch })
        if (newEmail !== null) {
          await deps.notify(m.id, { title: 'Your sign-in email was changed', type: 'warning',
            message: `An admin changed the email you use to sign in to Nitalink to ${newEmail}. If you did not ask for this, contact a group admin.` })
        }
        return json(200, { ok: true, message: `${first(name)}'s details were saved` })
      }

      case 'set_role': {
        const role = String(body?.role ?? '')
        if (!['admin', 'member'].includes(role)) return json(400, { error: 'Role must be member or admin' })
        if (role === m.role) return json(400, { error: `${m.name} is already ${role === 'admin' ? 'an admin' : 'a member'}` })
        if (role === 'admin' && m.login_disabled) return json(409, { error: `Restore ${first(m.name)}'s sign-in before making them an admin` })
        const err = await deps.updateProfile(m.id, { role })
        if (err) {
          if (/last admin/i.test(err)) return json(409, { error: 'You cannot remove the last admin' })
          deps.log(`set_role failed: ${err}`); return json(500, { error: 'Could not change the role' })
        }
        await deps.audit({ adminId: caller.id, memberId: m.id, action: `Admin changed role of ${m.name} to ${role}`, oldValues: { role: m.role }, newValues: { role } })
        await deps.notify(m.id, role === 'admin'
          ? { title: 'You are now a Nitalink admin', type: 'info', message: `${me.name} made you an admin. You now see the Admin section in the menu.` }
          : { title: 'Your Nitalink role changed', type: 'warning', message: `${me.name} changed your role from admin to member.` })
        return json(200, { ok: true, message: `${first(m.name)} is now ${role === 'admin' ? 'an admin' : 'a member'}` })
      }

      case 'suspend':
      case 'deactivate': {
        const banErr = await deps.setBanned(m.id, true)
        if (banErr) { deps.log(`ban failed: ${banErr}`); return json(500, { error: 'Could not block sign-in. Nothing was changed.' }) }
        const { data, error } = action === 'suspend'
          ? await deps.rpc('admin_set_login_disabled', { p_member: m.id, p_admin: caller.id, p_disabled: true, p_reason: reason })
          : await deps.rpc('admin_deactivate_member', { p_member: m.id, p_admin: caller.id, p_reason: reason })
        if (error || data?.error) {
          // the database refused or failed: undo the sign-in block so the two never disagree
          const undo = await deps.setBanned(m.id, m.login_disabled)   // back to exactly what it was
          if (undo) deps.log(`could not restore the previous sign-in state for ${m.id}: ${undo}`)
          if (data?.error) return json(409, { error: data.error })
          deps.log(`${action} failed: ${error}`); return json(500, { error: 'Could not complete this. Nothing was changed.' })
        }
        if (action === 'suspend') return json(200, { ok: true, message: `${first(m.name)} can no longer sign in` })
        return json(200, { ok: true, message: `${first(m.name)} was deactivated`, result: data })
      }

      case 'restore_login':
      case 'reactivate': {
        const banErr = await deps.setBanned(m.id, false)
        if (banErr) { deps.log(`unban failed: ${banErr}`); return json(500, { error: 'Could not restore sign-in. Nothing was changed.' }) }
        const { data, error } = action === 'restore_login'
          ? await deps.rpc('admin_set_login_disabled', { p_member: m.id, p_admin: caller.id, p_disabled: false, p_reason: reason })
          : await deps.rpc('admin_reactivate_member', { p_member: m.id, p_admin: caller.id })
        if (error || data?.error) {
          const undo = await deps.setBanned(m.id, m.login_disabled)   // back to exactly what it was
          if (undo) deps.log(`could not restore the previous sign-in state for ${m.id}: ${undo}`)
          if (data?.error) return json(409, { error: data.error })
          deps.log(`${action} failed: ${error}`); return json(500, { error: 'Could not complete this. Nothing was changed.' })
        }
        return json(200, { ok: true, message: action === 'reactivate' ? `${first(m.name)} is active again` : `${first(m.name)} can sign in again` })
      }

      case 'send_reset': {
        const err = await deps.sendResetEmail(m.email, safeRedirect(body?.redirect_to))
        if (err) {
          if (/rate|too many|seconds|limit|security purposes/i.test(err)) return json(429, { error: 'A reset email was sent recently. Wait a minute and try again.' })
          deps.log(`send_reset failed: ${err}`); return json(500, { error: 'Could not send the reset email' })
        }
        await deps.audit({ adminId: caller.id, memberId: m.id, action: `Admin sent a password reset email to ${m.name}` })
        await deps.notify(m.id, { title: 'Password reset email sent', type: 'warning',
          message: `${me.name} sent you a link to set a new Nitalink password. Check your email. If you did not ask for this, contact a group admin.` })
        return json(200, { ok: true, message: `Reset email sent to ${m.email}` })
      }

      case 'temp_password': {
        const temp = makeTemporaryPassword(deps.randomBytes)
        const err = await deps.setAuthPassword(m.id, temp)
        if (err) { deps.log(`setAuthPassword failed (password not shown): ${err.replaceAll(temp, '***')}`); return json(500, { error: 'Could not set a temporary password. Nothing was changed.' }) }
        const flagErr = await deps.updateProfile(m.id, { must_change_password: true })
        if (flagErr) deps.log(`could not mark must_change_password: ${flagErr}`)
        await deps.audit({ adminId: caller.id, memberId: m.id, action: `Admin set a temporary password for ${m.name}`, newValues: { must_change_password: !flagErr } })
        await deps.notify(m.id, { title: 'An admin set a temporary password', type: 'warning',
          message: `${me.name} set a temporary password for your Nitalink account. You will be asked to choose your own when you sign in. If you did not ask for this, contact a group admin.` })
        return json(200, {
          ok: true, temporary_password: temp, forced_change: !flagErr,
          message: flagErr
            ? `Temporary password set, but ${first(m.name)} will NOT be forced to change it. Ask them to change it in Security.`
            : `Temporary password set. ${first(m.name)} must change it at their next sign-in.`,
        })
      }
    }
  } catch (e) {
    deps.log(`${action} crashed: ${e instanceof Error ? e.message : e}`)
    return json(500, { error: 'Something went wrong. Please try again.' })
  }
  return json(400, { error: 'Unknown action' })
}
