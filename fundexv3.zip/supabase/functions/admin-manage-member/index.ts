import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { handle, type Deps } from "./logic.ts";

const URL_ = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const opts = { auth: { persistSession: false, autoRefreshToken: false } };

// Service role: never leaves the server. The browser only holds the public anon key.
const admin = createClient(URL_, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, opts);

const FOREVER = "876000h"; // ~100 years: Supabase's way of "disabled until an admin restores it"

const deps: Deps = {
  async getCaller(jwt) {
    const { data, error } = await admin.auth.getUser(jwt);
    if (error || !data.user?.id || !data.user.email) return null;
    return { id: data.user.id, email: data.user.email };
  },
  async getMember(id) {
    const { data } = await admin.from("profiles")
      .select("id, name, email, phone, role, is_active, login_disabled").eq("id", id).maybeSingle();
    return data ?? null;
  },
  async verifyPassword(email, password) {
    // A throw-away client, so the admin's real session is untouched. The check session is signed out at once.
    const probe = createClient(URL_, ANON, opts);
    const { error } = await probe.auth.signInWithPassword({ email, password });
    if (error) return /rate|too many|request this after/i.test(error.message) ? "rate_limited" : "wrong";
    await probe.auth.signOut({ scope: "local" });
    return "ok";
  },
  async setBanned(userId, banned) {
    const { error } = await admin.auth.admin.updateUserById(userId, { ban_duration: banned ? FOREVER : "none" });
    return error ? error.message : null;
  },
  async setAuthPassword(userId, password) {
    const { error } = await admin.auth.admin.updateUserById(userId, { password });
    return error ? error.message : null;
  },
  async setAuthEmail(userId, email) {
    const { error } = await admin.auth.admin.updateUserById(userId, { email, email_confirm: true });
    if (error) return { error: error.message, duplicate: /already|registered|exists/i.test(error.message) };
    return {};
  },
  async updateProfile(userId, patch) {
    const { error } = await admin.from("profiles").update({ ...patch, updated_at: new Date().toISOString() }).eq("id", userId);
    return error ? error.message : null;
  },
  async rpc(fn, args) {
    const { data, error } = await admin.rpc(fn, args);
    return error ? { error: error.message } : { data };
  },
  async sendResetEmail(email, redirectTo) {
    const { error } = await createClient(URL_, ANON, opts).auth.resetPasswordForEmail(email, redirectTo ? { redirectTo } : undefined);
    return error ? error.message : null;
  },
  async notify(userId, n) {
    const { error } = await admin.from("notifications").insert({
      user_id: userId, title: n.title, message: n.message, type: n.type, metadata: { account_notice: true },
    });
    if (error) console.error("notify failed:", error.message);
  },
  async audit({ adminId, memberId, action, oldValues, newValues }) {
    const { error } = await admin.from("audit_logs").insert({
      user_id: adminId, action, table_name: "profiles", record_id: memberId, change_type: "update",
      old_values: oldValues ?? null, new_values: newValues ?? null,
    });
    if (error) console.error("audit failed:", error.message);
  },
  randomBytes: (n) => crypto.getRandomValues(new Uint8Array(n)),
  log: (m) => {
    console.error(m);
    // Also into the app's Error Log. Messages never contain passwords (covered by the security tests).
    admin.from("error_logs").insert({
      severity: "error", source: "edge_function", context: "admin-manage-member", message: String(m).slice(0, 500),
    }).then(({ error }) => { if (error) console.error("error_logs insert failed:", error.message); });
  },
};

serve((req) => handle(req, deps));
