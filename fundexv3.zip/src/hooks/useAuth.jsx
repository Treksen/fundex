import { createContext, useContext, useEffect, useRef, useState } from "react";
import { supabase } from "../lib/supabase";
import { accountGate, friendlySignInError, BLOCKED_MESSAGE } from "../lib/memberAdmin";

const AuthContext = createContext({});

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [recovery, setRecovery] = useState(false); // true while a password-reset link is being used
  const [blockedNotice, setBlockedNotice] = useState(""); // shown on the login page after a forced sign-out
  const userIdRef = useRef(null);

  const fetchProfile = async (userId) => {
    if (!userId) { setLoading(false); return; }
    try {
      const { data } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", userId)
        .maybeSingle();
      // A suspended or deactivated member whose session is still alive is signed out here.
      if (accountGate(data) === "blocked") {
        setBlockedNotice(BLOCKED_MESSAGE);
        setProfile(null);
        await supabase.auth.signOut({ scope: "local" }).catch(() => {});
        return;
      }
      setProfile(data || null);
    } catch (err) {
      console.error("fetchProfile failed:", err);
      setProfile(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { userIdRef.current = user?.id ?? null; }, [user]);

  // Re-check the account when the app comes back to the foreground, so a suspended or deactivated member is
  // signed out without waiting for their session to expire.
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === "visible" && userIdRef.current) fetchProfile(userIdRef.current);
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  useEffect(() => {
    // Hard timeout — never spin more than 4 seconds
    const timeout = setTimeout(() => {
      console.warn("Auth timeout — forcing loading=false");
      setLoading(false);
    }, 4000);

    supabase.auth
      .getSession()
      .then(({ data: { session } }) => {
        clearTimeout(timeout);
        if (session?.user) {
          setUser(session.user);
          fetchProfile(session.user.id);
        } else {
          setUser(null);
          setProfile(null);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.error("getSession error:", err);
        clearTimeout(timeout);
        setLoading(false);
      });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'PASSWORD_RECOVERY') setRecovery(true);
      if (session?.user) {
        setUser(session.user);
        fetchProfile(session.user.id);
      } else {
        setUser(null);
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      clearTimeout(timeout);
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      // Supabase auth errors
      if (error) {
        return {
          data: null,
          error: {
            message: friendlySignInError(error.message),
          },
        };
      }

      setBlockedNotice("");
      return { data, error: null };
    } catch (err) {
      console.error("Sign in failed:", err);

      // Network / offline error
      if (err.message?.includes("Failed to fetch") || !navigator.onLine) {
        return {
          data: null,
          error: {
            message:
              "No internet connection. Please connect to a network and try again.",
          },
        };
      }

      return {
        data: null,
        error: {
          message: "Something went wrong. Please try again.",
        },
      };
    }
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    return { error };
  };

  const updateProfile = async (updates) => {
    const { data, error } = await supabase
      .from("profiles")
      .update(updates)
      .eq("id", user.id)
      .select()
      .single();
    if (!error) setProfile(data);
    return { data, error };
  };

  const isAdmin = profile?.role === "admin";
  const mustChangePassword = accountGate(profile) === "must_change";

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        isAdmin,
        recovery,
        clearRecovery: () => setRecovery(false),
        mustChangePassword,
        blockedNotice,
        clearBlockedNotice: () => setBlockedNotice(""),
        signIn,
        signOut,
        updateProfile,
        fetchProfile: () => fetchProfile(user?.id),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
