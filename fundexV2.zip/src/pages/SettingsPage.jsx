import MemberAvatar from '../components/MemberAvatar'
import PageHeader from '../components/PageHeader'
import AdminActions from '../components/AdminActions'
import { useState, useEffect, useRef, useCallback } from 'react'
import { User, Bell, Lock, Save, Check, ExternalLink, Camera, UserPlus, Shield, Mail, ToggleLeft, ToggleRight, RefreshCw, Smartphone } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { formatDateTime } from '../lib/utils'
import toast from 'react-hot-toast'
import { useAppUpdate, isStandaloneApp } from '../hooks/useAppUpdate'
import { settingsRedirect, SECTION_TITLES } from '../lib/settingsSections'
import { useSearchParams, useNavigate } from 'react-router-dom'

export default function SettingsPage({ section } = {}) {
  const { profile, updateProfile, isAdmin } = useAuth();
  const upd = useAppUpdate();
  const updLabel = { fontSize: 11, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--text-muted)", fontWeight: 600 };
  const handleCheckUpdate = async () => {
    const r = await upd.checkForUpdate();
    if (!r.ok) {
      toast.error(r.reason === "unsupported" ? "Update checks are not available in this mode" : "Could not check. Please check your connection.");
    } else if (r.found) {
      toast.success('A new version is ready. Tap "Update now".');
    } else {
      toast.success("You are on the latest version");
    }
  };
  const handleResetCache = async () => {
    if (!window.confirm("Reset the app cache? This clears the downloaded app files and reloads Nitalink. You will stay signed in.")) return;
    await upd.resetAppCache();
  };
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const requestedTab = searchParams.get("tab");
  const defaultTab = ["notifications", "updates"].includes(requestedTab) ? requestedTab : "profile";
  const [tabState, setActiveTab] = useState(defaultTab);
  const activeTab = section || tabState; // a section page (Security / App & Updates / Admin Panel) always shows its own section
  const sectionInfo = section ? SECTION_TITLES[section] : null;
  useEffect(() => {
    const to = settingsRedirect({ section, requestedTab, isAdmin, profileLoaded: !!profile });
    if (to) navigate(to, { replace: true });
  }, [section, requestedTab, isAdmin, profile, navigate]);
  const [notifications, setNotifications] = useState([]);
  const [allNotifications, setAllNotifications] = useState([]);
  const [notifView, setNotifView] = useState("mine"); // 'mine' | 'all'
  const [filterMember, setFilterMember] = useState(""); // user_id filter for all-view
  const [loadingNotif, setLoadingNotif] = useState(false);
  const [emailPrefs, setEmailPrefs] = useState({
    email_notifications_enabled: true,
    notify_on_deposits: true,
    notify_on_withdrawals: true,
    notify_on_investments: true,
    notify_on_governance: true,
  });
  const [savingEmailPrefs, setSavingEmailPrefs] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "" });
  const [pwForm, setPwForm] = useState({ current: "", newPw: "", confirm: "" });
  const [saving, setSaving] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(""); // e.g. "Compressing…" / "Uploading…"
  const fileInputRef = useRef(null);

  /**
   * Compress an image file using the Canvas API.
   * Resizes to maxDim × maxDim (keeping aspect ratio) and re-encodes as JPEG.
   * Returns a Blob — typically <200 KB for a 800px avatar.
   */
  const compressImage = (file, maxDim = 800, quality = 0.82) => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        let { width, height } = img;

        // Scale down proportionally if larger than maxDim
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height / width) * maxDim);
            width = maxDim;
          } else {
            width = Math.round((width / height) * maxDim);
            height = maxDim;
          }
        }

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) =>
            blob ? resolve(blob) : reject(new Error("Canvas toBlob failed")),
          "image/jpeg",
          quality,
        );
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error("Image load failed"));
      };
      img.src = url;
    });
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    // Reset input so same file can be re-selected after an error
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    setUploadingPhoto(true);
    try {
      // Step 1 — Compress
      setUploadProgress("Compressing…");
      const compressed = await compressImage(file);
      const sizeMB = (compressed.size / 1024 / 1024).toFixed(2);

      // Step 2 — Upload (always as JPEG after compression)
      setUploadProgress(`Uploading (${sizeMB} MB)…`);
      const path = `avatars/${profile.id}.jpg`;
      const { error: upErr } = await supabase.storage
        .from("avatars")
        .upload(path, compressed, { upsert: true, contentType: "image/jpeg" });
      if (upErr) throw upErr;

      // Step 3 — Save URL to profile
      const { data: urlData } = supabase.storage
        .from("avatars")
        .getPublicUrl(path);
      const avatarUrl = urlData.publicUrl + `?t=${Date.now()}`; // cache-bust
      const { error: profErr } = await updateProfile({ avatar_url: avatarUrl });
      if (profErr) throw profErr;

      toast.success(`Photo updated! (${sizeMB} MB after compression)`);
    } catch (err) {
      toast.error("Upload failed: " + err.message);
    } finally {
      setUploadingPhoto(false);
      setUploadProgress("");
    }
  };

  useEffect(() => {
    if (profile) {
      setForm({ name: profile.name || "", phone: profile.phone || "" });
      setEmailPrefs({
        email_notifications_enabled:
          profile.email_notifications_enabled !== false,
        notify_on_deposits: profile.notify_on_deposits !== false,
        notify_on_withdrawals: profile.notify_on_withdrawals !== false,
        notify_on_investments: profile.notify_on_investments !== false,
        notify_on_governance: profile.notify_on_governance !== false,
      });
    }
  }, [profile]);

  useEffect(() => {
    if (activeTab === "notifications") {
      fetchNotifications();
      if (isAdmin) fetchAllNotifications();
    }
  }, [activeTab, isAdmin]);

  const fetchNotifications = useCallback(async () => {
    setLoadingNotif(true);
    const { data } = await supabase
      .from("notifications")
      .select(
        "*, email_sent, email_sent_at, profiles!notifications_user_id_fkey(name, avatar_url)",
      )
      .eq("user_id", profile.id)
      .order("created_at", { ascending: false });
    if (data) setNotifications(data);
    setLoadingNotif(false);
  }, [profile]);

  const fetchAllNotifications = useCallback(async () => {
    setLoadingNotif(true);
    const { data, error } = await supabase.rpc("admin_get_all_notifications");
    if (error) {
      console.error("fetchAllNotifications error:", error.message);
      toast.error("Could not load all notifications: " + error.message);
    } else {
      // RPC returns JSONB — data is already an array or a JSON string
      const rows = Array.isArray(data)
        ? data
        : (typeof data === "string" ? JSON.parse(data) : data) || [];
      setAllNotifications(rows);
    }
    setLoadingNotif(false);
  }, []);

  const saveEmailPrefs = async () => {
    setSavingEmailPrefs(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        email_notifications_enabled: emailPrefs.email_notifications_enabled,
        notify_on_deposits: emailPrefs.notify_on_deposits,
        notify_on_withdrawals: emailPrefs.notify_on_withdrawals,
        notify_on_investments: emailPrefs.notify_on_investments,
        notify_on_governance: emailPrefs.notify_on_governance,
        updated_at: new Date().toISOString(),
      })
      .eq("id", profile.id);
    setSavingEmailPrefs(false);
    if (error) toast.error("Failed to save: " + error.message);
    else toast.success("Email preferences saved ✅");
  };

  const toggleEmailPref = (key) => {
    setEmailPrefs((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const markAllRead = async () => {
    await supabase
      .from("notifications")
      .update({ is_read: true })
      .eq("user_id", profile.id)
      .eq("is_read", false);
    fetchNotifications();
  };

  const markRead = async (id) => {
    await supabase.from("notifications").update({ is_read: true }).eq("id", id);
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)),
    );
  };

  const deleteNotification = async (id) => {
    if (!window.confirm("Delete this notification?")) return;
    const { error } = await supabase.rpc("admin_delete_notification", {
      p_notification_id: id,
    });
    if (error) toast.error("Delete failed: " + error.message);
    else {
      toast.success("Notification deleted");
      fetchNotifications();
      if (isAdmin) fetchAllNotifications();
    }
  };

  const deleteAnyNotification = async (id) => {
    if (!window.confirm("Delete this notification?")) return;
    const { error } = await supabase.rpc("admin_delete_notification", {
      p_notification_id: id,
    });
    if (error) toast.error("Delete failed: " + error.message);
    else {
      toast.success("Notification deleted");
      fetchAllNotifications();
    }
  };

  const clearMemberNotifications = async (userId, memberName) => {
    if (
      !window.confirm(
        `Clear ALL notifications for ${memberName}? This cannot be undone.`,
      )
    )
      return;
    const { error } = await supabase.rpc("admin_delete_all_notifications", {
      p_user_id: userId,
    });
    if (error) toast.error("Failed: " + error.message);
    else {
      toast.success(`Cleared all notifications for ${memberName}`);
      fetchAllNotifications();
    }
  };

  const clearAllNotifications = async () => {
    if (
      !window.confirm(
        `Clear all ${notifications.length} notification${notifications.length !== 1 ? "s" : ""}? This cannot be undone.`,
      )
    )
      return;
    const { error } = await supabase.rpc("admin_delete_all_notifications", {
      p_user_id: profile.id,
    });
    if (error) toast.error("Failed: " + error.message);
    else {
      toast.success("All cleared");
      fetchNotifications();
    }
  };

  const saveProfile = async (e) => {
    e.preventDefault();
    setSaving(true);
    const { error } = await updateProfile({
      name: form.name,
      phone: form.phone || null,
    });
    setSaving(false);
    if (error) toast.error(error.message);
    else toast.success("Profile updated!");
  };

  const changePassword = async (e) => {
    e.preventDefault();
    if (pwForm.newPw !== pwForm.confirm) {
      toast.error("Passwords do not match");
      return;
    }
    if (pwForm.newPw.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    setSaving(true);
    const { error } = await supabase.auth.updateUser({
      password: pwForm.newPw,
    });
    setSaving(false);
    if (error) toast.error(error.message);
    else {
      toast.success("Password changed!");
      setPwForm({ current: "", newPw: "", confirm: "" });
    }
  };

  const TABS = [
    { id: "profile", label: "Profile", icon: User },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "security", label: "Security", icon: Lock },
    { id: "updates", label: "App & Updates", icon: Smartphone },
    ...(isAdmin ? [{ id: "admin", label: "Admin", icon: Shield }] : []),
  ];

  // Admin: register new user state
  const [inviteForm, setInviteForm] = useState({
    email: "",
    name: "",
    role: "member",
    password: "",
  });
  const [inviting, setInviting] = useState(false);
  const [invitations, setInvitations] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [loadingAdmin, setLoadingAdmin] = useState(false);

  const fetchAdminData = useCallback(async () => {
    if (!isAdmin) return;
    setLoadingAdmin(true);
    const [invRes, remRes] = await Promise.all([
      supabase
        .from("member_invitations")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20),
      supabase.from("scheduled_reminders").select("*").order("reminder_type"),
    ]);
    if (invRes.data) setInvitations(invRes.data);
    if (remRes.data) setReminders(remRes.data);
    setLoadingAdmin(false);
  }, [isAdmin]);

  useEffect(() => {
    if (activeTab === "admin") fetchAdminData();
  }, [activeTab, fetchAdminData]);

  const handleRegisterUser = async (e) => {
    e.preventDefault();
    if (!inviteForm.email || !inviteForm.name || !inviteForm.password) {
      toast.error("Email, name and password are required");
      return;
    }
    if (inviteForm.password.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    setInviting(true);
    try {
      // The server creates the login and sets the role. Doing this in the browser let anyone on the internet
      // sign up as an admin, so it now goes through the admin-create-member function (admins only).
      const { data: created, error: fnErr } = await supabase.functions.invoke("admin-create-member", {
        body: {
          email: inviteForm.email.trim().toLowerCase(),
          name: inviteForm.name.trim(),
          role: inviteForm.role,
          password: inviteForm.password,
        },
      });
      if (fnErr || created?.error) {
        let message = created?.error;
        if (!message && fnErr?.context?.json) {
          try { message = (await fnErr.context.json())?.error; } catch { /* use the generic message */ }
        }
        throw new Error(message || "Could not create the member. Please try again.");
      }

      toast.success(
        `✅ ${inviteForm.name} has been registered! They can now log in with the provided credentials.`,
      );
      setInviteForm({ email: "", name: "", role: "member", password: "" });
      fetchAdminData();
    } catch (err) {
      toast.error("Registration failed: " + err.message);
    }
    setInviting(false);
  };

  //NEW ADDTION
  // ===============================
  // 📣 SEND BROADCAST NOTIFICATION
  // ===============================
  const sendBroadcastNotification = async (e) => {
    e.preventDefault();

    if (!broadcastForm.title || !broadcastForm.message) {
      toast.error("Title and message are required");
      return;
    }

    setSendingBroadcast(true);

    try {
      // STEP 1: get users based on target
      let query = supabase.from("profiles").select("id, role");

      if (broadcastForm.target === "admins") {
        query = query.eq("role", "admin");
      }

      if (broadcastForm.target === "members") {
        query = query.eq("role", "member");
      }

      const { data: users, error } = await query;

      if (error) throw error;

      // STEP 2: create notifications for each user
      const notifications = users.map((u) => ({
        user_id: u.id,
        title: broadcastForm.title,
        message: broadcastForm.message,
        type: "info",
        action_url: broadcastForm.action_url || null,
        created_at: new Date().toISOString(),
      }));

      const { error: insertError } = await supabase
        .from("notifications")
        .insert(notifications);

      if (insertError) throw insertError;

      toast.success(`Sent to ${users.length} users 🚀`);

      setBroadcastForm({
        title: "",
        message: "",
        action_url: "",
        target: "all",
        scheduled_for: "",
      });

      fetchAllNotifications();
    } catch (err) {
      console.error(err);
      toast.error("Failed: " + err.message);
    }

    setSendingBroadcast(false);
  };

  //END NEW ADDTION

  const toggleReminder = async (reminder) => {
    const { error } = await supabase
      .from("scheduled_reminders")
      .update({ is_active: !reminder.is_active })
      .eq("id", reminder.id);
    if (error) toast.error("Update failed");
    else {
      toast.success("Reminder updated");
      fetchAdminData();
    }
  };

  const updateReminderDay = async (id, day) => {
    const d = Math.max(1, Math.min(28, Number(day)));
    const { error } = await supabase
      .from("scheduled_reminders")
      .update({ day_of_month: d })
      .eq("id", id);
    if (!error) fetchAdminData();
  };

  const getNotifColor = (type) => {
    const map = {
      success: "var(--accent-emerald)",
      warning: "var(--accent-amber)",
      error: "var(--accent-red)",
      approval: "var(--olive)",
      info: "var(--accent-blue-light)",
    };
    return map[type] || "var(--text-secondary)";
  };

  const getNotifIcon = (type) => {
    const map = {
      success: "✅",
      warning: "⚠️",
      error: "❌",
      approval: "🔔",
      info: "ℹ️",
    };
    return map[type] || "📣";
  };

  const unread = notifications.filter((n) => !n.is_read).length;

  ///NEW PAGES
  const [notifForm, setNotifForm] = useState({
    title: "",
    message: "",
    action_url: "",
  });
  const [sendingNotif, setSendingNotif] = useState(false);
  const sendSystemNotification = async (e) => {
    e.preventDefault();

    if (!notifForm.title || !notifForm.message) {
      toast.error("Title and message are required");
      return;
    }

    setSendingNotif(true);

    try {
      // 1. Get all users
      const { data: users, error: usersError } = await supabase
        .from("profiles")
        .select("id");

      if (usersError) throw usersError;

      // 2. Create notifications for each user
      const inserts = users.map((u) => ({
        user_id: u.id,
        title: notifForm.title,
        message: notifForm.message,
        type: "info",
        action_url: notifForm.action_url || null,
        created_at: new Date().toISOString(),
      }));

      const { error: insertError } = await supabase
        .from("notifications")
        .insert(inserts);

      if (insertError) throw insertError;

      toast.success(`Notification sent to ${users.length} users 🎉`);

      setNotifForm({
        title: "",
        message: "",
        action_url: "",
      });

      // refresh admin view
      fetchAllNotifications();
    } catch (err) {
      console.error(err);
      toast.error("Failed: " + err.message);
    }

    setSendingNotif(false);
  };

  // ===============================
  // 📣 NOTIFICATION BROADCAST STATE
  // ===============================
  const [broadcastForm, setBroadcastForm] = useState({
    title: "",
    message: "",
    action_url: "",
    target: "all", // all | admins | members | selected
    scheduled_for: "",
  });

  const [sendingBroadcast, setSendingBroadcast] = useState(false);

  return (
    <div style={{ maxWidth: "100%" }}>
      <PageHeader
        title={sectionInfo ? sectionInfo[0] : "Settings"}
        subtitle={sectionInfo ? sectionInfo[1] : "Manage your account and preferences"}
      />

      {!section && (
      <>
      {/* Profile header with photo upload */}
      <div
        className="card mb-6"
        style={{
          display: "flex",
          alignItems: "center",
          gap: 16,
          flexWrap: "wrap",
        }}
      >
        {/* Avatar with camera overlay */}
        <div style={{ position: "relative", flexShrink: 0 }}>
          <MemberAvatar
            name={profile?.name}
            avatarUrl={profile?.avatar_url}
            size={64}
            fontSize={22}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploadingPhoto}
            title="Change profile photo"
            style={{
              position: "absolute",
              bottom: -2,
              right: -2,
              width: 22,
              height: 22,
              borderRadius: "50%",
              background: uploadingPhoto
                ? "var(--accent-amber)"
                : "var(--olive)",
              border: "2px solid #fff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: uploadingPhoto ? "default" : "pointer",
              padding: 0,
            }}
          >
            {uploadingPhoto ? (
              <div
                className="spinner"
                style={{
                  width: 10,
                  height: 10,
                  borderColor: "rgba(255,255,255,0.3)",
                  borderTopColor: "#fff",
                }}
              />
            ) : (
              <Camera size={11} color="#fff" />
            )}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: "none" }}
            onChange={handlePhotoUpload}
          />
        </div>
        <div>
          <h3 style={{ fontWeight: 700, fontSize: 16 }}>{profile?.name}</h3>
          <p className="text-sm text-muted">{profile?.email}</p>
          <span
            className={`badge badge-${profile?.role === "admin" ? "amber" : "blue"}`}
            style={{ marginTop: 4 }}
          >
            {profile?.role}
          </span>
          {uploadingPhoto ? (
            <p
              style={{
                fontSize: 11,
                color: "var(--accent-amber)",
                marginTop: 6,
                fontWeight: 600,
              }}
            >
              {uploadProgress || "Processing…"}
            </p>
          ) : (
            <p
              style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 6 }}
            >
              Click the camera icon to update your photo
            </p>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="page-tab-bar" style={{ marginBottom: 20 }}>
        {(isAdmin ? TABS.filter((t) => !['security', 'updates', 'admin'].includes(t.id)) : TABS).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              padding: "10px 16px",
              border: "none",
              borderBottom:
                activeTab === tab.id
                  ? "2px solid var(--olive)"
                  : "2px solid transparent",
              background: "none",
              color:
                activeTab === tab.id
                  ? "var(--olive-light)"
                  : "var(--text-muted)",
              fontFamily: "var(--font-main)",
              fontSize: 14,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s",
              position: "relative",
              bottom: -1,
            }}
          >
            <tab.icon size={14} />
            {tab.label}
            {tab.id === "notifications" && unread > 0 && (
              <span className="nav-badge">{unread}</span>
            )}
            {tab.id === "updates" && upd.needRefresh && (
              <span className="nav-badge" title="Update available">1</span>
            )}
          </button>
        ))}
      </div>

      </>
      )}

      {/* Profile tab */}
      {activeTab === "profile" && (
        <div className="card">
          <h3 style={{ fontWeight: 700, marginBottom: 20 }}>
            Personal Information
          </h3>
          <form onSubmit={saveProfile}>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                className="form-input"
                value={form.name}
                onChange={(e) =>
                  setForm((p) => ({ ...p, name: e.target.value }))
                }
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input
                className="form-input"
                value={profile?.email || ""}
                disabled
                style={{ opacity: 0.5 }}
              />
              <p className="form-error" style={{ color: "var(--text-muted)" }}>
                Email cannot be changed here
              </p>
            </div>
            <div className="form-group">
              <label className="form-label">Phone Number (optional)</label>
              <input
                className="form-input"
                value={form.phone}
                onChange={(e) =>
                  setForm((p) => ({ ...p, phone: e.target.value }))
                }
                placeholder="+254 700 000 000"
              />
            </div>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? (
                <div className="spinner" style={{ width: 14, height: 14 }} />
              ) : (
                <Save size={14} />
              )}
              Save Changes
            </button>
          </form>
        </div>
      )}

      {/* Notifications tab */}
      {activeTab === "notifications" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* ── EMAIL PREFERENCES CARD ── */}
          <div className="card">
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                marginBottom: 18,
              }}
            >
              <div
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 9,
                  background: "rgba(26,36,114,0.08)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Mail size={16} style={{ color: "var(--navy-light)" }} />
              </div>
              <div>
                <h3 style={{ fontWeight: 700, fontSize: 15 }}>
                  Email Notifications
                </h3>
                <p
                  style={{
                    fontSize: 12,
                    color: "var(--text-muted)",
                    marginTop: 1,
                  }}
                >
                  Sent to <strong>{profile?.email}</strong>
                </p>
              </div>
            </div>

            {/* Master toggle */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "12px 14px",
                borderRadius: 10,
                background: emailPrefs.email_notifications_enabled
                  ? "rgba(90,138,30,0.06)"
                  : "var(--bg-elevated)",
                border: `1px solid ${emailPrefs.email_notifications_enabled ? "rgba(90,138,30,0.2)" : "var(--border)"}`,
                marginBottom: 14,
                cursor: "pointer",
              }}
              onClick={() => toggleEmailPref("email_notifications_enabled")}
            >
              <div>
                <p
                  style={{
                    fontWeight: 700,
                    fontSize: 14,
                    color: "var(--text-primary)",
                  }}
                >
                  {emailPrefs.email_notifications_enabled
                    ? "🔔 Email alerts ON"
                    : "🔕 Email alerts OFF"}
                </p>
                <p
                  style={{
                    fontSize: 12,
                    color: "var(--text-muted)",
                    marginTop: 2,
                  }}
                >
                  {emailPrefs.email_notifications_enabled
                    ? "You will receive important notifications by email"
                    : "No emails will be sent — in-app only"}
                </p>
              </div>
              {emailPrefs.email_notifications_enabled ? (
                <ToggleRight
                  size={28}
                  style={{ color: "var(--olive)", flexShrink: 0 }}
                />
              ) : (
                <ToggleLeft
                  size={28}
                  style={{ color: "var(--text-muted)", flexShrink: 0 }}
                />
              )}
            </div>

            {/* Per-type toggles */}
            {emailPrefs.email_notifications_enabled && (
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 2,
                  marginBottom: 16,
                }}
              >
                {[
                  {
                    key: "notify_on_deposits",
                    label: "Deposits & contributions",
                    emoji: "💰",
                    desc: "When any member deposits funds",
                  },
                  {
                    key: "notify_on_withdrawals",
                    label: "Withdrawal approvals",
                    emoji: "💸",
                    desc: "Approval requests and outcomes",
                  },
                  {
                    key: "notify_on_investments",
                    label: "Investment updates",
                    emoji: "📈",
                    desc: "New investments, returns, dividends",
                  },
                  {
                    key: "notify_on_governance",
                    label: "Governance votes",
                    emoji: "🗳️",
                    desc: "Proposals requiring your vote",
                  },
                ].map(({ key, label, emoji, desc }) => (
                  <div
                    key={key}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: "10px 12px",
                      borderRadius: 8,
                      cursor: "pointer",
                      transition: "background 0.12s",
                    }}
                    onClick={() => toggleEmailPref(key)}
                    onMouseEnter={(e) =>
                      (e.currentTarget.style.background = "var(--bg-elevated)")
                    }
                    onMouseLeave={(e) =>
                      (e.currentTarget.style.background = "transparent")
                    }
                  >
                    <div
                      style={{ display: "flex", alignItems: "center", gap: 10 }}
                    >
                      <span style={{ fontSize: 16, flexShrink: 0 }}>
                        {emoji}
                      </span>
                      <div>
                        <p
                          style={{
                            fontSize: 13,
                            fontWeight: 600,
                            color: "var(--text-primary)",
                          }}
                        >
                          {label}
                        </p>
                        <p style={{ fontSize: 11, color: "var(--text-muted)" }}>
                          {desc}
                        </p>
                      </div>
                    </div>
                    {emailPrefs[key] ? (
                      <ToggleRight
                        size={22}
                        style={{ color: "var(--olive)", flexShrink: 0 }}
                      />
                    ) : (
                      <ToggleLeft
                        size={22}
                        style={{ color: "var(--text-muted)", flexShrink: 0 }}
                      />
                    )}
                  </div>
                ))}
              </div>
            )}

            <button
              className="btn btn-primary btn-sm"
              onClick={saveEmailPrefs}
              disabled={savingEmailPrefs}
              style={{ width: "100%", justifyContent: "center" }}
            >
              {savingEmailPrefs ? (
                <>
                  <div className="spinner" style={{ width: 13, height: 13 }} />{" "}
                  Saving…
                </>
              ) : (
                <>
                  <Save size={13} /> Save Email Preferences
                </>
              )}
            </button>
          </div>

          {/* ── IN-APP NOTIFICATION LIST ── */}
          <div className="card">
            {/* Header */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
                flexWrap: "wrap",
                gap: 8,
                marginBottom: 14,
              }}
            >
              <h3 style={{ fontWeight: 700 }}>
                In-App Notifications
                {notifView === "mine" && unread > 0 && (
                  <span className="badge badge-red" style={{ marginLeft: 8 }}>
                    {unread} new
                  </span>
                )}
                {notifView === "all" && (
                  <span className="badge badge-blue" style={{ marginLeft: 8 }}>
                    {allNotifications.length} total
                  </span>
                )}
              </h3>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => {
                    fetchNotifications();
                    if (isAdmin) fetchAllNotifications();
                  }}
                  disabled={loadingNotif}
                >
                  <RefreshCw
                    size={12}
                    style={{
                      animation: loadingNotif
                        ? "spin 0.7s linear infinite"
                        : "none",
                    }}
                  />{" "}
                  Refresh
                </button>
                {notifView === "mine" && unread > 0 && (
                  <button
                    className="btn btn-secondary btn-sm"
                    onClick={markAllRead}
                  >
                    <Check size={13} /> Mark all read
                  </button>
                )}
                {isAdmin &&
                  notifView === "mine" &&
                  notifications.length > 0 && (
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={clearAllNotifications}
                    >
                      🗑️ Clear Mine
                    </button>
                  )}
              </div>
            </div>

            {/* Admin view toggle */}
            {isAdmin && (
              <div
                style={{
                  display: "flex",
                  gap: 4,
                  marginBottom: 14,
                  borderBottom: "1px solid var(--border)",
                  paddingBottom: 0,
                }}
              >
                {[
                  ["mine", "👤 My Notifications"],
                  ["all", "👥 All Members"],
                ].map(([v, label]) => (
                  <button
                    key={v}
                    onClick={() => {
                      setNotifView(v);
                      if (v === "all") fetchAllNotifications();
                    }}
                    style={{
                      padding: "7px 14px",
                      border: "none",
                      background: "none",
                      cursor: "pointer",
                      fontFamily: "var(--font-main)",
                      fontSize: 13,
                      fontWeight: 600,
                      borderBottom:
                        notifView === v
                          ? "2px solid var(--olive)"
                          : "2px solid transparent",
                      color:
                        notifView === v ? "var(--olive)" : "var(--text-muted)",
                      position: "relative",
                      bottom: -1,
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}

            {/* ── ALL MEMBERS VIEW (admin only) ── */}
            {isAdmin && notifView === "all" && (
              <>
                {/* Member filter + clear all */}
                <div
                  style={{
                    display: "flex",
                    gap: 8,
                    marginBottom: 12,
                    flexWrap: "wrap",
                    alignItems: "center",
                  }}
                >
                  <select
                    className="form-select"
                    style={{ flex: 1 }}
                    value={filterMember}
                    onChange={(e) => setFilterMember(e.target.value)}
                  >
                    <option value="">
                      All Members ({allNotifications.length})
                    </option>
                    {[
                      ...new Map(
                        allNotifications.map((n) => [n.user_id, n.member_name]),
                      ).entries(),
                    ].map(([uid, name]) => (
                      <option key={uid} value={uid}>
                        {name} (
                        {
                          allNotifications.filter((n) => n.user_id === uid)
                            .length
                        }
                        )
                      </option>
                    ))}
                  </select>
                  {filterMember && (
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => {
                        const name =
                          allNotifications.find(
                            (n) => n.user_id === filterMember,
                          )?.member_name || "member";
                        clearMemberNotifications(filterMember, name);
                      }}
                    >
                      🗑️ Clear{" "}
                      {
                        allNotifications
                          .find((n) => n.user_id === filterMember)
                          ?.member_name?.split(" ")[0]
                      }
                      's
                    </button>
                  )}
                </div>

                {loadingNotif ? (
                  <div className="flex justify-center" style={{ padding: 32 }}>
                    <div
                      className="spinner"
                      style={{ width: 24, height: 24 }}
                    />
                  </div>
                ) : allNotifications.filter(
                    (n) => !filterMember || n.user_id === filterMember,
                  ).length === 0 ? (
                  <div className="empty-state">
                    <Bell size={32} style={{ opacity: 0.3 }} />
                    <p>No notifications</p>
                  </div>
                ) : (
                  <div
                    style={{ display: "flex", flexDirection: "column", gap: 6 }}
                  >
                    {allNotifications
                      .filter(
                        (n) => !filterMember || n.user_id === filterMember,
                      )
                      .map((n) => (
                        <div
                          key={n.id}
                          style={{
                            padding: "10px 12px",
                            borderRadius: 8,
                            background: n.is_read
                              ? "var(--bg-elevated)"
                              : "rgba(122,140,58,0.05)",
                            border: `1px solid ${n.is_read ? "var(--border)" : "rgba(122,140,58,0.2)"}`,
                            display: "flex",
                            alignItems: "flex-start",
                            gap: 10,
                          }}
                        >
                          {/* Member avatar */}
                          <div
                            style={{
                              width: 30,
                              height: 30,
                              borderRadius: "50%",
                              background: "var(--bg-hover)",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              fontSize: 12,
                              fontWeight: 700,
                              color: "var(--text-secondary)",
                              flexShrink: 0,
                            }}
                          >
                            {n.member_name?.charAt(0) || "?"}
                          </div>
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div
                              style={{
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "flex-start",
                                gap: 6,
                                flexWrap: "wrap",
                              }}
                            >
                              <div>
                                <span
                                  style={{
                                    fontSize: 11,
                                    fontWeight: 700,
                                    color: "var(--text-muted)",
                                    marginRight: 6,
                                  }}
                                >
                                  {n.member_name?.split(" ")[0]}
                                </span>
                                <span
                                  style={{
                                    fontSize: 13,
                                    fontWeight: n.is_read ? 500 : 700,
                                  }}
                                >
                                  {n.title}
                                </span>
                              </div>
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 6,
                                  flexShrink: 0,
                                }}
                              >
                                {!n.is_read && (
                                  <div
                                    style={{
                                      width: 7,
                                      height: 7,
                                      borderRadius: "50%",
                                      background: "var(--olive)",
                                    }}
                                  />
                                )}
                                <span onClick={(e) => e.stopPropagation()}>
                                  <AdminActions
                                    onDelete={() => deleteAnyNotification(n.id)}
                                    size="xs"
                                  />
                                </span>
                              </div>
                            </div>
                            <p
                              style={{
                                fontSize: 12,
                                color: "var(--text-muted)",
                                marginTop: 2,
                              }}
                            >
                              {n.message}
                            </p>
                            <p
                              style={{
                                fontSize: 10,
                                color: "var(--text-muted)",
                                marginTop: 4,
                              }}
                            >
                              {formatDateTime(n.created_at)}
                            </p>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </>
            )}

            {/* ── MY NOTIFICATIONS VIEW ── */}
            {notifView === "mine" && (
              <>
                {loadingNotif ? (
                  <div className="flex justify-center" style={{ padding: 32 }}>
                    <div
                      className="spinner"
                      style={{ width: 24, height: 24 }}
                    />
                  </div>
                ) : notifications.length === 0 ? (
                  <div className="empty-state">
                    <Bell size={32} style={{ opacity: 0.3 }} />
                    <p>No notifications yet</p>
                  </div>
                ) : (
                  <div
                    style={{ display: "flex", flexDirection: "column", gap: 8 }}
                  >
                    {notifications.map((n) => {
                      const isApproval = n.type === "approval";
                      const hasLink = !!n.action_url;

                      const handleCardClick = async () => {
                        if (!n.is_read) await markRead(n.id);
                      };

                      const handleReviewClick = async (e) => {
                        e.stopPropagation();
                        if (!n.is_read) await markRead(n.id);
                        if (n.action_url) navigate(n.action_url);
                      };

                      return (
                        <div
                          key={n.id}
                          onClick={handleCardClick}
                          style={{
                            padding: 14,
                            borderRadius: 10,
                            cursor: "pointer",
                            background: n.is_read
                              ? "transparent"
                              : isApproval
                                ? "rgba(230,144,10,0.06)"
                                : "rgba(122,140,58,0.05)",
                            border: `1px solid ${n.is_read ? "var(--border)" : isApproval ? "rgba(230,144,10,0.22)" : "rgba(122,140,58,0.15)"}`,
                            transition: "all 0.15s",
                          }}
                        >
                          <div className="flex items-start gap-3">
                            <span style={{ fontSize: 18, flexShrink: 0 }}>
                              {getNotifIcon(n.type)}
                            </span>
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div className="flex justify-between items-start gap-2">
                                <p
                                  style={{
                                    fontWeight: n.is_read ? 500 : 700,
                                    fontSize: 14,
                                    color: n.is_read
                                      ? "var(--text-secondary)"
                                      : "var(--text-primary)",
                                  }}
                                >
                                  {n.title}
                                </p>
                                <div
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 6,
                                    flexShrink: 0,
                                  }}
                                >
                                  {!n.is_read && (
                                    <div
                                      style={{
                                        width: 8,
                                        height: 8,
                                        borderRadius: "50%",
                                        background: isApproval
                                          ? "var(--accent-amber)"
                                          : "var(--olive)",
                                        flexShrink: 0,
                                      }}
                                    />
                                  )}
                                  {hasLink && (
                                    <button
                                      onClick={handleReviewClick}
                                      style={{
                                        fontSize: 11,
                                        color: "var(--olive)",
                                        fontWeight: 600,
                                        display: "flex",
                                        alignItems: "center",
                                        gap: 3,
                                        background: "none",
                                        border: "none",
                                        cursor: "pointer",
                                        padding: "2px 0",
                                        fontFamily: "var(--font-main)",
                                      }}
                                    >
                                      <ExternalLink size={11} /> Review
                                    </button>
                                  )}
                                  {isAdmin && (
                                    <span onClick={(e) => e.stopPropagation()}>
                                      <AdminActions
                                        onDelete={() =>
                                          deleteNotification(n.id)
                                        }
                                        size="xs"
                                      />
                                    </span>
                                  )}
                                </div>
                              </div>
                              <p
                                style={{
                                  fontSize: 13,
                                  color: "var(--text-muted)",
                                  marginTop: 2,
                                }}
                              >
                                {n.message}
                              </p>
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 8,
                                  marginTop: 6,
                                }}
                              >
                                <p className="text-xs text-muted">
                                  {formatDateTime(n.created_at)}
                                </p>
                                {n.email_sent && (
                                  <span
                                    style={{
                                      display: "inline-flex",
                                      alignItems: "center",
                                      gap: 3,
                                      fontSize: 10,
                                      fontWeight: 600,
                                      color: "var(--navy-light)",
                                      background: "rgba(58,77,181,0.08)",
                                      border: "1px solid rgba(58,77,181,0.15)",
                                      borderRadius: 99,
                                      padding: "1px 7px",
                                    }}
                                  >
                                    <Mail size={9} /> emailed
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* Security tab */}
      {activeTab === "security" && (
        <div className="card">
          <h3 style={{ fontWeight: 700, marginBottom: 20 }}>Change Password</h3>
          <form onSubmit={changePassword}>
            <div className="form-group">
              <label className="form-label">New Password</label>
              <input
                className="form-input"
                type="password"
                value={pwForm.newPw}
                onChange={(e) =>
                  setPwForm((p) => ({ ...p, newPw: e.target.value }))
                }
                placeholder="At least 8 characters"
                required
                minLength={8}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Confirm New Password</label>
              <input
                className="form-input"
                type="password"
                value={pwForm.confirm}
                onChange={(e) =>
                  setPwForm((p) => ({ ...p, confirm: e.target.value }))
                }
                placeholder="Repeat new password"
                required
              />
            </div>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? (
                <div className="spinner" style={{ width: 14, height: 14 }} />
              ) : (
                <Lock size={14} />
              )}
              Update Password
            </button>
          </form>

          <div className="divider" />
          <h3 style={{ fontWeight: 700, marginBottom: 12 }}>
            Account Information
          </h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {[
              {
                label: "Account ID",
                value: profile?.id?.substring(0, 18) + "…",
              },
              { label: "Role", value: profile?.role },
              {
                label: "Member Since",
                value: profile?.created_at
                  ? new Date(profile.created_at).toLocaleDateString()
                  : "—",
              },
            ].map((item) => (
              <div
                key={item.label}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  padding: "8px 0",
                  borderBottom: "1px solid var(--border)",
                }}
              >
                <span className="text-sm text-secondary">{item.label}</span>
                <span className="text-sm text-mono">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Admin tab */}
      {activeTab === "updates" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: 16 }}>App version</h3>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 28, marginBottom: 18 }}>
              <div>
                <div style={updLabel}>Version</div>
                <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "var(--font-mono)" }}>v{upd.version}</div>
              </div>
              <div>
                <div style={updLabel}>Built</div>
                <div style={{ fontSize: 14, marginTop: 4 }}>{upd.buildTime ? formatDateTime(upd.buildTime) : "—"}</div>
              </div>
              <div>
                <div style={updLabel}>Running as</div>
                <div style={{ fontSize: 14, marginTop: 4 }}>{isStandaloneApp() ? "Installed app" : "Web browser"}</div>
              </div>
            </div>

            {upd.needRefresh ? (
              <div style={{ background: "rgba(90,138,30,0.10)", border: "1px solid rgba(90,138,30,0.35)", borderRadius: 12, padding: 16, display: "flex", flexWrap: "wrap", alignItems: "center", gap: 12 }}>
                <RefreshCw size={18} style={{ color: "var(--olive)", flexShrink: 0 }} />
                <div style={{ flex: "1 1 220px" }}>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{upd.reason === "activated" ? "Nitalink was just updated" : "A new version is ready"}</div>
                  <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 2 }}>
                    {upd.reason === "activated" ? "Reload to start using the new version. Nothing has been reloaded for you." : "Updating reloads the app. Finish anything you are typing first."}
                  </div>
                </div>
                <button className="btn btn-primary btn-sm" onClick={upd.applyUpdate} disabled={upd.applying}>
                  {upd.applying ? "Updating…" : upd.reason === "activated" ? "Reload now" : "Update now"}
                </button>
              </div>
            ) : !upd.supported ? (
              <div style={{ background: "var(--bg-elevated)", border: "1px solid var(--border)", borderRadius: 12, padding: 16, fontSize: 13, color: "var(--text-secondary)" }}>
                Automatic updates are not active here (this is a development build, or your browser does not support
                installable apps). Reload the page to get the latest version.
                <div style={{ marginTop: 10 }}>
                  <button className="btn btn-secondary btn-sm" onClick={() => window.location.reload()}>Reload page</button>
                </div>
              </div>
            ) : (
              <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 14, color: "var(--accent-emerald)", fontWeight: 600 }}>
                <Check size={18} /> You are on the latest version
                {upd.lastChecked && (
                  <span style={{ color: "var(--text-muted)", fontWeight: 400, fontSize: 12 }}>
                    · last checked {upd.lastChecked.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                )}
              </div>
            )}

            <div style={{ marginTop: 18 }}>
              <button
                className="btn btn-secondary btn-sm"
                onClick={handleCheckUpdate}
                disabled={upd.checking || upd.applying}
                style={{ display: "inline-flex", alignItems: "center", gap: 6 }}
              >
                {upd.checking ? <div className="spinner" style={{ width: 12, height: 12 }} /> : <RefreshCw size={13} />}
                {upd.checking ? "Checking…" : "Check for updates"}
              </button>
            </div>
            {isAdmin && (
            <details style={{ marginTop: 18 }}>
              <summary style={{ cursor: "pointer", fontSize: 12, color: "var(--text-muted)" }}>Technical details</summary>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, lineHeight: 1.7, marginTop: 8, color: "var(--text-secondary)" }}>
                <div>Offline support: {upd.sw.controlled ? "active on this page" : "not active on this page yet"}</div>
                <div>Update waiting: {upd.sw.waiting ? "yes" : "no"}</div>
                {upd.events.length === 0 ? <div>No update activity recorded yet.</div> : upd.events.map((e, i) => <div key={i}>{e}</div>)}
              </div>
            </details>
            )}
          </div>

          {isAdmin && (
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: 12 }}>How updates work</h3>
            <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, lineHeight: 1.7, color: "var(--text-secondary)" }}>
              <li>Nitalink looks for a new version automatically every 30 minutes and whenever you come back to the app.</li>
              <li>When one is ready, a banner appears at the top of the page. Tap <strong>Update now</strong> when it suits you.</li>
              <li>Updating reloads the app, so save any form you are filling in first. You stay signed in.</li>
              <li>On an iPhone or iPad and the update does not show? Close the app fully from the app switcher and open it again.</li>
            </ul>
          </div>
          )}

          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: 8 }}>Having trouble?</h3>
            <p style={{ margin: "0 0 12px", fontSize: 13, color: "var(--text-secondary)" }}>
              If the app looks out of date or stuck after an update, reset its cached files. You will stay signed in.
            </p>
            <button className="btn btn-secondary btn-sm" onClick={handleResetCache}>Reset app cache</button>
          </div>
        </div>
      )}

      {activeTab === "admin" && isAdmin && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* =============================== */}
          {/* 📣 BROADCAST NOTIFICATION */}
          {/* =============================== */}
          <div className="card">
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                marginBottom: 16,
              }}
            >
              <Bell size={16} style={{ color: "var(--olive)" }} />
              <h3 style={{ fontWeight: 700, fontSize: 15 }}>
                Send System Notification
              </h3>
            </div>

            <form onSubmit={sendBroadcastNotification}>
              {/* TITLE */}
              <div className="form-group">
                <label className="form-label">Title</label>
                <input
                  className="form-input"
                  value={broadcastForm.title}
                  onChange={(e) =>
                    setBroadcastForm((p) => ({ ...p, title: e.target.value }))
                  }
                  placeholder="e.g. System Update"
                  required
                />
              </div>

              {/* MESSAGE */}
              <div className="form-group">
                <label className="form-label">Message</label>
                <textarea
                  className="form-input"
                  rows="3"
                  value={broadcastForm.message}
                  onChange={(e) =>
                    setBroadcastForm((p) => ({ ...p, message: e.target.value }))
                  }
                  placeholder="Write announcement..."
                  required
                />
              </div>

              {/* TARGET USERS */}
              <div className="form-group">
                <label className="form-label">Send To</label>
                <select
                  className="form-select"
                  value={broadcastForm.target}
                  onChange={(e) =>
                    setBroadcastForm((p) => ({ ...p, target: e.target.value }))
                  }
                >
                  <option value="all">All Users</option>
                  <option value="admins">Admins Only</option>
                  <option value="members">Members Only</option>
                </select>
              </div>

              {/* ACTION LINK */}
              <div className="form-group">
                <label className="form-label">Action URL (optional)</label>
                <input
                  className="form-input"
                  value={broadcastForm.action_url}
                  onChange={(e) =>
                    setBroadcastForm((p) => ({
                      ...p,
                      action_url: e.target.value,
                    }))
                  }
                  placeholder="https://finance.geotreks.co.ke"
                />
              </div>

              {/* SEND BUTTON */}
              <button
                type="submit"
                className="btn btn-primary"
                disabled={sendingBroadcast}
                style={{ width: "100%", justifyContent: "center" }}
              >
                {sendingBroadcast ? (
                  <>
                    <div
                      className="spinner"
                      style={{ width: 14, height: 14 }}
                    />
                    Sending...
                  </>
                ) : (
                  <>
                    <Mail size={14} />
                    Send Notification to Users
                  </>
                )}
              </button>
            </form>
          </div>
          {/* System notification sender (admin only) */}
          {/* <div className="card">
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                marginBottom: 16,
              }}
            >
              <Bell size={16} style={{ color: "var(--olive)" }} />
              <h3 style={{ fontWeight: 700, fontSize: 15 }}>
                Send System Notification
              </h3>
            </div>

            <form onSubmit={sendSystemNotification}>
              <div className="form-group">
                <label className="form-label">Title</label>
                <input
                  className="form-input"
                  value={notifForm.title}
                  onChange={(e) =>
                    setNotifForm((p) => ({ ...p, title: e.target.value }))
                  }
                  placeholder="e.g. System Maintenance Update"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Message</label>
                <textarea
                  className="form-input"
                  rows="3"
                  value={notifForm.message}
                  onChange={(e) =>
                    setNotifForm((p) => ({ ...p, message: e.target.value }))
                  }
                  placeholder="Write your announcement..."
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Action URL (optional)</label>
                <input
                  className="form-input"
                  value={notifForm.action_url}
                  onChange={(e) =>
                    setNotifForm((p) => ({ ...p, action_url: e.target.value }))
                  }
                  placeholder="https://finance.geotreks.co.ke"
                />
              </div>

              <button
                type="submit"
                className="btn btn-primary"
                disabled={sendingNotif}
                style={{ width: "100%", justifyContent: "center" }}
              >
                {sendingNotif ? (
                  <>
                    <div
                      className="spinner"
                      style={{ width: 14, height: 14 }}
                    />
                    Sending...
                  </>
                ) : (
                  <>
                    <Mail size={14} />
                    Send to All Members
                  </>
                )}
              </button>
            </form>
          </div> */}

          {/* //END NEW ADDTIONS */}
          {/* Register new user */}
          <div className="card">
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                marginBottom: 18,
              }}
            >
              <UserPlus size={16} style={{ color: "var(--olive)" }} />
              <h3 style={{ fontWeight: 700, fontSize: 15 }}>
                Register New Member
              </h3>
            </div>
            <div
              style={{
                background: "rgba(90,138,30,0.07)",
                border: "1px solid rgba(90,138,30,0.2)",
                borderRadius: 8,
                padding: 10,
                marginBottom: 16,
                fontSize: 13,
                color: "var(--text-secondary)",
              }}
            >
              ℹ️ Creates a Supabase auth account and member profile. The new
              member can log in immediately with the credentials you set. If
              email confirmation is enabled in Supabase, they must confirm their
              email first.
            </div>
            <form onSubmit={handleRegisterUser}>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Full Name *</label>
                  <input
                    className="form-input"
                    value={inviteForm.name}
                    onChange={(e) =>
                      setInviteForm((p) => ({ ...p, name: e.target.value }))
                    }
                    placeholder="e.g. Jane Wanjiru"
                    required
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Role</label>
                  <select
                    className="form-select"
                    value={inviteForm.role}
                    onChange={(e) =>
                      setInviteForm((p) => ({ ...p, role: e.target.value }))
                    }
                  >
                    <option value="member">Member</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Email Address *</label>
                <input
                  className="form-input"
                  type="email"
                  value={inviteForm.email}
                  onChange={(e) =>
                    setInviteForm((p) => ({ ...p, email: e.target.value }))
                  }
                  placeholder="jane@fundex.app"
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">
                  Initial Password * (min 8 chars)
                </label>
                <input
                  className="form-input"
                  type="password"
                  value={inviteForm.password}
                  onChange={(e) =>
                    setInviteForm((p) => ({ ...p, password: e.target.value }))
                  }
                  placeholder="Strong password — share securely with the member"
                  minLength={8}
                  required
                />
              </div>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={inviting}
              >
                {inviting ? (
                  <>
                    <div
                      className="spinner"
                      style={{ width: 14, height: 14 }}
                    />{" "}
                    Registering…
                  </>
                ) : (
                  <>
                    <UserPlus size={14} /> Register Member
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Registration history */}
          {invitations.length > 0 && (
            <div className="card">
              <h3 style={{ fontWeight: 700, marginBottom: 14, fontSize: 15 }}>
                Registration History
              </h3>
              <div className="table-container">
                <table>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Role</th>
                      <th>Registered</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invitations.map((inv) => (
                      <tr key={inv.id}>
                        <td style={{ fontWeight: 600, fontSize: 13 }}>
                          {inv.name}
                        </td>
                        <td className="text-sm text-secondary">{inv.email}</td>
                        <td>
                          <span
                            className={`badge badge-${inv.role === "admin" ? "amber" : "blue"}`}
                          >
                            {inv.role}
                          </span>
                        </td>
                        <td className="text-xs text-muted">
                          {new Date(inv.created_at).toLocaleDateString()}
                        </td>
                        <td>
                          <span
                            className={`badge badge-${inv.accepted_at ? "green" : inv.expires_at && new Date(inv.expires_at) < new Date() ? "red" : "amber"}`}
                          >
                            {inv.accepted_at
                              ? "Registered"
                              : new Date(inv.expires_at) < new Date()
                                ? "Expired"
                                : "Pending"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Scheduled reminders */}
          <div className="card">
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                marginBottom: 16,
              }}
            >
              <Shield size={15} style={{ color: "var(--olive)" }} />
              <h3 style={{ fontWeight: 700, fontSize: 15 }}>
                Scheduled Automations
              </h3>
            </div>
            {loadingAdmin ? (
              <div className="flex justify-center" style={{ padding: 24 }}>
                <div className="spinner" style={{ width: 20, height: 20 }} />
              </div>
            ) : reminders.length === 0 ? (
              <p style={{ fontSize: 13, color: "var(--text-muted)" }}>
                No scheduled reminders configured. Run migration 008 to set them
                up.
              </p>
            ) : (
              <div
                style={{ display: "flex", flexDirection: "column", gap: 10 }}
              >
                {reminders.map((r) => {
                  const labels = {
                    monthly_contribution: {
                      title: "📅 Monthly Contribution Reminder",
                      desc: "Notifies all members to make their monthly contribution",
                    },
                    snapshot: {
                      title: "📸 Auto Ownership Snapshot",
                      desc: "Automatically snapshots ownership percentages for record-keeping",
                    },
                    report: {
                      title: "📊 Monthly Summary Report",
                      desc: "Generates and stores a monthly financial summary insight",
                    },
                  };
                  const cfg = labels[r.reminder_type] || {
                    title: r.reminder_type,
                    desc: "",
                  };
                  return (
                    <div
                      key={r.id}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        padding: "12px 14px",
                        background: "var(--bg-elevated)",
                        borderRadius: 8,
                        border: "1px solid var(--border)",
                        gap: 12,
                        flexWrap: "wrap",
                      }}
                    >
                      <div style={{ flex: 1, minWidth: 160 }}>
                        <p style={{ fontSize: 13, fontWeight: 700 }}>
                          {cfg.title}
                        </p>
                        <p
                          style={{
                            fontSize: 11,
                            color: "var(--text-muted)",
                            marginTop: 2,
                          }}
                        >
                          {cfg.desc}
                        </p>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                          flexShrink: 0,
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 6,
                          }}
                        >
                          <span
                            style={{ fontSize: 11, color: "var(--text-muted)" }}
                          >
                            Day of month:
                          </span>
                          <input
                            type="number"
                            min="1"
                            max="28"
                            value={r.day_of_month}
                            onChange={(e) =>
                              updateReminderDay(r.id, e.target.value)
                            }
                            style={{
                              width: 48,
                              padding: "4px 8px",
                              borderRadius: 6,
                              border: "1px solid var(--border)",
                              background: "var(--bg-surface)",
                              color: "var(--text-primary)",
                              fontSize: 13,
                              fontFamily: "var(--font-mono)",
                              textAlign: "center",
                            }}
                          />
                        </div>
                        <label
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 6,
                            cursor: "pointer",
                          }}
                        >
                          <div
                            onClick={() => toggleReminder(r)}
                            style={{
                              width: 36,
                              height: 20,
                              borderRadius: 99,
                              cursor: "pointer",
                              background: r.is_active
                                ? "var(--olive)"
                                : "var(--bg-elevated)",
                              border: `1px solid ${r.is_active ? "var(--olive)" : "var(--border)"}`,
                              position: "relative",
                              transition: "background 0.2s",
                            }}
                          >
                            <div
                              style={{
                                width: 14,
                                height: 14,
                                borderRadius: "50%",
                                background: "#fff",
                                position: "absolute",
                                top: 2,
                                left: r.is_active ? 18 : 2,
                                transition: "left 0.2s",
                              }}
                            />
                          </div>
                          <span
                            style={{
                              fontSize: 12,
                              color: r.is_active
                                ? "var(--olive)"
                                : "var(--text-muted)",
                              fontWeight: 600,
                            }}
                          >
                            {r.is_active ? "On" : "Off"}
                          </span>
                        </label>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
