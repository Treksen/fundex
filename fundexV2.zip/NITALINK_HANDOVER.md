# Nitalink — handover for a new chat (as of 19 Nov 2026)

Nitalink (formerly Fundex) is a group savings and investment web app: Vite + React PWA on Supabase
(Postgres, Auth, Edge Functions, Resend email). Paste this note into the new chat and attach a zip of the
current project folder WITHOUT `node_modules` and WITHOUT `.env.local`.

## Current state
- App version 1.5.1. Do not change the version unless asked.
- Bundles applied in this order on top of fundexv6: fundex_v6_fixes, nitalink_branding, nitalink_email_text,
  nitalink_updates, nitalink_updates_fix, nitalink_members_fix, nitalink_reports, nitalink_security, nitalink_admin_nav.
- Migrations added: 023-030 (deposit verification, back-fill, notifications, reject, 90-day bank-code window),
  031 correct bank code, 032 error logs, 033 protect profiles (security fix).
- Edge functions: send-email-notification (index.ts is live; index2.ts is NOT deployed, see below),
  send-scheduled-reminders (needs a daily Supabase cron), admin-create-member (new, admins add members server-side).
- Tests (from project root): `node tests/nav/nav.test.mjs`, `node tests/security/run.mjs`,
  `node tests/reports/run.mjs`, and `tests/updateController.test.mjs` (copy src/lib/updateController.js next to it as
  updateController.mjs). 113 checks, all passing on 19 Nov.

## Must confirm (security)
1. 033_check_for_abuse.sql was run and every admin/recent account is recognised.
2. 033_protect_profiles.sql then 033_verify.sql were run: PASS 1-5 (PASS 6 only with exactly one admin).
3. Public sign-ups turned OFF (after admin-create-member is deployed).
4. Auth > URL configuration has the site URL and `<domain>/reset-password` as a redirect URL.
5. Custom SMTP set up (built-in Supabase email is for testing only), otherwise reset emails may not arrive.
6. Rotate the Supabase service-role key (it was inside the uploaded zip in `.env.local`).

## Known issues
- Deleting a member fails for anyone with history: transactions.user_id, notifications.user_id,
  withdrawal_approvals.approver_id and others reference profiles with no ON DELETE rule. The confirm text
  ("transactions are preserved but unlinked") is wrong. Even when it succeeds, the member's login keeps working.
- `BRIDGE_RELEASE = true` in vite.config.js is temporary: keep for this release and the next, then set false.
- index2.ts (not deployed) skips emails of type 'info' (back-fill, bank-code-corrected, others' verified/rejected).
- Error Log is only fed by ErrorBoundary, AuditPage and ReportsPage; failed RPCs elsewhere only toast.
- `.gitignore` excludes `supabase/`, so migrations and edge functions are not in version control.
- Migration folder has duplicate 017/019 files with " (1)"/" (2)" in their names; the Supabase CLI won't push these.
- Both public/manifest.webmanifest and the vite-plugin-pwa manifest exist (minor).

## Next feature: admin tools for members (designed, not built)
- Disable / re-enable a login, send a reset email, set a temporary password (shown once, never stored,
  forced change at next sign-in), change role (last-admin guard already in 033), edit details.
- Replace "delete" with "deactivate" so financial history is kept.
- Admin re-enters own password for sensitive actions; every action audit-logged; the member is notified;
  an admin cannot reset another admin's account.
- Withdrawal approvals: process_withdrawal_approval completes only when EVERY approval row is approved,
  so a deactivated member's pending vote would block withdrawals forever. Deactivation must remove or skip
  their pending approval rows and re-check affected withdrawals.
- Will NOT build: any way to view members' current passwords.

## Waiting on the owner
- Monthly report email: send day/time, summary+link vs PDF attachment, can members opt out.
- Reports: export one real PDF and Excel so the layout can be tuned (layout never seen rendered).
- M-Pesa (KCB Buni, shared paybill 522522, account 1351460749): needs Buni sandbox credentials and
  decisions (defaults proposed: keep admin verification, phone from profile and editable, admins can trigger
  for others, deposits only). Correct KCB field names: phoneNumber, invoiceNumber, sharedShortCode,
  orgShortCode, orgPassKey, callbackUrl, transactionDescription. Test with KES 1 that money lands on the account.
- Trademark/name check for "Nitalink" in Kenya before investing in branding.
