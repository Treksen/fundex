-- ============================================================
-- Migration 026: Back-fill Notifications
-- ------------------------------------------------------------
-- When an admin retroactively stamps an old completed deposit
-- with a bank verification code via backfill_deposit_verification(),
-- the status stays 'completed' — so the existing trigger
-- notify_members_on_deposit() (fires on status transition to
-- completed) does NOT fire.
--
-- This migration adds a separate trigger that fires whenever
-- bank_verification_code transitions from NULL to a value on an
-- already-completed deposit. It fans out the same kind of
-- notification messages as a fresh verification (depositor gets
-- a personal "Your Deposit Verified" message; everyone else
-- gets a group "X's deposit verified" message), but framed as a
-- record-keeping update rather than as "the pool was updated"
-- (because the pool was already updated long ago).
--
-- Emails go out automatically via the existing Resend webhook
-- on the notifications table.
--
-- Run after 025.
-- ============================================================


CREATE OR REPLACE FUNCTION notify_members_on_backfill()
RETURNS TRIGGER AS $$
DECLARE
  v_depositor_name   TEXT;
  v_depositor_first  TEXT;
  v_verifier_name    TEXT;
  v_verifier_first   TEXT;
  v_member           RECORD;
  v_amount_str       TEXT;
BEGIN
  -- Guard rails. We only act when:
  --   * It's a deposit
  --   * The row is (and was) status='completed' — so this is
  --     truly a back-fill, NOT a fresh verification (which
  --     transitions pending_verification → completed and is
  --     handled by notify_members_on_deposit instead).
  --   * bank_verification_code transitioned NULL → not-null
  --   * verified_by is populated (sanity)
  IF NEW.type <> 'deposit' THEN RETURN NEW; END IF;
  IF NEW.status <> 'completed' THEN RETURN NEW; END IF;
  IF OLD IS NULL THEN RETURN NEW; END IF;
  IF OLD.status <> 'completed' THEN RETURN NEW; END IF;
  IF NEW.bank_verification_code IS NULL THEN RETURN NEW; END IF;
  IF OLD.bank_verification_code IS NOT NULL THEN RETURN NEW; END IF;
  IF NEW.verified_by IS NULL THEN RETURN NEW; END IF;

  -- Names
  SELECT name INTO v_depositor_name FROM profiles WHERE id = NEW.user_id;
  v_depositor_first := SPLIT_PART(v_depositor_name, ' ', 1);

  SELECT name INTO v_verifier_name FROM profiles WHERE id = NEW.verified_by;
  v_verifier_first := SPLIT_PART(v_verifier_name, ' ', 1);

  v_amount_str := 'KES ' || TO_CHAR(NEW.amount, 'FM999,999,999.00');

  FOR v_member IN SELECT id FROM profiles LOOP
    IF v_member.id = NEW.user_id THEN
      -- Personal note to the depositor
      INSERT INTO notifications
        (user_id, title, message, type, action_url, metadata)
      VALUES (
        v_member.id,
        '🧾 Bank Reference Added to Your Deposit',
        v_verifier_first || ' added the bank verification code for your earlier deposit of ' ||
          v_amount_str || ' (Bank ref: ' || NEW.bank_verification_code ||
          '). Your equity is unchanged — this is a record-keeping update for the bank reconciliation.',
        'info',
        '/transactions',
        jsonb_build_object(
          'transaction_id', NEW.id,
          'amount',         NEW.amount,
          'bank_ref',       NEW.bank_verification_code,
          'kind',           'backfill'
        )
      )
      ON CONFLICT DO NOTHING;
    ELSE
      -- Group update
      INSERT INTO notifications
        (user_id, title, message, type, action_url, metadata)
      VALUES (
        v_member.id,
        '🧾 Bank Reference Back-filled',
        v_verifier_name || ' added the bank verification code for ' ||
          v_depositor_name || '''s earlier deposit of ' || v_amount_str ||
          ' (Bank ref: ' || NEW.bank_verification_code ||
          '). No change to balances — this is for reconciliation only.',
        'info',
        '/transactions',
        jsonb_build_object(
          'transaction_id', NEW.id,
          'depositor_id',   NEW.user_id,
          'amount',         NEW.amount,
          'bank_ref',       NEW.bank_verification_code,
          'kind',           'backfill'
        )
      )
      ON CONFLICT DO NOTHING;
    END IF;
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


DROP TRIGGER IF EXISTS trg_backfill_notifications ON transactions;

CREATE TRIGGER trg_backfill_notifications
  AFTER UPDATE ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION notify_members_on_backfill();


GRANT EXECUTE ON FUNCTION notify_members_on_backfill() TO authenticated;


COMMENT ON FUNCTION notify_members_on_backfill() IS
  'Fires on UPDATE when bank_verification_code transitions NULL → not-null on an already-completed deposit. Sends record-keeping notifications (and emails via Resend) to depositor + all other members, clearly framed as a reconciliation update rather than a new pool change.';
