-- ============================================================
-- Migration 027: Members Can Back-fill Admin Deposits
-- ------------------------------------------------------------
-- Two problems being solved here:
--
-- 1. The original backfill_deposit_verification() RPC required
--    the caller to be an admin. That works for back-filling
--    member deposits, but FAILS for admin deposits in a single-
--    admin group (the only admin is the depositor, so dual-
--    control blocks them). And in a multi-admin group it locks
--    out the non-admin members even though, per the verify
--    workflow in migration 023, they SHOULD be allowed to act
--    on admin deposits.
--
--    Fix: mirror verify_deposit()'s dual-control rule —
--      depositor is admin     → ANY other member can back-fill
--      depositor is non-admin → only an admin can back-fill
--      depositor can never back-fill their own deposit
--
-- 2. The historical admin deposits that were created BEFORE
--    migration 026 never got a "back-fill needed" notification
--    fanned out, so members have no idea they can act. The
--    notify_members_on_backfill trigger only fires AFTER the
--    code is stamped — but we need members to be prompted
--    BEFORE that, so they know to do it in the first place.
--
--    Fix: a new notify_members_on_pending_backfill() that
--    inserts one "please back-fill this old deposit" notification
--    per eligible verifier, deduplicated by transaction. Then
--    a one-shot seed at the bottom calls it for every existing
--    completed deposit lacking a bank_verification_code.
--
-- Run after 026.
-- ============================================================


-- ── 1. RELAX backfill_deposit_verification() ────────────────
-- Same behavior as before EXCEPT for the caller-role check.
-- Everything else (no overwrites, no duplicates, no self-back-
-- fill, status guard, audit log, auto-recon row) is unchanged.

CREATE OR REPLACE FUNCTION backfill_deposit_verification(
  p_transaction_id UUID,
  p_bank_code      TEXT
)
RETURNS JSONB AS $$
DECLARE
  v_tx              RECORD;
  v_caller_id       UUID := auth.uid();
  v_caller_role     TEXT;
  v_depositor_role  TEXT;
  v_dup_count       INT;
  v_recon_created   BOOLEAN := FALSE;
BEGIN
  IF v_caller_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
  END IF;

  IF p_bank_code IS NULL OR LENGTH(TRIM(p_bank_code)) = 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Bank verification code is required'
    );
  END IF;

  SELECT * INTO v_tx FROM transactions WHERE id = p_transaction_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Transaction not found');
  END IF;

  IF v_tx.type <> 'deposit' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only deposits can have a bank verification code'
    );
  END IF;

  IF v_tx.status = 'pending_verification' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'This deposit is awaiting verification. Use the normal Verify action instead.'
    );
  END IF;

  IF v_tx.status <> 'completed' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only completed deposits can be back-filled (current status: ' || v_tx.status || ')'
    );
  END IF;

  IF v_tx.bank_verification_code IS NOT NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'This deposit already has a bank verification code: ' || v_tx.bank_verification_code
    );
  END IF;

  IF v_tx.user_id = v_caller_id THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'You cannot back-fill your own deposit. Another member must do it.'
    );
  END IF;

  -- NEW dual-control rule (mirrors verify_deposit):
  SELECT role INTO v_caller_role    FROM profiles WHERE id = v_caller_id;
  SELECT role INTO v_depositor_role FROM profiles WHERE id = v_tx.user_id;

  IF v_depositor_role <> 'admin' AND v_caller_role <> 'admin' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only an admin can back-fill member deposits'
    );
  END IF;

  -- (If depositor IS admin, ANY other member may back-fill — no
  --  further check needed since v_caller_id <> v_tx.user_id is
  --  already guaranteed above.)

  SELECT COUNT(*) INTO v_dup_count
  FROM transactions
  WHERE bank_verification_code = TRIM(p_bank_code)
    AND id <> p_transaction_id;

  IF v_dup_count > 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'This bank verification code has already been used on another transaction'
    );
  END IF;

  UPDATE transactions
  SET bank_verification_code = TRIM(p_bank_code),
      verified_at            = NOW(),
      verified_by            = v_caller_id,
      updated_at             = NOW()
  WHERE id = p_transaction_id;

  IF NOT EXISTS (
    SELECT 1 FROM bank_reconciliations
    WHERE transaction_id = p_transaction_id
  ) THEN
    INSERT INTO bank_reconciliations (
      transaction_id,
      bank_date,
      bank_amount,
      bank_reference,
      bank_description,
      match_status,
      reconciled_by,
      reconciled_at
    ) VALUES (
      p_transaction_id,
      v_tx.transaction_date::DATE,
      v_tx.amount,
      TRIM(p_bank_code),
      'Back-filled bank verification for legacy deposit ' ||
        COALESCE(v_tx.statement_no, LEFT(p_transaction_id::TEXT, 8)),
      'matched',
      v_caller_id,
      NOW()
    );
    v_recon_created := TRUE;
  END IF;

  INSERT INTO audit_logs
    (user_id, action, table_name, record_id, new_values)
  VALUES (
    v_caller_id,
    'Back-filled bank verification (bank ref: ' || TRIM(p_bank_code) || ')',
    'transactions',
    p_transaction_id,
    jsonb_build_object(
      'bank_verification_code', TRIM(p_bank_code),
      'amount',                  v_tx.amount,
      'depositor_id',            v_tx.user_id,
      'recon_created',           v_recon_created
    )
  );

  RETURN jsonb_build_object(
    'success',        true,
    'transaction_id', p_transaction_id,
    'recon_created',  v_recon_created
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION backfill_deposit_verification(UUID, TEXT) TO authenticated;


-- ── 2. "PLEASE BACK-FILL THIS DEPOSIT" NOTIFICATION ─────────
-- Inserts one prompt-notification per eligible verifier for a
-- given pending-backfill transaction. Idempotent thanks to the
-- (user_id, metadata->>'transaction_id') uniqueness implicit in
-- the ON CONFLICT DO NOTHING and the kind='pending_backfill'
-- discriminator in metadata.
--
-- Eligible verifier set is the same as in verify_deposit /
-- backfill_deposit_verification:
--   depositor is admin     → every other member
--   depositor is non-admin → every admin (depositor excluded)
--
-- We do NOT fire this from a trigger — it's invoked manually
-- below as a one-shot seed for existing rows. Future back-fills
-- proceed directly (admin/member already knows what to do).

CREATE OR REPLACE FUNCTION notify_members_on_pending_backfill(
  p_transaction_id UUID
)
RETURNS INT AS $$
DECLARE
  v_tx              RECORD;
  v_depositor_name  TEXT;
  v_depositor_role  TEXT;
  v_amount_str      TEXT;
  v_verifier        RECORD;
  v_count           INT := 0;
BEGIN
  SELECT * INTO v_tx FROM transactions WHERE id = p_transaction_id;
  IF NOT FOUND THEN RETURN 0; END IF;
  IF v_tx.type <> 'deposit' THEN RETURN 0; END IF;
  IF v_tx.status <> 'completed' THEN RETURN 0; END IF;
  IF v_tx.bank_verification_code IS NOT NULL THEN RETURN 0; END IF;

  SELECT name, role
    INTO v_depositor_name, v_depositor_role
    FROM profiles WHERE id = v_tx.user_id;

  v_amount_str := 'KES ' || TO_CHAR(v_tx.amount, 'FM999,999,999.00');

  FOR v_verifier IN
    SELECT id
      FROM profiles
      WHERE id <> v_tx.user_id
        AND (
          v_depositor_role = 'admin'
          OR role = 'admin'
        )
  LOOP
    INSERT INTO notifications
      (user_id, title, message, type, action_url, metadata)
    VALUES (
      v_verifier.id,
      '🔎 Old Deposit Needs Bank Code',
      v_depositor_name || ' has an earlier deposit of ' || v_amount_str ||
        CASE
          WHEN v_tx.reference IS NOT NULL AND LENGTH(v_tx.reference) > 0
          THEN ' (Their ref: ' || v_tx.reference || ')'
          ELSE ''
        END ||
        ' that still needs its bank verification code added. ' ||
        'Tap to open and add the code from your bank statement.',
      'approval',
      '/transactions?pending=' || v_tx.id::TEXT,
      jsonb_build_object(
        'transaction_id', v_tx.id,
        'depositor_id',   v_tx.user_id,
        'amount',         v_tx.amount,
        'kind',           'pending_backfill'
      )
    )
    ON CONFLICT DO NOTHING;
    v_count := v_count + 1;
  END LOOP;

  RETURN v_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION notify_members_on_pending_backfill(UUID) TO authenticated;


-- ── 3. ONE-SHOT ROLLUP SEED FOR EXISTING UN-BACK-FILLED DEPOSITS ───
-- Instead of fanning out one notification per old deposit per
-- member (which could be dozens of emails per person), we send
-- ONE rollup notification per eligible recipient that says:
--   "There are N earlier deposits that still need bank codes.
--    Go to /transactions and look for the back-fill banner."
--
-- Subsequent new admin deposits will use the per-transaction
-- notify_members_on_pending_backfill() if the admin explicitly
-- calls it, but the standard verify flow (status starts as
-- pending_verification) means brand-new admin deposits are
-- already handled by mig 025's trg_pending_verification_notifications.
-- So this rollup only exists to clear the historical backlog.

DO $$
DECLARE
  v_member               RECORD;
  v_total_pending        INT;
  v_total_for_member     INT;
  v_already_notified     INT;
BEGIN
  -- Total un-back-filled deposits in the system right now.
  SELECT COUNT(*) INTO v_total_pending
    FROM transactions
    WHERE type   = 'deposit'
      AND status = 'completed'
      AND bank_verification_code IS NULL;

  IF v_total_pending = 0 THEN
    RAISE NOTICE 'No un-back-filled deposits — skipping rollup seed';
    RETURN;
  END IF;

  -- For each profile, count how many of those deposits THEY
  -- are eligible to back-fill. A member is eligible when:
  --   * They are not the depositor, AND
  --   * Either the depositor is admin OR they themselves are admin.
  FOR v_member IN SELECT id, role FROM profiles LOOP
    SELECT COUNT(*) INTO v_total_for_member
      FROM transactions t
      JOIN profiles      dep ON dep.id = t.user_id
      WHERE t.type   = 'deposit'
        AND t.status = 'completed'
        AND t.bank_verification_code IS NULL
        AND t.user_id <> v_member.id
        AND (dep.role = 'admin' OR v_member.role = 'admin');

    IF v_total_for_member = 0 THEN CONTINUE; END IF;

    -- Skip if we've already sent this member a rollup
    -- notification (i.e. migration is being re-run).
    SELECT COUNT(*) INTO v_already_notified
      FROM notifications
      WHERE user_id = v_member.id
        AND (metadata->>'kind') = 'pending_backfill_rollup';

    IF v_already_notified > 0 THEN CONTINUE; END IF;

    INSERT INTO notifications
      (user_id, title, message, type, action_url, metadata)
    VALUES (
      v_member.id,
      '🔎 ' || v_total_for_member::TEXT || ' Deposit' ||
        CASE WHEN v_total_for_member = 1 THEN '' ELSE 's' END ||
        ' Need Bank Codes',
      'There ' ||
        CASE WHEN v_total_for_member = 1 THEN 'is 1 earlier deposit' ELSE 'are ' || v_total_for_member::TEXT || ' earlier deposits' END ||
        ' that still need bank verification codes added. ' ||
        'Open the Transactions page and look for the blue "needs back-fill" banner — ' ||
        'tap any row''s "Add Code" button to confirm the deposit against your bank statement.',
      'approval',
      '/transactions',
      jsonb_build_object(
        'count', v_total_for_member,
        'kind',  'pending_backfill_rollup'
      )
    );
  END LOOP;

  RAISE NOTICE 'Rollup seed: % total un-back-filled deposit(s)', v_total_pending;
END;
$$;


-- ── COMMENTS ────────────────────────────────────────────────
COMMENT ON FUNCTION backfill_deposit_verification(UUID, TEXT) IS
  'Admin-only for member deposits; ANY non-depositor member for admin deposits. Stamps bank code on a completed deposit without changing status. Mirrors verify_deposit''s dual-control rule.';
COMMENT ON FUNCTION notify_members_on_pending_backfill(UUID) IS
  'Fans out an in-app + email notification to every member eligible to back-fill the given deposit. Idempotent across re-runs. Used for one-shot seeding of historical un-back-filled rows.';
