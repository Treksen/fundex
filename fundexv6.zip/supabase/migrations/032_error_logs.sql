-- ============================================================
-- Migration 032: Error Logs
-- ------------------------------------------------------------
-- Captures frontend and backend errors in a persistent table
-- so admins can review, filter, and mark them resolved.
--
-- Sources:
--   * Frontend: caught JS exceptions, failed RPC calls, failed
--     Supabase queries — written via the log_error() RPC or
--     directly from the client using the service-role path
--     in the logError() JS utility.
--   * Backend: DB-level errors can call log_error() directly
--     from PL/pgSQL using PERFORM log_error(...).
--
-- Severity levels: 'info' | 'warning' | 'error' | 'critical'
--
-- RLS:
--   * INSERT: any authenticated user (so members can report
--     their own errors too)
--   * SELECT / UPDATE: admin only
--   * DELETE: admin only
--
-- Run after 031.
-- ============================================================


-- ── TABLE ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS error_logs (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Who was logged in when the error happened (NULL = unauthenticated)
  user_id         UUID REFERENCES profiles(id) ON DELETE SET NULL,

  -- Severity: info | warning | error | critical
  severity        TEXT NOT NULL DEFAULT 'error'
                  CHECK (severity IN ('info', 'warning', 'error', 'critical')),

  -- Where the error came from: 'frontend' | 'rpc' | 'trigger' | 'edge_function' | 'other'
  source          TEXT NOT NULL DEFAULT 'frontend'
                  CHECK (source IN ('frontend', 'rpc', 'trigger', 'edge_function', 'other')),

  -- Page or component where the error occurred (e.g. 'TransactionsPage', 'verify_deposit')
  context         TEXT,

  -- Short one-liner (shown in the table)
  message         TEXT NOT NULL,

  -- Full error details: stack trace, response body, etc.
  details         JSONB,

  -- HTTP status or Supabase error code if applicable
  error_code      TEXT,

  -- Admin triage fields
  resolved        BOOLEAN NOT NULL DEFAULT FALSE,
  resolved_at     TIMESTAMPTZ,
  resolved_by     UUID REFERENCES profiles(id) ON DELETE SET NULL,
  resolution_note TEXT
);

-- Indexes for the admin list view
CREATE INDEX IF NOT EXISTS idx_error_logs_created_at  ON error_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_error_logs_severity    ON error_logs(severity);
CREATE INDEX IF NOT EXISTS idx_error_logs_resolved    ON error_logs(resolved);
CREATE INDEX IF NOT EXISTS idx_error_logs_user_id     ON error_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_error_logs_source      ON error_logs(source);


-- ── RLS ─────────────────────────────────────────────────────
ALTER TABLE error_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can insert error logs"
  ON error_logs FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Admins can view error logs"
  ON error_logs FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can update error logs"
  ON error_logs FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can delete error logs"
  ON error_logs FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );


-- ── RPC: log_error() ────────────────────────────────────────
-- Callable from both PL/pgSQL (PERFORM log_error(...)) and
-- from the frontend (supabase.rpc('log_error', {...})).
-- Returns the new error_log id on success.

CREATE OR REPLACE FUNCTION log_error(
  p_message    TEXT,
  p_context    TEXT    DEFAULT NULL,
  p_details    JSONB   DEFAULT NULL,
  p_severity   TEXT    DEFAULT 'error',
  p_source     TEXT    DEFAULT 'frontend',
  p_error_code TEXT    DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
  v_id UUID;
BEGIN
  INSERT INTO error_logs
    (user_id, severity, source, context, message, details, error_code)
  VALUES (
    auth.uid(),
    COALESCE(p_severity, 'error'),
    COALESCE(p_source, 'frontend'),
    p_context,
    COALESCE(p_message, 'Unknown error'),
    p_details,
    p_error_code
  )
  RETURNING id INTO v_id;

  RETURN v_id;
EXCEPTION WHEN OTHERS THEN
  -- Never let error-logging itself crash the caller
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION log_error(TEXT, TEXT, JSONB, TEXT, TEXT, TEXT) TO authenticated;


-- ── RPC: resolve_error() ─────────────────────────────────────
-- Admin marks an error as resolved.

CREATE OR REPLACE FUNCTION resolve_error(
  p_error_id UUID,
  p_note     TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
  v_caller_role TEXT;
BEGIN
  SELECT role INTO v_caller_role FROM profiles WHERE id = auth.uid();
  IF v_caller_role <> 'admin' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Admin only');
  END IF;

  UPDATE error_logs
  SET resolved      = TRUE,
      resolved_at   = NOW(),
      resolved_by   = auth.uid(),
      resolution_note = p_note
  WHERE id = p_error_id AND resolved = FALSE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Error log not found or already resolved');
  END IF;

  RETURN jsonb_build_object('success', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION resolve_error(UUID, TEXT) TO authenticated;


-- ── RPC: reopen_error() ──────────────────────────────────────
-- Admin re-opens a resolved error.

CREATE OR REPLACE FUNCTION reopen_error(p_error_id UUID)
RETURNS JSONB AS $$
DECLARE
  v_caller_role TEXT;
BEGIN
  SELECT role INTO v_caller_role FROM profiles WHERE id = auth.uid();
  IF v_caller_role <> 'admin' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Admin only');
  END IF;

  UPDATE error_logs
  SET resolved = FALSE, resolved_at = NULL, resolved_by = NULL, resolution_note = NULL
  WHERE id = p_error_id;

  RETURN jsonb_build_object('success', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION reopen_error(UUID) TO authenticated;


COMMENT ON TABLE error_logs IS
  'Persistent error log for admin review. Frontend and backend errors are written here via log_error(). Admins can filter, resolve, and clear entries.';
