-- ============================================================
-- Migration 025: Verification-Aware Notifications
-- ------------------------------------------------------------
-- Two changes:
--
-- A) NEW trigger function notify_verifiers_on_pending_deposit()
--    fires when a deposit is INSERTED with status =
--    'pending_verification'. It picks the set of users allowed
--    to verify (admins for member deposits, other members for
--    admin deposits) and inserts one notification per verifier.
--    The existing Resend email webhook on the notifications
--    table will then email each of them automatically.
--
-- B) REPLACE notify_members_on_deposit() with a version that
--    enriches the message when a bank verification code and
--    verifier are present (i.e. the deposit was just verified).
--    For non-verified completed deposits (e.g. adjustments or
--    edge-case manual completions) it falls back to the
--    original wording.
--
-- Run after 023 (which adds the columns we read here) and 024.
-- ============================================================


-- ── A. PENDING-VERIFICATION FAN-OUT ─────────────────────────
CREATE OR REPLACE FUNCTION notify_verifiers_on_pending_deposit()
RETURNS TRIGGER AS $$
DECLARE
  v_depositor_name   TEXT;
  v_depositor_first  TEXT;
  v_depositor_role   TEXT;
  v_verifier         RECORD;
  v_amount_str       TEXT;
  v_ref_clause       TEXT;
BEGIN
  -- Only act on pending_verification deposits, only on INSERT
  -- (the transition pending_verification → completed is handled
  -- by the existing notify_members_on_deposit trigger).
  IF NEW.type <> 'deposit' THEN RETURN NEW; END IF;
  IF NEW.status <> 'pending_verification' THEN RETURN NEW; END IF;

  SELECT name, role
    INTO v_depositor_name, v_depositor_role
    FROM profiles
    WHERE id = NEW.user_id;

  v_depositor_first := SPLIT_PART(v_depositor_name, ' ', 1);
  v_amount_str      := 'KES ' || TO_CHAR(NEW.amount, 'FM999,999,999.00');
  v_ref_clause      := CASE
                         WHEN NEW.reference IS NOT NULL AND LENGTH(NEW.reference) > 0
                         THEN ' (Their ref: ' || NEW.reference || ')'
                         ELSE ''
                       END;

  -- Pick verifier set:
  --   depositor is admin     → every OTHER member
  --   depositor is non-admin → every admin (excluding depositor,
  --                            which is already enforced by role)
  FOR v_verifier IN
    SELECT id, name
      FROM profiles
      WHERE id <> NEW.user_id
        AND (
          v_depositor_role = 'admin'        -- any other member
          OR role = 'admin'                 -- member deposit → admins only
        )
  LOOP
    INSERT INTO notifications
      (user_id, title, message, type, action_url, metadata)
    VALUES (
      v_verifier.id,
      '🕓 Deposit Awaiting Verification',
      v_depositor_name || ' recorded a deposit of ' || v_amount_str ||
        '.' || v_ref_clause ||
        ' Please confirm the funds in the group bank account and add' ||
        ' the bank verification code.',
      'approval',
      '/transactions?pending=' || NEW.id::TEXT,
      jsonb_build_object(
        'transaction_id', NEW.id,
        'depositor_id',   NEW.user_id,
        'amount',         NEW.amount,
        'kind',           'pending_verification'
      )
    )
    ON CONFLICT DO NOTHING;
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_pending_verification_notifications ON transactions;

CREATE TRIGGER trg_pending_verification_notifications
  AFTER INSERT ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION notify_verifiers_on_pending_deposit();

GRANT EXECUTE ON FUNCTION notify_verifiers_on_pending_deposit() TO authenticated;


-- ── B. ENRICH COMPLETED-DEPOSIT NOTIFICATION ───────────────
-- Replaces the body of notify_members_on_deposit() to include
-- the verifier's name and the bank verification code when the
-- deposit was just verified. Trigger attachment stays the same.

CREATE OR REPLACE FUNCTION notify_members_on_deposit()
RETURNS TRIGGER AS $$
DECLARE
  v_depositor_name   TEXT;
  v_depositor_first  TEXT;
  v_verifier_name    TEXT;
  v_verifier_first   TEXT;
  v_member           RECORD;
  v_stmt_no          TEXT;
  v_amount_str       TEXT;
  v_was_verified     BOOLEAN;
  v_title_dep        TEXT;
  v_msg_dep          TEXT;
  v_title_grp        TEXT;
  v_msg_grp          TEXT;
BEGIN
  IF NEW.type <> 'deposit' THEN RETURN NEW; END IF;
  IF NEW.status <> 'completed' THEN RETURN NEW; END IF;
  IF OLD IS NOT NULL AND OLD.status = 'completed' THEN RETURN NEW; END IF;

  SELECT name INTO v_depositor_name FROM profiles WHERE id = NEW.user_id;
  v_depositor_first := SPLIT_PART(v_depositor_name, ' ', 1);
  v_stmt_no    := COALESCE(NEW.statement_no, LEFT(NEW.id::TEXT, 8));
  v_amount_str := 'KES ' || TO_CHAR(NEW.amount, 'FM999,999,999.00');

  -- Was this completion the result of a verification?
  v_was_verified := NEW.bank_verification_code IS NOT NULL
                    AND NEW.verified_by IS NOT NULL
                    AND (OLD IS NULL OR OLD.status = 'pending_verification');

  IF v_was_verified THEN
    SELECT name INTO v_verifier_name FROM profiles WHERE id = NEW.verified_by;
    v_verifier_first := SPLIT_PART(v_verifier_name, ' ', 1);

    v_title_dep := '✅ Your Deposit Verified';
    v_msg_dep   := v_verifier_first || ' verified your deposit of ' ||
                   v_amount_str || '. Bank reference: ' ||
                   NEW.bank_verification_code ||
                   '. It now counts toward the group pool.';

    v_title_grp := '💰 ' || v_depositor_first || '''s deposit verified';
    v_msg_grp   := v_depositor_name || '''s deposit of ' || v_amount_str ||
                   ' has been verified by ' || v_verifier_name ||
                   ' (Bank ref: ' || NEW.bank_verification_code || ').' ||
                   ' The pool has been updated.';
  ELSE
    -- Legacy / non-verified completion (e.g. data fix). Use
    -- the original wording so behavior is unchanged.
    v_title_dep := '✅ Deposit Confirmed';
    v_msg_dep   := 'Your deposit of ' || v_amount_str ||
                   ' (Ref: ' || v_stmt_no ||
                   ') has been recorded successfully.';

    v_title_grp := '💰 ' || v_depositor_first || ' made a deposit';
    v_msg_grp   := v_depositor_name || ' deposited ' || v_amount_str ||
                   ' into the group pool (Ref: ' || v_stmt_no || '). ' ||
                   'The pool has been updated.';
  END IF;

  FOR v_member IN SELECT id FROM profiles LOOP
    IF v_member.id = NEW.user_id THEN
      INSERT INTO notifications
        (user_id, title, message, type, action_url, metadata)
      VALUES (
        v_member.id,
        v_title_dep,
        v_msg_dep,
        'success',
        '/transactions',
        jsonb_build_object(
          'transaction_id', NEW.id,
          'amount',         NEW.amount,
          'verified',       v_was_verified,
          'bank_ref',       NEW.bank_verification_code
        )
      )
      ON CONFLICT DO NOTHING;
    ELSE
      INSERT INTO notifications
        (user_id, title, message, type, action_url, metadata)
      VALUES (
        v_member.id,
        v_title_grp,
        v_msg_grp,
        'info',
        '/transactions',
        jsonb_build_object(
          'transaction_id', NEW.id,
          'depositor_id',   NEW.user_id,
          'amount',         NEW.amount,
          'verified',       v_was_verified,
          'bank_ref',       NEW.bank_verification_code
        )
      )
      ON CONFLICT DO NOTHING;
    END IF;
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION notify_members_on_deposit() TO authenticated;


-- ── COMMENTS ────────────────────────────────────────────────
COMMENT ON FUNCTION notify_verifiers_on_pending_deposit() IS
  'Fires on INSERT of a deposit with status=pending_verification. Notifies admins (or other members, if depositor is admin) so they can review and stamp the bank verification code. Emails go out via the existing Resend webhook on the notifications table.';
COMMENT ON FUNCTION notify_members_on_deposit() IS
  'Fires when a deposit transitions to status=completed. Sends an enriched message that mentions the verifier name and bank verification code when the completion was the result of verify_deposit().';
