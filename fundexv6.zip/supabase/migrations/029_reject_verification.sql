-- ============================================================
-- Migration 029: Reject a Pending Deposit Verification
-- ------------------------------------------------------------
-- Companion to verify_deposit. Lets a verifier mark a
-- pending_verification deposit as 'rejected' (e.g., funds
-- never arrived, suspicious reference, duplicate of another
-- deposit). The depositor + everyone else are notified.
--
-- Rules mirror verify_deposit:
--   * Deposit must currently be pending_verification
--   * Caller must NOT be the depositor
--   * Member deposits: only admins can reject
--   * Admin deposits: any other member can reject
--   * Rejection reason is required (audit trail)
--
-- Behavior:
--   * Sets status = 'rejected'
--   * Stamps verified_by + verified_at with the rejecter
--     (this is intentional — these columns now mean "decided by"
--      and "decided at" regardless of outcome)
--   * Saves the reason into description (prepended)
--   * Does NOT create a bank_reconciliations row
--   * Writes an audit log entry
--
-- The depositor can later either:
--   * Record a fresh deposit if the money does eventually
--     arrive (the rejected row remains for audit), OR
--   * An admin can re-open the row via the existing edit UI
--     by flipping status back to pending_verification.
--
-- Run after 028.
-- ============================================================


CREATE OR REPLACE FUNCTION reject_deposit_verification(
  p_transaction_id UUID,
  p_reason         TEXT
)
RETURNS JSONB AS $$
DECLARE
  v_tx               RECORD;
  v_caller_id        UUID := auth.uid();
  v_caller_role      TEXT;
  v_depositor_role   TEXT;
BEGIN
  IF v_caller_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
  END IF;

  IF p_reason IS NULL OR LENGTH(TRIM(p_reason)) < 5 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'A rejection reason of at least 5 characters is required'
    );
  END IF;

  SELECT * INTO v_tx FROM transactions WHERE id = p_transaction_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Transaction not found');
  END IF;

  IF v_tx.type <> 'deposit' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only deposits can be rejected via this action'
    );
  END IF;

  IF v_tx.status <> 'pending_verification' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'This deposit is not awaiting verification (status: ' || v_tx.status || ')'
    );
  END IF;

  IF v_tx.user_id = v_caller_id THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'You cannot reject your own deposit'
    );
  END IF;

  SELECT role INTO v_caller_role    FROM profiles WHERE id = v_caller_id;
  SELECT role INTO v_depositor_role FROM profiles WHERE id = v_tx.user_id;

  IF v_depositor_role <> 'admin' AND v_caller_role <> 'admin' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only an admin can reject member deposits'
    );
  END IF;

  UPDATE transactions
  SET status      = 'rejected',
      verified_by = v_caller_id,
      verified_at = NOW(),
      description = CASE
                      WHEN description IS NULL OR LENGTH(description) = 0
                      THEN 'REJECTED: ' || TRIM(p_reason)
                      ELSE 'REJECTED: ' || TRIM(p_reason) || E'\n\n--- original description ---\n' || description
                    END,
      updated_at  = NOW()
  WHERE id = p_transaction_id;

  -- Notifications: depositor, rejecter, bystanders all get different copy
  DECLARE
    v_depositor_name TEXT;
    v_rejecter_name  TEXT;
    v_amount_str     TEXT;
    v_member         RECORD;
    v_title          TEXT;
    v_msg            TEXT;
  BEGIN
    SELECT name INTO v_depositor_name FROM profiles WHERE id = v_tx.user_id;
    SELECT name INTO v_rejecter_name  FROM profiles WHERE id = v_caller_id;
    v_amount_str := 'KES ' || TO_CHAR(v_tx.amount, 'FM999,999,999.00');

    FOR v_member IN SELECT id FROM profiles LOOP
      IF v_member.id = v_tx.user_id THEN
        v_title := '❌ Your Deposit Was Rejected';
        v_msg   := v_rejecter_name || ' rejected your deposit of ' ||
                   v_amount_str || '. Reason: ' || TRIM(p_reason) ||
                   '. If the funds do show up later, please record a fresh deposit.';
      ELSIF v_member.id = v_caller_id THEN
        v_title := '❌ You Rejected a Deposit';
        v_msg   := 'You rejected ' || v_depositor_name || '''s deposit of ' ||
                   v_amount_str || '. Reason: ' || TRIM(p_reason) || '.';
      ELSE
        v_title := '❌ Deposit Rejected';
        v_msg   := v_rejecter_name || ' rejected ' || v_depositor_name ||
                   '''s deposit of ' || v_amount_str ||
                   '. Reason: ' || TRIM(p_reason) || '.';
      END IF;

      INSERT INTO notifications
        (user_id, title, message, type, action_url, metadata)
      VALUES (
        v_member.id,
        v_title,
        v_msg,
        CASE WHEN v_member.id = v_tx.user_id THEN 'warning' ELSE 'info' END,
        '/transactions',
        jsonb_build_object(
          'transaction_id', p_transaction_id,
          'depositor_id',   v_tx.user_id,
          'rejecter_id',    v_caller_id,
          'amount',         v_tx.amount,
          'reason',         TRIM(p_reason),
          'kind',           'verification_rejected'
        )
      )
      ON CONFLICT DO NOTHING;
    END LOOP;
  END;

  -- Audit
  INSERT INTO audit_logs
    (user_id, action, table_name, record_id, new_values)
  VALUES (
    v_caller_id,
    'Rejected deposit verification: ' || TRIM(p_reason),
    'transactions',
    p_transaction_id,
    jsonb_build_object(
      'amount',       v_tx.amount,
      'depositor_id', v_tx.user_id,
      'reason',       TRIM(p_reason)
    )
  );

  RETURN jsonb_build_object(
    'success',        true,
    'transaction_id', p_transaction_id,
    'status',         'rejected'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION reject_deposit_verification(UUID, TEXT) TO authenticated;

COMMENT ON FUNCTION reject_deposit_verification(UUID, TEXT) IS
  'Companion to verify_deposit. Marks a pending_verification deposit as rejected with a reason. Same dual-control rules apply. Reason is required (min 5 chars) and stored both in description (prefixed REJECTED:) and in the audit log.';
