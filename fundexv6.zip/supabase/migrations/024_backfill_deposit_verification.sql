-- ============================================================
-- Migration 024: Back-fill Bank Verification on Existing Deposits
-- ------------------------------------------------------------
-- Purpose:
--   Provide a safe, admin-only RPC for retroactively stamping
--   bank_verification_code onto OLD deposits that were inserted
--   before migration 023 introduced the verification workflow.
--
-- Important differences vs. verify_deposit():
--   * Old deposits are already status='completed'. We do NOT
--     change the status. No equity recalc, no notification
--     storm, no reserve skim re-fire — those have all already
--     happened for these transactions.
--   * No ownership_snapshots row is inserted (already there).
--   * We still optionally insert a MATCHED row into
--     bank_reconciliations so the back-filled deposit shows up
--     on the reconciliation page, matching the new-flow
--     behavior the user asked for.
--
-- Caller rules:
--   * Caller must be admin.
--   * Caller cannot back-fill their OWN deposit (same dual-
--     control idea as verify_deposit). Another admin or — in
--     groups with only one admin — that admin must accept the
--     restriction and ask a member to use verify_deposit()
--     instead. (See note below for the single-admin case.)
--   * Target deposit must:
--       - exist
--       - be type='deposit'
--       - have status='completed' (not pending_verification —
--         use verify_deposit for that)
--       - not already have a bank_verification_code (no
--         overwriting historical data without explicit force)
--   * Bank code must be non-empty and unique across all
--     transactions.
--
-- Returns JSONB { success, error?, transaction_id?, recon_created? }
-- ============================================================


CREATE OR REPLACE FUNCTION backfill_deposit_verification(
  p_transaction_id UUID,
  p_bank_code      TEXT
)
RETURNS JSONB AS $$
DECLARE
  v_tx            RECORD;
  v_caller_id     UUID := auth.uid();
  v_caller_role   TEXT;
  v_dup_count     INT;
  v_recon_created BOOLEAN := FALSE;
BEGIN
  -- 1. Auth
  IF v_caller_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
  END IF;

  SELECT role INTO v_caller_role FROM profiles WHERE id = v_caller_id;
  IF v_caller_role <> 'admin' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only an admin can back-fill historical deposits'
    );
  END IF;

  -- 2. Bank code required
  IF p_bank_code IS NULL OR LENGTH(TRIM(p_bank_code)) = 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Bank verification code is required'
    );
  END IF;

  -- 3. Load tx and validate state
  SELECT * INTO v_tx FROM transactions WHERE id = p_transaction_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Transaction not found');
  END IF;

  IF v_tx.type <> 'deposit' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only deposits can have a bank verification code'
    );
  END IF;

  IF v_tx.status = 'pending_verification' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'This deposit is awaiting verification. Use the normal Verify action instead.'
    );
  END IF;

  IF v_tx.status <> 'completed' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only completed deposits can be back-filled (current status: ' || v_tx.status || ')'
    );
  END IF;

  IF v_tx.bank_verification_code IS NOT NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'This deposit already has a bank verification code: ' || v_tx.bank_verification_code
    );
  END IF;

  -- 4. Dual control: admin can't back-fill their own deposit
  IF v_tx.user_id = v_caller_id THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'You cannot back-fill your own deposit. Another admin must do it.'
    );
  END IF;

  -- 5. Uniqueness of bank code
  SELECT COUNT(*) INTO v_dup_count
  FROM transactions
  WHERE bank_verification_code = TRIM(p_bank_code)
    AND id <> p_transaction_id;

  IF v_dup_count > 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'This bank verification code has already been used on another transaction'
    );
  END IF;

  -- 6. Stamp the columns. Status stays 'completed' so no
  --    downstream trigger re-fires equity / reserve / notif.
  UPDATE transactions
  SET bank_verification_code = TRIM(p_bank_code),
      verified_at            = NOW(),
      verified_by            = v_caller_id,
      updated_at             = NOW()
  WHERE id = p_transaction_id;

  -- 7. Insert matched bank_reconciliations row only if none
  --    exists for this transaction yet.
  IF NOT EXISTS (
    SELECT 1 FROM bank_reconciliations
    WHERE transaction_id = p_transaction_id
  ) THEN
    INSERT INTO bank_reconciliations (
      transaction_id,
      bank_date,
      bank_amount,
      bank_reference,
      bank_description,
      match_status,
      reconciled_by,
      reconciled_at
    ) VALUES (
      p_transaction_id,
      v_tx.transaction_date::DATE,
      v_tx.amount,
      TRIM(p_bank_code),
      'Back-filled bank verification for legacy deposit ' ||
        COALESCE(v_tx.statement_no, LEFT(p_transaction_id::TEXT, 8)),
      'matched',
      v_caller_id,
      NOW()
    );
    v_recon_created := TRUE;
  END IF;

  -- 8. Audit log
  INSERT INTO audit_logs
    (user_id, action, table_name, record_id, new_values)
  VALUES (
    v_caller_id,
    'Back-filled bank verification (bank ref: ' || TRIM(p_bank_code) || ')',
    'transactions',
    p_transaction_id,
    jsonb_build_object(
      'bank_verification_code', TRIM(p_bank_code),
      'amount',                  v_tx.amount,
      'depositor_id',            v_tx.user_id,
      'recon_created',           v_recon_created
    )
  );

  RETURN jsonb_build_object(
    'success',        true,
    'transaction_id', p_transaction_id,
    'recon_created',  v_recon_created
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION backfill_deposit_verification(UUID, TEXT) TO authenticated;

COMMENT ON FUNCTION backfill_deposit_verification(UUID, TEXT) IS
  'Admin-only retroactive stamp of bank_verification_code onto a deposit that was created before migration 023. Does not change status or re-fire downstream triggers. Inserts a matched bank_reconciliations row if absent.';


-- ============================================================
-- NOTE ON SINGLE-ADMIN GROUPS:
-- If your group has only one admin and that admin has historical
-- deposits of their own to back-fill, the dual-control rule above
-- will block them. In that case, run the following as a one-off
-- in the Supabase SQL editor (replacing the placeholders):
--
--   SELECT backfill_deposit_verification(
--     '<tx_id_uuid>'::UUID,
--     '<bank_code>'
--   );
--
-- ... won't work for self, but a direct UPDATE will:
--
--   UPDATE transactions
--      SET bank_verification_code = '<bank_code>',
--          verified_at            = NOW(),
--          verified_by            = '<other_member_uuid>'::UUID,
--          updated_at             = NOW()
--    WHERE id = '<tx_id_uuid>'::UUID
--      AND bank_verification_code IS NULL;
--
-- Then optionally INSERT the matching bank_reconciliations row
-- by hand. Document this in your audit trail externally.
-- ============================================================
