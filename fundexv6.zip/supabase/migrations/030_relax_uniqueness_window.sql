-- ============================================================
-- Migration 030: 90-day Bank-Code Uniqueness Window
-- ------------------------------------------------------------
-- Until now, verify_deposit and backfill_deposit_verification
-- rejected ANY bank_verification_code that appeared on any
-- other transaction in the entire history. This is too strict:
--   * M-Pesa transaction IDs wrap and reuse after some months.
--   * Many bank reference schemes are sequential per-day so a
--     code from 2 years ago can legitimately appear again today.
--
-- This migration replaces the uniqueness check in both RPCs
-- with "no other transaction in the last 90 days has the same
-- bank_verification_code". The window is intentionally generous
-- so genuine duplicates (same admin pasting the same code twice
-- within a verification session) are still caught.
--
-- Run after 029.
-- ============================================================


-- ── verify_deposit ──────────────────────────────────────────
CREATE OR REPLACE FUNCTION verify_deposit(
  p_transaction_id UUID,
  p_bank_code      TEXT
)
RETURNS JSONB AS $$
DECLARE
  v_tx               RECORD;
  v_caller_id        UUID := auth.uid();
  v_caller_role      TEXT;
  v_depositor_role   TEXT;
  v_dup_count        INT;
  v_grand_total      DECIMAL;
BEGIN
  IF v_caller_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
  END IF;

  IF p_bank_code IS NULL OR LENGTH(TRIM(p_bank_code)) = 0 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Bank verification code is required');
  END IF;

  SELECT * INTO v_tx FROM transactions WHERE id = p_transaction_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Transaction not found');
  END IF;

  IF v_tx.type <> 'deposit' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Only deposits can be verified');
  END IF;

  IF v_tx.status <> 'pending_verification' THEN
    RETURN jsonb_build_object('success', false, 'error',
      'Transaction is not awaiting verification (current status: ' || v_tx.status || ')');
  END IF;

  IF v_tx.user_id = v_caller_id THEN
    RETURN jsonb_build_object('success', false, 'error',
      'You cannot verify your own deposit. Another member must verify it.');
  END IF;

  SELECT role INTO v_caller_role    FROM profiles WHERE id = v_caller_id;
  SELECT role INTO v_depositor_role FROM profiles WHERE id = v_tx.user_id;

  IF v_depositor_role <> 'admin' AND v_caller_role <> 'admin' THEN
    RETURN jsonb_build_object('success', false, 'error',
      'Only an admin can verify member deposits');
  END IF;

  -- 90-day uniqueness window
  SELECT COUNT(*) INTO v_dup_count
  FROM transactions
  WHERE bank_verification_code = TRIM(p_bank_code)
    AND id <> p_transaction_id
    AND verified_at >= NOW() - INTERVAL '90 days';

  IF v_dup_count > 0 THEN
    RETURN jsonb_build_object('success', false, 'error',
      'This bank verification code was already used on another transaction within the last 90 days');
  END IF;

  UPDATE transactions
  SET status                  = 'completed',
      bank_verification_code  = TRIM(p_bank_code),
      verified_at             = NOW(),
      verified_by             = v_caller_id,
      updated_at              = NOW()
  WHERE id = p_transaction_id;

  SELECT COALESCE(SUM(amount), 0) INTO v_grand_total
  FROM transactions
  WHERE type = 'deposit' AND status = 'completed';

  IF v_grand_total > 0 THEN
    INSERT INTO ownership_snapshots
      (user_id, percentage, total_contribution, transaction_id)
    SELECT
      op.id,
      COALESCE(op.ownership_pct, 0),
      COALESCE(op.total_deposits, 0),
      p_transaction_id
    FROM ownership_percentages op;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM bank_reconciliations
    WHERE transaction_id = p_transaction_id
  ) THEN
    INSERT INTO bank_reconciliations (
      transaction_id, bank_date, bank_amount,
      bank_reference, bank_description,
      match_status, reconciled_by, reconciled_at
    ) VALUES (
      p_transaction_id,
      v_tx.transaction_date::DATE,
      v_tx.amount,
      TRIM(p_bank_code),
      'Auto-imported on verification of deposit ' ||
        COALESCE(v_tx.statement_no, LEFT(p_transaction_id::TEXT, 8)),
      'matched',
      v_caller_id,
      NOW()
    );
  END IF;

  INSERT INTO audit_logs
    (user_id, action, table_name, record_id, new_values)
  VALUES (
    v_caller_id,
    'Verified deposit (bank ref: ' || TRIM(p_bank_code) || ')',
    'transactions',
    p_transaction_id,
    jsonb_build_object(
      'bank_verification_code', TRIM(p_bank_code),
      'amount',                  v_tx.amount,
      'depositor_id',            v_tx.user_id
    )
  );

  RETURN jsonb_build_object(
    'success',        true,
    'transaction_id', p_transaction_id,
    'status',         'completed'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ── backfill_deposit_verification ───────────────────────────
CREATE OR REPLACE FUNCTION backfill_deposit_verification(
  p_transaction_id UUID,
  p_bank_code      TEXT
)
RETURNS JSONB AS $$
DECLARE
  v_tx              RECORD;
  v_caller_id       UUID := auth.uid();
  v_caller_role     TEXT;
  v_depositor_role  TEXT;
  v_dup_count       INT;
  v_recon_created   BOOLEAN := FALSE;
BEGIN
  IF v_caller_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
  END IF;

  IF p_bank_code IS NULL OR LENGTH(TRIM(p_bank_code)) = 0 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Bank verification code is required');
  END IF;

  SELECT * INTO v_tx FROM transactions WHERE id = p_transaction_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Transaction not found');
  END IF;

  IF v_tx.type <> 'deposit' THEN
    RETURN jsonb_build_object('success', false, 'error',
      'Only deposits can have a bank verification code');
  END IF;

  IF v_tx.status = 'pending_verification' THEN
    RETURN jsonb_build_object('success', false, 'error',
      'This deposit is awaiting verification. Use the normal Verify action instead.');
  END IF;

  IF v_tx.status <> 'completed' THEN
    RETURN jsonb_build_object('success', false, 'error',
      'Only completed deposits can be back-filled (current status: ' || v_tx.status || ')');
  END IF;

  IF v_tx.bank_verification_code IS NOT NULL THEN
    RETURN jsonb_build_object('success', false, 'error',
      'This deposit already has a bank verification code: ' || v_tx.bank_verification_code);
  END IF;

  IF v_tx.user_id = v_caller_id THEN
    RETURN jsonb_build_object('success', false, 'error',
      'You cannot back-fill your own deposit. Another member must do it.');
  END IF;

  SELECT role INTO v_caller_role    FROM profiles WHERE id = v_caller_id;
  SELECT role INTO v_depositor_role FROM profiles WHERE id = v_tx.user_id;

  IF v_depositor_role <> 'admin' AND v_caller_role <> 'admin' THEN
    RETURN jsonb_build_object('success', false, 'error',
      'Only an admin can back-fill member deposits');
  END IF;

  -- 90-day uniqueness window — but compute against transaction_date
  -- because back-fill is for older rows whose verified_at is NULL
  -- everywhere else. We compare against the depositor's claimed
  -- transaction date to catch admin pasting the same code twice
  -- for two deposits in the same statement period.
  SELECT COUNT(*) INTO v_dup_count
  FROM transactions
  WHERE bank_verification_code = TRIM(p_bank_code)
    AND id <> p_transaction_id
    AND transaction_date >= v_tx.transaction_date - INTERVAL '90 days'
    AND transaction_date <= v_tx.transaction_date + INTERVAL '90 days';

  IF v_dup_count > 0 THEN
    RETURN jsonb_build_object('success', false, 'error',
      'This bank verification code was already used on another transaction within the same 90-day window');
  END IF;

  UPDATE transactions
  SET bank_verification_code = TRIM(p_bank_code),
      verified_at            = NOW(),
      verified_by            = v_caller_id,
      updated_at             = NOW()
  WHERE id = p_transaction_id;

  IF NOT EXISTS (
    SELECT 1 FROM bank_reconciliations
    WHERE transaction_id = p_transaction_id
  ) THEN
    INSERT INTO bank_reconciliations (
      transaction_id, bank_date, bank_amount,
      bank_reference, bank_description,
      match_status, reconciled_by, reconciled_at
    ) VALUES (
      p_transaction_id,
      v_tx.transaction_date::DATE,
      v_tx.amount,
      TRIM(p_bank_code),
      'Back-filled bank verification for legacy deposit ' ||
        COALESCE(v_tx.statement_no, LEFT(p_transaction_id::TEXT, 8)),
      'matched',
      v_caller_id,
      NOW()
    );
    v_recon_created := TRUE;
  END IF;

  INSERT INTO audit_logs
    (user_id, action, table_name, record_id, new_values)
  VALUES (
    v_caller_id,
    'Back-filled bank verification (bank ref: ' || TRIM(p_bank_code) || ')',
    'transactions',
    p_transaction_id,
    jsonb_build_object(
      'bank_verification_code', TRIM(p_bank_code),
      'amount',                  v_tx.amount,
      'depositor_id',            v_tx.user_id,
      'recon_created',           v_recon_created
    )
  );

  RETURN jsonb_build_object(
    'success',        true,
    'transaction_id', p_transaction_id,
    'recon_created',  v_recon_created
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
