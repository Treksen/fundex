-- ============================================================
-- Migration 023: Deposit Verification Workflow
-- ------------------------------------------------------------
-- Adds an admin-verification step for member deposits.
--
-- Flow:
--  1. Member submits a deposit. They enter their own M-Pesa /
--     Bank reference into transactions.reference as before.
--     The deposit is inserted with status = 'pending_verification'.
--  2. An admin confirms the funds arrived in the group bank
--     account, then types in the bank-generated verification
--     code and calls verify_deposit(...).
--  3. The RPC stamps the transaction with the verification
--     code, flips status -> 'completed', writes audit log, and
--     inserts a matched row into bank_reconciliations so it
--     shows up on the reconciliation page automatically.
--  4. Dual-control: if the depositor IS an admin, an admin
--     cannot verify their own deposit. Another member (admin
--     or non-admin) must verify it. This is optional and only
--     enforced inside the RPC — it is NOT a hard DB constraint
--     (Supabase RLS cannot easily express "anyone except the
--     depositor"), so the RPC does the check itself.
--
-- All existing already-completed transactions are left alone.
-- Run after 001-022.
-- ============================================================


-- ── 1. ADD VERIFICATION COLUMNS ─────────────────────────────
ALTER TABLE transactions
  ADD COLUMN IF NOT EXISTS bank_verification_code TEXT,
  ADD COLUMN IF NOT EXISTS verified_at            TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS verified_by            UUID REFERENCES profiles(id);

CREATE INDEX IF NOT EXISTS idx_transactions_bank_verification_code
  ON transactions(bank_verification_code)
  WHERE bank_verification_code IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_transactions_status_type
  ON transactions(status, type);


-- ── 2. ALLOW 'pending_verification' IN status CHECK ─────────
-- The existing check allows: pending, approved, rejected, completed.
-- We add pending_verification used for deposits awaiting admin sign-off.
ALTER TABLE transactions
  DROP CONSTRAINT IF EXISTS transactions_status_check;

ALTER TABLE transactions
  ADD CONSTRAINT transactions_status_check
  CHECK (status IN (
    'pending',
    'pending_verification',
    'approved',
    'rejected',
    'completed'
  ));


-- ── 3. VERIFY DEPOSIT RPC ───────────────────────────────────
-- Verifies a pending deposit. SECURITY DEFINER so the function
-- can update the row regardless of RLS, but the function itself
-- enforces who is allowed to verify.
--
-- Returns JSONB { success, error?, transaction_id?, status? }
CREATE OR REPLACE FUNCTION verify_deposit(
  p_transaction_id UUID,
  p_bank_code      TEXT
)
RETURNS JSONB AS $$
DECLARE
  v_tx               RECORD;
  v_caller_id        UUID := auth.uid();
  v_caller_role      TEXT;
  v_depositor_role   TEXT;
  v_dup_count        INT;
  v_grand_total      DECIMAL;
BEGIN
  -- 3.1 Caller must be authenticated
  IF v_caller_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
  END IF;

  -- 3.2 Bank code is required and non-empty
  IF p_bank_code IS NULL OR LENGTH(TRIM(p_bank_code)) = 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Bank verification code is required'
    );
  END IF;

  -- 3.3 Fetch the transaction
  SELECT * INTO v_tx FROM transactions WHERE id = p_transaction_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Transaction not found');
  END IF;

  -- 3.4 Only deposits can be verified by this workflow
  IF v_tx.type <> 'deposit' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only deposits can be verified'
    );
  END IF;

  -- 3.5 Must currently be pending_verification
  IF v_tx.status <> 'pending_verification' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Transaction is not awaiting verification (current status: '
                 || v_tx.status || ')'
    );
  END IF;

  -- 3.6 Caller cannot verify their own deposit — even an admin
  IF v_tx.user_id = v_caller_id THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'You cannot verify your own deposit. Another member must verify it.'
    );
  END IF;

  -- 3.7 Role-based check:
  --     - If depositor is NOT admin: only an admin can verify.
  --     - If depositor IS admin:     ANY other member can verify
  --                                  (dual-control fallback).
  SELECT role INTO v_caller_role    FROM profiles WHERE id = v_caller_id;
  SELECT role INTO v_depositor_role FROM profiles WHERE id = v_tx.user_id;

  IF v_depositor_role <> 'admin' AND v_caller_role <> 'admin' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'Only an admin can verify member deposits'
    );
  END IF;

  -- 3.8 Bank verification code must be unique across all
  --     verified transactions (a real bank reference appears once)
  SELECT COUNT(*) INTO v_dup_count
  FROM transactions
  WHERE bank_verification_code = TRIM(p_bank_code)
    AND id <> p_transaction_id;

  IF v_dup_count > 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error',   'This bank verification code has already been used on another transaction'
    );
  END IF;

  -- 3.9 Stamp the transaction. This UPDATE will fire the existing
  --     triggers (notifications, equity recalc, reserve skim,
  --     ledger entries) because status transitions to 'completed'.
  UPDATE transactions
  SET status                  = 'completed',
      bank_verification_code  = TRIM(p_bank_code),
      verified_at             = NOW(),
      verified_by             = v_caller_id,
      updated_at              = NOW()
  WHERE id = p_transaction_id;

  -- 3.10 Create an ownership snapshot now that the deposit
  --      counts toward the pool. Mirrors what the old frontend
  --      did at deposit-creation time.
  SELECT COALESCE(SUM(amount), 0) INTO v_grand_total
  FROM transactions
  WHERE type = 'deposit' AND status = 'completed';

  IF v_grand_total > 0 THEN
    INSERT INTO ownership_snapshots
      (user_id, percentage, total_contribution, transaction_id)
    SELECT
      op.id,
      COALESCE(op.ownership_pct, 0),
      COALESCE(op.total_deposits, 0),
      p_transaction_id
    FROM ownership_percentages op;
  END IF;

  -- 3.11 Auto-insert a MATCHED row into bank_reconciliations
  --      so the verified transaction shows up on the
  --      reconciliation page already linked to the bank record.
  --      Skip if a row with this transaction_id already exists.
  IF NOT EXISTS (
    SELECT 1 FROM bank_reconciliations
    WHERE transaction_id = p_transaction_id
  ) THEN
    INSERT INTO bank_reconciliations (
      transaction_id,
      bank_date,
      bank_amount,
      bank_reference,
      bank_description,
      match_status,
      reconciled_by,
      reconciled_at
    ) VALUES (
      p_transaction_id,
      v_tx.transaction_date::DATE,
      v_tx.amount,
      TRIM(p_bank_code),
      'Auto-imported on verification of deposit ' ||
        COALESCE(v_tx.statement_no, LEFT(p_transaction_id::TEXT, 8)),
      'matched',
      v_caller_id,
      NOW()
    );
  END IF;

  -- 3.12 Audit log
  INSERT INTO audit_logs
    (user_id, action, table_name, record_id, new_values)
  VALUES (
    v_caller_id,
    'Verified deposit (bank ref: ' || TRIM(p_bank_code) || ')',
    'transactions',
    p_transaction_id,
    jsonb_build_object(
      'bank_verification_code', TRIM(p_bank_code),
      'amount',                  v_tx.amount,
      'depositor_id',            v_tx.user_id
    )
  );

  RETURN jsonb_build_object(
    'success',        true,
    'transaction_id', p_transaction_id,
    'status',         'completed'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION verify_deposit(UUID, TEXT) TO authenticated;


-- ── 4. RLS UPDATE  ──────────────────────────────────────────
-- The existing "Admin can update transactions" policy already
-- lets admins update via the RPC. For the case where the
-- depositor is an admin and a non-admin member verifies, we
-- add a narrow policy that lets any authenticated member set
-- ONLY the verification fields on a pending_verification deposit.
--
-- But because verify_deposit() runs as SECURITY DEFINER, RLS
-- is bypassed inside the function. So we don't strictly NEED
-- this policy — keeping it commented for documentation.
--
-- (No additional policy required.)


-- ── 5. CONVENIENCE VIEW: transactions_with_verification ─────
-- A lightweight view the frontend can read from with the
-- verifier's name resolved. Optional — the frontend can also
-- just join profiles directly.
CREATE OR REPLACE VIEW transactions_with_verification AS
SELECT
  t.*,
  vp.name  AS verified_by_name,
  vp.role  AS verified_by_role
FROM transactions t
LEFT JOIN profiles vp ON vp.id = t.verified_by;


-- ── 6. COMMENTS ─────────────────────────────────────────────
COMMENT ON COLUMN transactions.bank_verification_code IS
  'Bank/M-Pesa reference code added by the admin (or other member) at verification time. Distinct from transactions.reference, which is the code typed by the depositor when initiating the transfer.';
COMMENT ON COLUMN transactions.verified_at IS
  'Timestamp when the deposit was verified by an admin (or other member, for admin deposits).';
COMMENT ON COLUMN transactions.verified_by IS
  'Profile ID of the user who verified the deposit. Must differ from transactions.user_id.';
COMMENT ON FUNCTION verify_deposit(UUID, TEXT) IS
  'Admin-side action: stamp a pending deposit with the bank verification code, flip status to completed, snapshot ownership, and create a matched bank_reconciliations row.';
