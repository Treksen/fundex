-- ============================================================
-- Migration 028: Actor-Aware Notification Messages
-- ------------------------------------------------------------
-- Before this migration, notifications were written with the
-- same {depositor_name}/{verifier_name} interpolation for every
-- recipient. That meant a user reading their own notifications
-- saw their own name as if a stranger had written it:
--
--   "Mary's deposit verified by Tom"
--   (when Mary herself was the one reading)
--
-- This migration rewrites the three notification-emitting
-- functions so the message branches on whether the recipient
-- IS the actor in question. "You" replaces names when applicable.
--
-- Functions touched:
--   - notify_verifiers_on_pending_deposit  (mig 025)
--   - notify_members_on_deposit            (mig 014 / mig 025)
--   - notify_members_on_backfill           (mig 026)
--
-- Run after 027.
-- ============================================================


-- ── A. PENDING-VERIFICATION FAN-OUT ─────────────────────────
-- Replaces mig-025's body. Recipients here are verifiers, who
-- are by construction NOT the depositor (the WHERE filters that
-- out). So the only personalization possible is when the verifier
-- reads their notification and sees a depositor's name. The
-- depositor never sees this notification, so we don't have an
-- actor==recipient branch here, but for consistency we still
-- use the helper pattern.

CREATE OR REPLACE FUNCTION notify_verifiers_on_pending_deposit()
RETURNS TRIGGER AS $$
DECLARE
  v_depositor_name   TEXT;
  v_depositor_role   TEXT;
  v_amount_str       TEXT;
  v_ref_clause       TEXT;
  v_verifier         RECORD;
BEGIN
  IF NEW.type <> 'deposit' THEN RETURN NEW; END IF;
  IF NEW.status <> 'pending_verification' THEN RETURN NEW; END IF;

  SELECT name, role
    INTO v_depositor_name, v_depositor_role
    FROM profiles WHERE id = NEW.user_id;

  v_amount_str := 'KES ' || TO_CHAR(NEW.amount, 'FM999,999,999.00');
  v_ref_clause := CASE
                    WHEN NEW.reference IS NOT NULL AND LENGTH(NEW.reference) > 0
                    THEN ' (Their ref: ' || NEW.reference || ')'
                    ELSE ''
                  END;

  FOR v_verifier IN
    SELECT id FROM profiles
    WHERE id <> NEW.user_id
      AND (v_depositor_role = 'admin' OR role = 'admin')
  LOOP
    INSERT INTO notifications
      (user_id, title, message, type, action_url, metadata)
    VALUES (
      v_verifier.id,
      '🕓 Deposit Awaiting Verification',
      v_depositor_name || ' recorded a deposit of ' || v_amount_str ||
        '.' || v_ref_clause ||
        ' Please confirm the funds in the group bank account and add' ||
        ' the bank verification code.',
      'approval',
      '/transactions?pending=' || NEW.id::TEXT,
      jsonb_build_object(
        'transaction_id', NEW.id,
        'depositor_id',   NEW.user_id,
        'amount',         NEW.amount,
        'kind',           'pending_verification'
      )
    )
    ON CONFLICT DO NOTHING;
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ── B. DEPOSIT-COMPLETED FAN-OUT (verification path) ───────
-- Three recipients matter:
--   * The depositor      → "Your deposit was verified by Tom"
--   * The verifier       → "You verified Mary's deposit"
--   * Everyone else      → "Mary's deposit verified by Tom"
--
-- For non-verified completions (legacy edits etc) the older
-- "✅ Deposit Confirmed" wording still applies, but now
-- "Your deposit" replaces "Your deposit" only when recipient is
-- depositor; everyone else sees "Mary made a deposit".

CREATE OR REPLACE FUNCTION notify_members_on_deposit()
RETURNS TRIGGER AS $$
DECLARE
  v_depositor_name   TEXT;
  v_verifier_name    TEXT;
  v_member           RECORD;
  v_stmt_no          TEXT;
  v_amount_str       TEXT;
  v_was_verified     BOOLEAN;
  v_title            TEXT;
  v_msg              TEXT;
BEGIN
  IF NEW.type <> 'deposit' THEN RETURN NEW; END IF;
  IF NEW.status <> 'completed' THEN RETURN NEW; END IF;
  IF OLD IS NOT NULL AND OLD.status = 'completed' THEN RETURN NEW; END IF;

  SELECT name INTO v_depositor_name FROM profiles WHERE id = NEW.user_id;
  v_stmt_no    := COALESCE(NEW.statement_no, LEFT(NEW.id::TEXT, 8));
  v_amount_str := 'KES ' || TO_CHAR(NEW.amount, 'FM999,999,999.00');

  v_was_verified := NEW.bank_verification_code IS NOT NULL
                    AND NEW.verified_by IS NOT NULL
                    AND (OLD IS NULL OR OLD.status = 'pending_verification');

  IF v_was_verified THEN
    SELECT name INTO v_verifier_name FROM profiles WHERE id = NEW.verified_by;
  END IF;

  FOR v_member IN SELECT id FROM profiles LOOP
    IF v_was_verified THEN
      -- Three branches by recipient role in this event
      IF v_member.id = NEW.user_id THEN
        -- Recipient is the depositor
        v_title := '✅ Your Deposit Verified';
        v_msg   := v_verifier_name || ' verified your deposit of ' ||
                   v_amount_str || '. Bank reference: ' ||
                   NEW.bank_verification_code ||
                   '. It now counts toward the group pool.';
      ELSIF v_member.id = NEW.verified_by THEN
        -- Recipient is the verifier
        v_title := '✅ You Verified a Deposit';
        v_msg   := 'You verified ' || v_depositor_name || '''s deposit of ' ||
                   v_amount_str || ' (Bank ref: ' ||
                   NEW.bank_verification_code ||
                   '). The pool has been updated.';
      ELSE
        -- Recipient is a bystander
        v_title := '💰 ' || SPLIT_PART(v_depositor_name, ' ', 1) ||
                   '''s deposit verified';
        v_msg   := v_depositor_name || '''s deposit of ' || v_amount_str ||
                   ' has been verified by ' || v_verifier_name ||
                   ' (Bank ref: ' || NEW.bank_verification_code || ').' ||
                   ' The pool has been updated.';
      END IF;

      INSERT INTO notifications
        (user_id, title, message, type, action_url, metadata)
      VALUES (
        v_member.id,
        v_title,
        v_msg,
        CASE WHEN v_member.id = NEW.user_id THEN 'success' ELSE 'info' END,
        '/transactions',
        jsonb_build_object(
          'transaction_id', NEW.id,
          'amount',         NEW.amount,
          'verified',       TRUE,
          'bank_ref',       NEW.bank_verification_code
        )
      )
      ON CONFLICT DO NOTHING;
    ELSE
      -- Non-verified completion (legacy edits etc)
      IF v_member.id = NEW.user_id THEN
        v_title := '✅ Deposit Confirmed';
        v_msg   := 'Your deposit of ' || v_amount_str ||
                   ' (Ref: ' || v_stmt_no ||
                   ') has been recorded successfully.';
      ELSE
        v_title := '💰 ' || SPLIT_PART(v_depositor_name, ' ', 1) || ' made a deposit';
        v_msg   := v_depositor_name || ' deposited ' || v_amount_str ||
                   ' into the group pool (Ref: ' || v_stmt_no || '). ' ||
                   'The pool has been updated.';
      END IF;

      INSERT INTO notifications
        (user_id, title, message, type, action_url, metadata)
      VALUES (
        v_member.id,
        v_title,
        v_msg,
        CASE WHEN v_member.id = NEW.user_id THEN 'success' ELSE 'info' END,
        '/transactions',
        jsonb_build_object(
          'transaction_id', NEW.id,
          'amount',         NEW.amount,
          'verified',       FALSE
        )
      )
      ON CONFLICT DO NOTHING;
    END IF;
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ── C. BACK-FILL FAN-OUT ────────────────────────────────────
-- Three recipients:
--   * The depositor → "Tom added the bank code for your deposit"
--   * The verifier  → "You added the bank code for Mary's deposit"
--   * Bystanders    → "Tom added the bank code for Mary's deposit"

CREATE OR REPLACE FUNCTION notify_members_on_backfill()
RETURNS TRIGGER AS $$
DECLARE
  v_depositor_name   TEXT;
  v_verifier_name    TEXT;
  v_member           RECORD;
  v_amount_str       TEXT;
  v_title            TEXT;
  v_msg              TEXT;
BEGIN
  IF NEW.type <> 'deposit' THEN RETURN NEW; END IF;
  IF NEW.status <> 'completed' THEN RETURN NEW; END IF;
  IF OLD IS NULL THEN RETURN NEW; END IF;
  IF OLD.status <> 'completed' THEN RETURN NEW; END IF;
  IF NEW.bank_verification_code IS NULL THEN RETURN NEW; END IF;
  IF OLD.bank_verification_code IS NOT NULL THEN RETURN NEW; END IF;
  IF NEW.verified_by IS NULL THEN RETURN NEW; END IF;

  SELECT name INTO v_depositor_name FROM profiles WHERE id = NEW.user_id;
  SELECT name INTO v_verifier_name  FROM profiles WHERE id = NEW.verified_by;

  v_amount_str := 'KES ' || TO_CHAR(NEW.amount, 'FM999,999,999.00');

  FOR v_member IN SELECT id FROM profiles LOOP
    IF v_member.id = NEW.user_id THEN
      v_title := '🧾 Bank Reference Added to Your Deposit';
      v_msg   := v_verifier_name || ' added the bank verification code for your earlier deposit of ' ||
                 v_amount_str || ' (Bank ref: ' || NEW.bank_verification_code ||
                 '). Your equity is unchanged — this is a record-keeping update for the bank reconciliation.';
    ELSIF v_member.id = NEW.verified_by THEN
      v_title := '🧾 You Added a Bank Reference';
      v_msg   := 'You added the bank verification code for ' || v_depositor_name ||
                 '''s earlier deposit of ' || v_amount_str || ' (Bank ref: ' ||
                 NEW.bank_verification_code ||
                 '). No change to balances — this is for reconciliation only.';
    ELSE
      v_title := '🧾 Bank Reference Back-filled';
      v_msg   := v_verifier_name || ' added the bank verification code for ' ||
                 v_depositor_name || '''s earlier deposit of ' || v_amount_str ||
                 ' (Bank ref: ' || NEW.bank_verification_code ||
                 '). No change to balances — this is for reconciliation only.';
    END IF;

    INSERT INTO notifications
      (user_id, title, message, type, action_url, metadata)
    VALUES (
      v_member.id,
      v_title,
      v_msg,
      'info',
      '/transactions',
      jsonb_build_object(
        'transaction_id', NEW.id,
        'depositor_id',   NEW.user_id,
        'amount',         NEW.amount,
        'bank_ref',       NEW.bank_verification_code,
        'kind',           'backfill'
      )
    )
    ON CONFLICT DO NOTHING;
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ── D. PENDING-BACKFILL HELPER (mig-027) ────────────────────
-- Already writes per-recipient text, but the message uses
-- {depositor_name}. When the eligible verifier list ever
-- includes the depositor themselves (it doesn't today — the
-- WHERE clause excludes them), the wording would be wrong.
-- Updated for consistency anyway: skip if recipient is depositor
-- (defensive; the WHERE already excludes them).

CREATE OR REPLACE FUNCTION notify_members_on_pending_backfill(
  p_transaction_id UUID
)
RETURNS INT AS $$
DECLARE
  v_tx              RECORD;
  v_depositor_name  TEXT;
  v_depositor_role  TEXT;
  v_amount_str      TEXT;
  v_verifier        RECORD;
  v_count           INT := 0;
BEGIN
  SELECT * INTO v_tx FROM transactions WHERE id = p_transaction_id;
  IF NOT FOUND THEN RETURN 0; END IF;
  IF v_tx.type <> 'deposit' THEN RETURN 0; END IF;
  IF v_tx.status <> 'completed' THEN RETURN 0; END IF;
  IF v_tx.bank_verification_code IS NOT NULL THEN RETURN 0; END IF;

  SELECT name, role INTO v_depositor_name, v_depositor_role
    FROM profiles WHERE id = v_tx.user_id;

  v_amount_str := 'KES ' || TO_CHAR(v_tx.amount, 'FM999,999,999.00');

  FOR v_verifier IN
    SELECT id FROM profiles
    WHERE id <> v_tx.user_id
      AND (v_depositor_role = 'admin' OR role = 'admin')
  LOOP
    INSERT INTO notifications
      (user_id, title, message, type, action_url, metadata)
    VALUES (
      v_verifier.id,
      '🔎 Old Deposit Needs Bank Code',
      v_depositor_name || ' has an earlier deposit of ' || v_amount_str ||
        CASE
          WHEN v_tx.reference IS NOT NULL AND LENGTH(v_tx.reference) > 0
          THEN ' (Their ref: ' || v_tx.reference || ')'
          ELSE ''
        END ||
        ' that still needs its bank verification code added. ' ||
        'Tap to open and add the code from your bank statement.',
      'approval',
      '/transactions?pending=' || v_tx.id::TEXT,
      jsonb_build_object(
        'transaction_id', v_tx.id,
        'depositor_id',   v_tx.user_id,
        'amount',         v_tx.amount,
        'kind',           'pending_backfill'
      )
    )
    ON CONFLICT DO NOTHING;
    v_count := v_count + 1;
  END LOOP;

  RETURN v_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


GRANT EXECUTE ON FUNCTION notify_verifiers_on_pending_deposit() TO authenticated;
GRANT EXECUTE ON FUNCTION notify_members_on_deposit() TO authenticated;
GRANT EXECUTE ON FUNCTION notify_members_on_backfill() TO authenticated;
GRANT EXECUTE ON FUNCTION notify_members_on_pending_backfill(UUID) TO authenticated;
