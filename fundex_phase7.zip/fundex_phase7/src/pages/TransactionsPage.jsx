import React from 'react'
import MemberAvatar from '../components/MemberAvatar'
import PageHeader from '../components/PageHeader'
import Pagination from '../components/Pagination'
import DocumentAttachments from '../components/DocumentAttachments'
import { useState, useEffect, useCallback, useMemo } from 'react'
import { Plus, Filter, Check, X, ChevronDown, ChevronUp, AlertCircle, Edit2, Trash2, ShieldCheck, Clock } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { formatCurrency, formatDateTime, getMemberColor } from '../lib/utils'
import AddTransactionModal from '../components/transactions/AddTransactionModal'
import toast from 'react-hot-toast'
import { useSearchParams } from 'react-router-dom'

const PAGE_SIZE = 20

export default function TransactionsPage() {
  const { profile, isAdmin } = useAuth()
  const [searchParams] = useSearchParams()
  const highlightId = searchParams.get('pending')

  const [transactions, setTransactions] = useState([])
  const [approvals, setApprovals] = useState({})
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [filter, setFilter] = useState({ type: '', status: '', member: '' })
  const [members, setMembers] = useState([])
  const [expandedRows, setExpandedRows] = useState({})
  const [voting, setVoting] = useState({})
  const [page, setPage] = useState(1)
  const [totalCount, setTotalCount] = useState(0)
  // Total number of completed deposits that still need a bank
  // verification code (across ALL pages, ignoring current filter).
  const [backfillCount, setBackfillCount] = useState(0)

  // Admin edit/delete state
  const [editingTx, setEditingTx] = useState(null)
  const [editForm, setEditForm] = useState({})
  const [savingEdit, setSavingEdit] = useState(false)
  const [deletingId, setDeletingId] = useState(null)

  // Deposit verification state
  // verifyingTx: id of the transaction currently being verified (shows inline form)
  // verifyCode:  per-transaction bank-code input value
  // verifyBusy:  per-transaction in-flight flag
  const [verifyingTx, setVerifyingTx] = useState(null)
  const [verifyCode, setVerifyCode] = useState({})
  const [verifyBusy, setVerifyBusy] = useState({})

  // Rejection state — separate from verify so opening the reject
  // panel doesn't clobber a typed-in bank code.
  const [rejectingTx, setRejectingTx] = useState(null)
  const [rejectReason, setRejectReason] = useState({})
  const [rejectBusy, setRejectBusy] = useState({})

  // When TRUE, only show completed deposits without a bank_verification_code
  // (i.e. legacy rows the admin still needs to back-fill).
  const [needsBackfillOnly, setNeedsBackfillOnly] = useState(false)

  useEffect(() => { fetchMembers() }, [])
  useEffect(() => { setPage(1) }, [filter, needsBackfillOnly])
  useEffect(() => { fetchData() }, [filter, page, needsBackfillOnly])

  useEffect(() => {
    if (highlightId) {
      setExpandedRows(prev => ({ ...prev, [highlightId]: true }))
      setTimeout(() => {
        const el = document.getElementById(`tx-row-${highlightId}`)
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }, 600)
    }
  }, [highlightId, loading])

  useEffect(() => {
    if (!profile) return
    const channel = supabase.channel('approval-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'withdrawal_approvals' }, () => fetchData())
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'transactions' }, () => fetchData())
      .subscribe()
    return () => supabase.removeChannel(channel)
  }, [profile])

  const fetchMembers = async () => {
    const { data } = await supabase.from('profiles').select('id, name, role')
    if (data) setMembers(data)
  }

  // How many completed deposits is the current user eligible
  // to back-fill? Drives the back-fill banner. Independent of
  // pagination and current filter.
  //   * Admins → count every un-back-filled completed deposit
  //              (except their own).
  //   * Members → count un-back-filled completed deposits whose
  //              depositor is an admin (mirrors canBackfillDeposit).
  const fetchBackfillCount = useCallback(async () => {
    if (!profile?.id) { setBackfillCount(0); return }

    let query = supabase
      .from('transactions')
      .select(
        // !inner forces the join filter to apply server-side
        'id, profiles!transactions_user_id_fkey!inner(role)',
        { count: 'exact', head: true }
      )
      .eq('type', 'deposit')
      .eq('status', 'completed')
      .is('bank_verification_code', null)
      .neq('user_id', profile.id)            // never self

    // Non-admins can only act on admin deposits.
    if (!isAdmin) {
      query = query.eq('profiles.role', 'admin')
    }

    const { count, error } = await query
    if (!error) setBackfillCount(count || 0)
  }, [isAdmin, profile?.id])

  useEffect(() => { fetchBackfillCount() }, [fetchBackfillCount])

  const fetchData = useCallback(async () => {
    setLoading(true)
    try {
      let query = supabase.from('transactions')
        .select('*, profiles!transactions_user_id_fkey(name, id, avatar_url)', { count: 'exact' })
        .order('transaction_date', { ascending: false })
        .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1)

      if (filter.type) query = query.eq('type', filter.type)
      if (filter.status) query = query.eq('status', filter.status)
      if (filter.member) query = query.eq('user_id', filter.member)

      // Back-fill filter: completed deposits with no
      // bank_verification_code. Mirrors canBackfillDeposit:
      //  - Admin caller → all such deposits (except own)
      //  - Member caller → only those where the depositor is admin
      // Overrides any conflicting filters set above.
      if (needsBackfillOnly) {
        query = supabase
          .from('transactions')
          .select(
            // !inner so we can filter on profiles.role server-side
            '*, profiles!transactions_user_id_fkey!inner(name, id, avatar_url, role)',
            { count: 'exact' }
          )
          .order('transaction_date', { ascending: false })
          .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1)
          .eq('type', 'deposit')
          .eq('status', 'completed')
          .is('bank_verification_code', null)
          .neq('user_id', profile?.id || '00000000-0000-0000-0000-000000000000')

        if (!isAdmin) {
          query = query.eq('profiles.role', 'admin')
        }
      }

      const { data, error, count } = await query
      if (!error && data) {
        setTransactions(data)
        setTotalCount(count || 0)
        const withdrawalIds = data.filter(t => t.type === 'withdrawal').map(t => t.id)
        if (withdrawalIds.length > 0) {
          const { data: appData } = await supabase
            .from('withdrawal_approvals')
            .select('*, profiles!withdrawal_approvals_approver_id_fkey(name, id, avatar_url)')
            .in('transaction_id', withdrawalIds)
          if (appData) {
            const grouped = {}
            appData.forEach(a => {
              if (!grouped[a.transaction_id]) grouped[a.transaction_id] = []
              grouped[a.transaction_id].push(a)
            })
            setApprovals(grouped)
          }
        }
      } else if (error) {
        toast.error('Failed to load transactions')
      }
    } catch (err) {
      toast.error('Network error loading transactions')
    }
    setLoading(false)
  }, [filter, page, needsBackfillOnly, isAdmin, profile?.id])

  const handleVote = async (transactionId, approve, reason = '') => {
    setVoting(v => ({ ...v, [transactionId]: true }))
    const { error } = await supabase.from('withdrawal_approvals')
      .update({ status: approve ? 'approved' : 'rejected', voted_at: new Date().toISOString(), rejection_reason: !approve ? reason : null })
      .eq('transaction_id', transactionId).eq('approver_id', profile.id)

    if (error) { toast.error('Failed to submit vote'); setVoting(v => ({ ...v, [transactionId]: false })); return }

    const tx = transactions.find(t => t.id === transactionId)
    const othersToNotify = members.filter(m => m.id !== profile.id)
    if (othersToNotify.length > 0) {
      await supabase.from('notifications').insert(othersToNotify.map(m => ({
        user_id: m.id,
        title: approve ? `${profile.name?.split(' ')[0]} approved a withdrawal` : `${profile.name?.split(' ')[0]} rejected a withdrawal`,
        message: approve
          ? `${profile.name} has approved the KES ${Number(tx?.amount || 0).toLocaleString()} withdrawal by ${tx?.profiles?.name?.split(' ')[0]}.`
          : `${profile.name} has rejected the KES ${Number(tx?.amount || 0).toLocaleString()} withdrawal by ${tx?.profiles?.name?.split(' ')[0]}.`,
        type: approve ? 'info' : 'warning',
        action_url: `/transactions?pending=${transactionId}`,
      })))
    }
    const { data: result } = await supabase.rpc('process_withdrawal_approval', { p_transaction_id: transactionId })
    if (result?.status === 'completed') toast.success('All members approved — withdrawal processed! ✅')
    else if (result?.status === 'rejected') toast.error('Withdrawal has been rejected.')
    else if (approve) { const rem = (result?.total || 0) - (result?.approved_count || 0); toast.success(`Approval recorded. ${rem} more needed.`) }
    else toast('Vote recorded.', { icon: '📝' })
    setVoting(v => ({ ...v, [transactionId]: false }))
    await fetchData()
  }

  // ── ADMIN EDIT ──────────────────────────────────────────────
  const startEdit = (tx) => {
    setEditingTx(tx.id)
    setEditForm({
      amount: tx.amount,
      reference: tx.reference || '',
      description: tx.description || '',
      status: tx.status,
      type: tx.type,
    })
  }

  const saveEdit = async () => {
    if (!editingTx) return
    if (Number(editForm.amount) <= 0) { toast.error('Amount must be greater than zero'); return }
    setSavingEdit(true)
    const { error } = await supabase.from('transactions')
      .update({
        amount: Number(editForm.amount),
        reference: editForm.reference || null,
        description: editForm.description || null,
        status: editForm.status,
        type: editForm.type,
        updated_at: new Date().toISOString(),
      })
      .eq('id', editingTx)

    if (error) { toast.error('Update failed: ' + error.message) }
    else {
      toast.success('Transaction updated')
      await supabase.from('audit_logs').insert({
        user_id: profile.id, action: 'Admin updated transaction',
        table_name: 'transactions', record_id: editingTx,
      })
      setEditingTx(null)
      await fetchData()
    }
    setSavingEdit(false)
  }

  // ── ADMIN DELETE ────────────────────────────────────────────
  // Uses admin_delete_transaction() RPC (migration 010) which:
  //  • Handles all FK cascades safely (ownership_snapshots, ledger, etc.)
  //  • Writes an audit log server-side
  //  • Recalculates equity for all members after deletion
  const handleDelete = async (txId, txType, txAmount, memberName) => {
    const reason = window.prompt(
      `Delete this ${txType} of ${formatCurrency(txAmount)} for ${memberName}?\n\nThis will recalculate all equity and reserve balances.\nEnter a reason (required):`,
      'Admin correction'
    )
    if (reason === null) return  // user cancelled
    if (!reason.trim()) { toast.error('A reason is required to delete a transaction.'); return }

    setDeletingId(txId)
    // Log reason to audit first, then delete
    await supabase.from('audit_logs').insert({
      user_id: profile.id,
      action: `Deleting transaction — reason: ${reason.trim()}`,
      table_name: 'transactions',
      record_id: txId,
      change_type: 'delete',
    })
    const { data, error } = await supabase.rpc('admin_delete_transaction', {
      p_transaction_id: txId,
    })
    if (error || data?.success === false) {
      toast.error('Delete failed: ' + (error?.message || data?.error))
    } else {
      toast.success('Transaction deleted — equity and reserve recalculated ✅')
      await fetchData()
    }
    setDeletingId(null)
  }

  const myApproval = (txId) => approvals[txId]?.find(a => a.approver_id === profile?.id)
  const canVote = (txId) => {
    const tx = transactions.find(t => t.id === txId)
    if (!tx || tx.user_id === profile?.id) return false
    return myApproval(txId)?.status === 'pending'
  }
  const getApprovalSummary = (txId) => {
    const txApprovals = approvals[txId] || []
    return {
      approved: txApprovals.filter(a => a.status === 'approved'),
      rejected: txApprovals.filter(a => a.status === 'rejected'),
      pending: txApprovals.filter(a => a.status === 'pending'),
      total: txApprovals.length
    }
  }
  const toggleExpand = (id) => setExpandedRows(prev => ({ ...prev, [id]: !prev[id] }))
  const getStatusBadge = (s) => ({
    completed: 'badge-green',
    approved:  'badge-blue',
    pending:   'badge-amber',
    pending_verification: 'badge-amber',
    rejected:  'badge-red',
  }[s] || 'badge-gray')
  const getStatusLabel = (s) => ({
    completed: 'completed',
    approved:  'approved',
    pending:   'pending',
    pending_verification: 'awaiting verification',
    rejected:  'rejected',
  }[s] || s)

  // ── Approvals/Verification cell helper ─────────────────────
  // Returns an array of badge descriptors { label, kind } where
  // kind ∈ {green, blue, amber, red, gray}. Used by the Approvals
  // column on both desktop and mobile. Handles all type/status
  // combinations:
  //
  //   Deposit  pending_verification        → [Awaiting Verification]
  //   Deposit  completed + bank code       → [Approved & Verified]
  //   Deposit  completed, no bank code     → [Counted, Unverified]
  //   Deposit  rejected                    → [Rejected]
  //
  //   Withdrawal pending (some votes left) → [Pending Votes]
  //   Withdrawal pending (all voted)       → [Pending Votes]  (status hasn't flipped yet)
  //   Withdrawal completed                 → [Approved]
  //   Withdrawal rejected                  → [Rejected]
  //
  //   Adjustment completed                 → [Approved]
  //   anything else                        → [—]
  const getApprovalBadges = (tx) => {
    if (!tx) return [{ label: '—', kind: 'gray' }]

    if (tx.type === 'deposit') {
      if (tx.status === 'pending_verification') {
        return [{ label: 'Awaiting Verification', kind: 'amber' }]
      }
      if (tx.status === 'rejected') {
        return [{ label: 'Rejected', kind: 'red' }]
      }
      if (tx.status === 'completed') {
        if (tx.bank_verification_code) {
          return [{ label: 'Approved & Verified', kind: 'green' }]
        }
        return [{ label: 'Counted, Unverified', kind: 'amber' }]
      }
    }

    if (tx.type === 'withdrawal') {
      if (tx.status === 'pending') {
        return [{ label: 'Pending Votes', kind: 'amber' }]
      }
      if (tx.status === 'rejected') {
        return [{ label: 'Rejected', kind: 'red' }]
      }
      if (tx.status === 'completed') {
        return [{ label: 'Approved', kind: 'green' }]
      }
    }

    if (tx.type === 'adjustment') {
      if (tx.status === 'completed') {
        return [{ label: 'Approved', kind: 'green' }]
      }
    }

    return [{ label: '—', kind: 'gray' }]
  }

  // CSS class for each badge kind
  const badgeClass = (kind) => ({
    green: 'badge-green',
    blue:  'badge-blue',
    amber: 'badge-amber',
    red:   'badge-red',
    gray:  'badge-gray',
  }[kind] || 'badge-gray')

  // Can the current user verify this deposit?
  //  - Must be a deposit awaiting verification
  //  - The current user must NOT be the depositor
  //  - If depositor is admin → ANY other member can verify
  //  - If depositor is non-admin → only an admin can verify
  const canVerifyDeposit = (tx) => {
    if (!tx || !profile) return false
    if (tx.type !== 'deposit') return false
    if (tx.status !== 'pending_verification') return false
    if (tx.user_id === profile.id) return false
    const depositor = members.find(m => m.id === tx.user_id)
    if (!depositor) return false
    if (depositor.role === 'admin') return true     // any other member
    return isAdmin                                  // member deposit → admin-only
  }

  // True if this transaction has a verification code stamped on it.
  // We use this for the "Verified" badge on the row.
  const isVerified = (tx) =>
    tx?.type === 'deposit' && !!tx?.bank_verification_code

  // Submit the bank verification code for a deposit.
  const handleVerifyDeposit = async (tx) => {
    const code = (verifyCode[tx.id] || '').trim()
    if (!code) {
      toast.error('Enter the bank verification code first')
      return
    }
    setVerifyBusy(b => ({ ...b, [tx.id]: true }))
    const { data, error } = await supabase.rpc('verify_deposit', {
      p_transaction_id: tx.id,
      p_bank_code:      code,
    })
    if (error) {
      toast.error('Verify failed: ' + error.message)
      setVerifyBusy(b => ({ ...b, [tx.id]: false }))
      return
    }
    if (data && data.success === false) {
      toast.error(data.error || 'Verification rejected')
      setVerifyBusy(b => ({ ...b, [tx.id]: false }))
      return
    }
    toast.success(`Deposit verified ✓ — added to reconciliation`)
    // Note: depositor + group notifications (and emails) are sent by
    // the notify_members_on_deposit DB trigger (migration 025), which
    // fires when the status flips to 'completed' and now includes
    // verifier name + bank reference.
    setVerifyingTx(null)
    setVerifyCode(c => ({ ...c, [tx.id]: '' }))
    setVerifyBusy(b => ({ ...b, [tx.id]: false }))
    await fetchData()
  }

  // Reject a pending_verification deposit. Calls the
  // reject_deposit_verification RPC (migration 029). Same
  // role rules as verify_deposit — only enforced server-side.
  const handleRejectDeposit = async (tx) => {
    const reason = (rejectReason[tx.id] || '').trim()
    if (reason.length < 5) {
      toast.error('Please give a reason (at least 5 characters)')
      return
    }
    setRejectBusy(b => ({ ...b, [tx.id]: true }))
    const { data, error } = await supabase.rpc('reject_deposit_verification', {
      p_transaction_id: tx.id,
      p_reason:         reason,
    })
    if (error) {
      toast.error('Reject failed: ' + error.message)
      setRejectBusy(b => ({ ...b, [tx.id]: false }))
      return
    }
    if (data && data.success === false) {
      toast.error(data.error || 'Rejection refused')
      setRejectBusy(b => ({ ...b, [tx.id]: false }))
      return
    }
    toast.success('Deposit marked as rejected — depositor has been notified')
    setRejectingTx(null)
    setRejectReason(r => ({ ...r, [tx.id]: '' }))
    setRejectBusy(b => ({ ...b, [tx.id]: false }))
    await fetchData()
  }

  // ── BACK-FILL: stamping a bank code onto an OLD completed deposit ──
  // Mirrors verify_deposit / backfill_deposit_verification dual-control:
  //  - tx is already 'completed' (legacy data)
  //  - bank_verification_code is still NULL
  //  - caller is NOT the depositor
  //  - If depositor is admin → ANY other member can back-fill
  //  - If depositor is non-admin → only an admin can back-fill
  const canBackfillDeposit = (tx) => {
    if (!tx || !profile) return false
    if (tx.type !== 'deposit') return false
    if (tx.status !== 'completed') return false
    if (tx.bank_verification_code) return false
    if (tx.user_id === profile.id) return false
    const depositor = members.find(m => m.id === tx.user_id)
    if (!depositor) return false
    if (depositor.role === 'admin') return true      // any other member
    return isAdmin                                   // member deposit → admin-only
  }

  // Submit the bank code for an old completed deposit (back-fill).
  const handleBackfillDeposit = async (tx) => {
    const code = (verifyCode[tx.id] || '').trim()
    if (!code) {
      toast.error('Enter the bank verification code first')
      return
    }
    setVerifyBusy(b => ({ ...b, [tx.id]: true }))
    const { data, error } = await supabase.rpc('backfill_deposit_verification', {
      p_transaction_id: tx.id,
      p_bank_code:      code,
    })
    if (error) {
      toast.error('Back-fill failed: ' + error.message)
      setVerifyBusy(b => ({ ...b, [tx.id]: false }))
      return
    }
    if (data && data.success === false) {
      toast.error(data.error || 'Back-fill rejected')
      setVerifyBusy(b => ({ ...b, [tx.id]: false }))
      return
    }
    toast.success(
      data?.recon_created
        ? 'Bank code added ✓ — also linked on reconciliation page'
        : 'Bank code added ✓'
    )
    setVerifyingTx(null)
    setVerifyCode(c => ({ ...c, [tx.id]: '' }))
    setVerifyBusy(b => ({ ...b, [tx.id]: false }))

    // Compute the new back-fill count BEFORE refetching the grid.
    // If it has dropped to zero AND the "Show only these" filter
    // is on, we drop the filter so the user lands back on the
    // general transactions list automatically (otherwise they'd
    // be stuck on an empty list until navigating away and back).
    let remainingCount = 0
    {
      let q = supabase
        .from('transactions')
        .select('id, profiles!transactions_user_id_fkey!inner(role)', {
          count: 'exact',
          head: true,
        })
        .eq('type', 'deposit')
        .eq('status', 'completed')
        .is('bank_verification_code', null)
        .neq('user_id', profile?.id || '00000000-0000-0000-0000-000000000000')
      if (!isAdmin) q = q.eq('profiles.role', 'admin')
      const { count } = await q
      remainingCount = count || 0
    }
    setBackfillCount(remainingCount)

    if (needsBackfillOnly && remainingCount === 0) {
      setNeedsBackfillOnly(false)
      toast.success('All caught up — showing the full list')
      // fetchData will fire automatically because needsBackfillOnly
      // is in its useEffect deps.
    } else {
      await fetchData()
    }
  }

  const ApproverChip = ({ approval }) => {
    const color = approval.status === 'approved' ? 'var(--accent-emerald)' : approval.status === 'rejected' ? 'var(--accent-red)' : 'var(--accent-amber)'
    const bg = approval.status === 'approved' ? 'rgba(13,156,94,0.10)' : approval.status === 'rejected' ? 'rgba(220,53,69,0.10)' : 'rgba(230,144,10,0.10)'
    const icon = approval.status === 'approved' ? '✓' : approval.status === 'rejected' ? '✕' : '…'
    return (
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 99, background: bg, border: `1px solid ${color}22`, fontSize: 12, fontWeight: 600, color }}>
        <MemberAvatar name={approval.profiles?.name} avatarUrl={approval.profiles?.avatar_url} size={18} fontSize={8} />
        {approval.profiles?.name?.split(' ')[0]}
        <span style={{ fontSize: 11 }}>{icon}</span>
        {approval.voted_at && <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>{new Date(approval.voted_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>}
      </div>
    )
  }

  const ApprovalPanel = ({ tx }) => {
    const [rejectReason, setRejectReason] = useState('')
    const [showRejectInput, setShowRejectInput] = useState(false)
    const summary = getApprovalSummary(tx.id)
    const isVoting = voting[tx.id]
    const isRequester = tx.user_id === profile?.id
    const mine = myApproval(tx.id)
    const pct = summary.total > 0 ? Math.round((summary.approved.length / summary.total) * 100) : 0
    return (
      <div style={{ background: highlightId === tx.id ? 'rgba(90,138,30,0.04)' : 'rgba(245,247,245,0.8)', border: `1px solid ${highlightId === tx.id ? 'rgba(90,138,30,0.25)' : 'var(--border)'}`, borderRadius: 10, padding: '14px 16px', marginTop: 2 }}>
        <div style={{ marginBottom: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>Approval Progress</span>
            <span style={{ fontSize: 12, fontWeight: 700 }}>{summary.approved.length} / {summary.total} approved</span>
          </div>
          <div style={{ height: 6, background: 'var(--bg-elevated)', borderRadius: 99, overflow: 'hidden' }}>
            <div style={{ height: '100%', borderRadius: 99, width: `${pct}%`, background: summary.rejected.length > 0 ? 'var(--accent-red)' : 'var(--olive)', transition: 'width 0.4s' }} />
          </div>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 14 }}>
          {(approvals[tx.id] || []).map(a => <ApproverChip key={a.id} approval={a} />)}
        </div>
        {isRequester ? (
          <div style={{ fontSize: 13, color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <AlertCircle size={14} style={{ color: 'var(--olive)', flexShrink: 0 }} />
            Awaiting {summary.pending.length} approval{summary.pending.length !== 1 ? 's' : ''} from: <strong>{summary.pending.map(a => a.profiles?.name?.split(' ')[0]).join(', ')}</strong>
          </div>
        ) : mine?.status === 'pending' ? (
          <div>
            {showRejectInput ? (
              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap' }}>
                <div style={{ flex: 1, minWidth: 180 }}>
                  <input className="form-input" placeholder="Reason (optional)" value={rejectReason} onChange={e => setRejectReason(e.target.value)} style={{ fontSize: 13 }} />
                </div>
                <button className="btn btn-danger btn-sm" disabled={isVoting} onClick={() => handleVote(tx.id, false, rejectReason)}>{isVoting ? <div className="spinner" style={{ width: 12, height: 12 }} /> : <><X size={13} /> Confirm Reject</>}</button>
                <button className="btn btn-secondary btn-sm" onClick={() => setShowRejectInput(false)}>Cancel</button>
              </div>
            ) : (
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <button className="btn btn-success btn-sm" disabled={isVoting} onClick={() => handleVote(tx.id, true)} style={{ flex: 1, minWidth: 100, justifyContent: 'center' }}>{isVoting ? <div className="spinner" style={{ width: 12, height: 12 }} /> : <><Check size={14} /> Approve</>}</button>
                <button className="btn btn-danger btn-sm" disabled={isVoting} onClick={() => setShowRejectInput(true)} style={{ flex: 1, minWidth: 100, justifyContent: 'center' }}><X size={14} /> Reject</button>
              </div>
            )}
          </div>
        ) : mine ? (
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 600, color: mine.status === 'approved' ? 'var(--accent-emerald)' : 'var(--accent-red)' }}>
            {mine.status === 'approved' ? <Check size={14} /> : <X size={14} />}
            You {mine.status} this withdrawal
            {summary.pending.length > 0 && <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>— waiting for {summary.pending.map(a => a.profiles?.name?.split(' ')[0]).join(', ')}</span>}
          </div>
        ) : null}
      </div>
    )
  }

  const totalPages = Math.ceil(totalCount / PAGE_SIZE)

  return (
    <div>
      <PageHeader
        title="Transactions"
        subtitle={`Account No • 135 146 0749 • ${totalCount} records`}
        onRefresh={fetchData}
        loading={loading}
      >
        <button className="btn btn-primary" onClick={() => setShowAdd(true)}>
          <Plus size={15} /> Add Transaction
        </button>
      </PageHeader>

      {/* Filters */}
      <div className="card mb-4">
        <div
          className="filter-bar"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            flexWrap: "wrap",
          }}
        >
          <Filter
            size={15}
            style={{ color: "var(--text-muted)", flexShrink: 0 }}
          />
          <select
            className="form-select"
            style={{ flex: 1, minWidth: 0 }}
            value={filter.type}
            onChange={(e) => setFilter((p) => ({ ...p, type: e.target.value }))}
          >
            <option value="">All Types</option>
            <option value="deposit">Deposit</option>
            <option value="withdrawal">Withdrawal</option>
            <option value="adjustment">Adjustment</option>
          </select>
          <select
            className="form-select"
            style={{ flex: 1, minWidth: 0 }}
            value={filter.status}
            onChange={(e) =>
              setFilter((p) => ({ ...p, status: e.target.value }))
            }
          >
            <option value="">All Status</option>
            <option value="completed">Completed</option>
            <option value="pending_verification">Awaiting Verification</option>
            <option value="pending">Pending Approval</option>
            <option value="rejected">Rejected</option>
          </select>
          <select
            className="form-select"
            style={{ flex: 1, minWidth: 0 }}
            value={filter.member}
            onChange={(e) =>
              setFilter((p) => ({ ...p, member: e.target.value }))
            }
          >
            <option value="">All Members</option>
            {members.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name?.split(" ")[0]}
              </option>
            ))}
          </select>
          {(filter.type || filter.status || filter.member) && (
            <button
              className="btn btn-secondary btn-sm"
              onClick={() => setFilter({ type: "", status: "", member: "" })}
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Pending verification banner — for whoever can verify */}
      {transactions.some((t) => canVerifyDeposit(t)) && (
        <div
          style={{
            background: "rgba(230,144,10,0.08)",
            border: "1px solid rgba(230,144,10,0.25)",
            borderRadius: 10,
            padding: "12px 16px",
            marginBottom: 16,
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}
        >
          <ShieldCheck
            size={16}
            style={{ color: "var(--accent-amber)", flexShrink: 0 }}
          />
          <span
            style={{
              fontSize: 14,
              fontWeight: 600,
              color: "var(--accent-amber)",
            }}
          >
            {transactions.filter((t) => canVerifyDeposit(t)).length} deposit
            {transactions.filter((t) => canVerifyDeposit(t)).length === 1
              ? ""
              : "s"}{" "}
            awaiting your verification — confirm the funds and add the bank
            reference code
          </span>
        </div>
      )}

      {/* Back-fill banner — shown to anyone eligible to back-fill at
          least one historical deposit (admin OR member-with-admin-deposits
          to verify) */}
      {backfillCount > 0 && (
        <div
          style={{
            background: "rgba(58,77,181,0.06)",
            border: "1px solid rgba(58,77,181,0.22)",
            borderRadius: 10,
            padding: "12px 16px",
            marginBottom: 16,
            display: "flex",
            alignItems: "center",
            gap: 10,
            flexWrap: "wrap",
          }}
        >
          <ShieldCheck
            size={16}
            style={{
              color: "var(--accent-blue, #3a4db5)",
              flexShrink: 0,
            }}
          />
          <span
            style={{
              fontSize: 14,
              fontWeight: 600,
              color: "var(--accent-blue, #3a4db5)",
              flex: 1,
              minWidth: 200,
            }}
          >
            {backfillCount} earlier deposit
            {backfillCount === 1 ? "" : "s"} need
            {backfillCount === 1 ? "s" : ""} a bank verification code
            {!isAdmin ? " — admin deposits are awaiting your verification" : ""}
            {needsBackfillOnly ? " (showing below)" : ""}
          </span>
          <button
            className="btn btn-sm"
            style={{
              fontSize: 12,
              padding: "4px 10px",
              background: needsBackfillOnly
                ? "var(--accent-blue, #3a4db5)"
                : "transparent",
              color: needsBackfillOnly
                ? "#fff"
                : "var(--accent-blue, #3a4db5)",
              border: "1px solid var(--accent-blue, #3a4db5)",
              borderRadius: 6,
              cursor: "pointer",
              fontWeight: 600,
            }}
            onClick={() => setNeedsBackfillOnly((v) => !v)}
          >
            {needsBackfillOnly ? "✓ Showing only these" : "Show only these"}
          </button>
        </div>
      )}

      {/* Pending approvals banner */}
      {transactions.some(
        (t) =>
          t.type === "withdrawal" && t.status === "pending" && canVote(t.id),
      ) && (
        <div
          style={{
            background: "rgba(230,144,10,0.08)",
            border: "1px solid rgba(230,144,10,0.25)",
            borderRadius: 10,
            padding: "12px 16px",
            marginBottom: 16,
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}
        >
          <AlertCircle
            size={16}
            style={{ color: "var(--accent-amber)", flexShrink: 0 }}
          />
          <span
            style={{
              fontSize: 14,
              fontWeight: 600,
              color: "var(--accent-amber)",
            }}
          >
            You have pending withdrawal approvals — click a row to review
          </span>
        </div>
      )}

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        {loading ? (
          <div
            className="flex items-center justify-center"
            style={{ padding: 48 }}
          >
            <div className="spinner" style={{ width: 32, height: 32 }} />
          </div>
        ) : transactions.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">💳</div>
            <p style={{ fontWeight: 600 }}>No transactions found</p>
            <p className="text-sm">
              Adjust filters or record your first transaction
            </p>
          </div>
        ) : (
          <>
            <div
              className="table-container tx-table-view"
              style={{ borderRadius: 0, border: "none" }}
            >
              <table>
                <thead>
                  <tr>
                    <th>Member</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Refs</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th style={{ width: 130 }}>Approvals</th>
                    <th style={{ width: isAdmin ? 110 : 40 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((tx) => {
                    const summary = getApprovalSummary(tx.id);
                    const isWithdrawalPending =
                      tx.type === "withdrawal" && tx.status === "pending";
                    const needsMyVote = canVote(tx.id);
                    const isExpanded = expandedRows[tx.id];
                    const isEditing = editingTx === tx.id;
                    const isDeleting = deletingId === tx.id;
                    const isAwaitingVerification =
                      tx.type === "deposit" && tx.status === "pending_verification";
                    const showVerifyRow = verifyingTx === tx.id;
                    const iCanVerify = canVerifyDeposit(tx);
                    const iCanBackfill = canBackfillDeposit(tx);

                    return (
                      <React.Fragment key={tx.id}>
                        <tr
                          id={`tx-row-${tx.id}`}
                          style={{
                            background:
                              highlightId === tx.id
                                ? "rgba(90,138,30,0.05)"
                                : needsMyVote || iCanVerify
                                  ? "rgba(230,144,10,0.04)"
                                  : undefined,
                            cursor: isWithdrawalPending ? "pointer" : undefined,
                            borderLeft:
                              highlightId === tx.id
                                ? "3px solid var(--olive)"
                                : needsMyVote || iCanVerify
                                  ? "3px solid var(--accent-amber)"
                                  : "3px solid transparent",
                            opacity: isDeleting ? 0.4 : 1,
                          }}
                          onClick={() =>
                            !isEditing &&
                            isWithdrawalPending &&
                            toggleExpand(tx.id)
                          }
                        >
                          <td>
                            <div className="flex items-center gap-2">
                              <MemberAvatar
                                name={tx.profiles?.name}
                                avatarUrl={tx.profiles?.avatar_url}
                                size={30}
                                fontSize={11}
                              />
                              <div>
                                <div style={{ fontSize: 13, fontWeight: 600 }}>
                                  {tx.profiles?.name
                                    ?.split(" ")
                                    .slice(0, 2)
                                    .join(" ")}
                                </div>
                                {tx.description && (
                                  <div
                                    className="text-xs text-muted"
                                    style={{
                                      maxWidth: 160,
                                      overflow: "hidden",
                                      textOverflow: "ellipsis",
                                      whiteSpace: "nowrap",
                                    }}
                                  >
                                    {tx.description}
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td>
                            <span
                              className={`badge badge-${tx.type === "deposit" ? "green" : tx.type === "withdrawal" ? "red" : "amber"}`}
                            >
                              {tx.type === "deposit"
                                ? "↑"
                                : tx.type === "withdrawal"
                                  ? "↓"
                                  : "±"}{" "}
                              {tx.type}
                            </span>
                          </td>
                          <td
                            className="text-mono font-semibold"
                            style={{
                              color:
                                tx.type === "deposit"
                                  ? "var(--accent-emerald)"
                                  : "var(--accent-red)",
                            }}
                          >
                            {tx.type === "deposit" ? "+" : "-"}
                            {formatCurrency(tx.amount)}
                          </td>
                          <td className="text-sm" style={{ minWidth: 130 }}>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 2, fontFamily: 'var(--font-mono)', fontSize: 12 }}>
                              <span style={{ color: 'var(--text-secondary)' }} title="Member's M-Pesa / bank reference">
                                <span style={{ color: 'var(--text-muted)', fontSize: 10, fontFamily: 'inherit', fontWeight: 400 }}>Deposit: </span>
                                {tx.reference || <span style={{ color: 'var(--text-muted)' }}>—</span>}
                              </span>
                              {tx.type === 'deposit' && (
                                <span title="Bank-side verification code added by admin">
                                  <span style={{ color: 'var(--text-muted)', fontSize: 10, fontFamily: 'inherit', fontWeight: 400 }}>Bank: </span>
                                  {tx.bank_verification_code ? (
                                    <span style={{ color: 'var(--accent-emerald)', fontWeight: 600 }}>
                                      ✓ {tx.bank_verification_code}
                                    </span>
                                  ) : (
                                    <span style={{ color: 'var(--text-muted)' }}>—</span>
                                  )}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="text-sm text-muted">
                            {formatDateTime(tx.transaction_date)}
                          </td>
                          <td>
                            <span
                              className={`badge ${getStatusBadge(tx.status)}`}
                              title={tx.status}
                            >
                              {getStatusLabel(tx.status)}
                            </span>
                          </td>
                          <td>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'flex-start' }}>
                              {getApprovalBadges(tx).map((b, i) => (
                                <span
                                  key={i}
                                  className={`badge ${badgeClass(b.kind)}`}
                                  style={{ fontSize: 10, whiteSpace: 'nowrap' }}
                                  title={
                                    tx.bank_verification_code
                                      ? `Bank ref: ${tx.bank_verification_code}` +
                                        (tx.verified_at ? ` (verified ${formatDateTime(tx.verified_at)})` : '')
                                      : undefined
                                  }
                                >
                                  {b.label}
                                </span>
                              ))}
                              {isWithdrawalPending && summary.total > 0 && (
                                <div style={{ display: 'flex', gap: 3, alignItems: 'center', marginTop: 2 }}>
                                  <div style={{ display: 'flex', gap: 3 }}>
                                    {(approvals[tx.id] || []).map((a) => (
                                      <div
                                        key={a.id}
                                        title={`${a.profiles?.name?.split(' ')[0]}: ${a.status}`}
                                        style={{
                                          borderRadius: '50%',
                                          overflow: 'hidden',
                                          border:
                                            a.status === 'approved'
                                              ? '2px solid rgba(13,156,94,0.6)'
                                              : a.status === 'rejected'
                                                ? '2px solid rgba(220,53,69,0.6)'
                                                : '2px solid var(--border)',
                                          opacity: a.status === 'pending' ? 0.45 : 1,
                                        }}
                                      >
                                        <MemberAvatar
                                          name={a.profiles?.name}
                                          avatarUrl={a.profiles?.avatar_url}
                                          size={18}
                                          fontSize={7}
                                        />
                                      </div>
                                    ))}
                                  </div>
                                  <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>
                                    {summary.approved.length}/{summary.total}
                                  </span>
                                </div>
                              )}
                            </div>
                          </td>
                          <td onClick={(e) => e.stopPropagation()}>
                            <div className="row-actions">
                              {isWithdrawalPending && (
                                <button
                                  style={{
                                    background: "none",
                                    border: "none",
                                    cursor: "pointer",
                                    color: "var(--text-muted)",
                                    padding: 4,
                                  }}
                                  onClick={() => toggleExpand(tx.id)}
                                >
                                  {isExpanded ? (
                                    <ChevronUp size={16} />
                                  ) : (
                                    <ChevronDown size={16} />
                                  )}
                                </button>
                              )}
                              {needsMyVote && !isExpanded && (
                                <span
                                  style={{
                                    width: 8,
                                    height: 8,
                                    borderRadius: "50%",
                                    background: "var(--accent-amber)",
                                    display: "inline-block",
                                  }}
                                />
                              )}
                              {iCanVerify && (
                                <button
                                  className="btn btn-primary btn-sm"
                                  onClick={() =>
                                    setVerifyingTx(
                                      showVerifyRow ? null : tx.id,
                                    )
                                  }
                                  title="Verify this deposit"
                                  style={{
                                    fontSize: 11,
                                    padding: "3px 8px",
                                    display: "inline-flex",
                                    alignItems: "center",
                                    gap: 4,
                                  }}
                                >
                                  <ShieldCheck size={11} /> Verify
                                </button>
                              )}
                              {isAwaitingVerification && !iCanVerify && (
                                <span
                                  title="Awaiting verification"
                                  style={{
                                    display: "inline-flex",
                                    alignItems: "center",
                                    gap: 3,
                                    fontSize: 11,
                                    color: "var(--accent-amber)",
                                  }}
                                >
                                  <Clock size={11} />
                                </span>
                              )}
                              {iCanBackfill && (
                                <button
                                  className="btn btn-sm"
                                  onClick={() =>
                                    setVerifyingTx(
                                      showVerifyRow ? null : tx.id,
                                    )
                                  }
                                  title="Add bank verification code to this historical deposit"
                                  style={{
                                    fontSize: 11,
                                    padding: "3px 8px",
                                    display: "inline-flex",
                                    alignItems: "center",
                                    gap: 4,
                                    background: "transparent",
                                    color: "var(--accent-blue, #3a4db5)",
                                    border:
                                      "1px solid var(--accent-blue, #3a4db5)",
                                    borderRadius: 6,
                                    cursor: "pointer",
                                    fontWeight: 600,
                                  }}
                                >
                                  <ShieldCheck size={11} /> Add Code
                                </button>
                              )}
                              {isAdmin && (
                                <>
                                  <button
                                    className="btn-row-edit"
                                    onClick={() =>
                                      isEditing
                                        ? setEditingTx(null)
                                        : startEdit(tx)
                                    }
                                    title="Edit transaction"
                                  >
                                    <Edit2 size={11} />
                                  </button>
                                  <button
                                    className="btn-row-delete"
                                    disabled={isDeleting}
                                    onClick={() =>
                                      handleDelete(
                                        tx.id,
                                        tx.type,
                                        tx.amount,
                                        tx.profiles?.name,
                                      )
                                    }
                                    title="Delete transaction"
                                  >
                                    {isDeleting ? (
                                      <div
                                        className="spinner"
                                        style={{ width: 10, height: 10 }}
                                      />
                                    ) : (
                                      <Trash2 size={11} />
                                    )}
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>

                        {/* Admin inline edit row */}
                        {isAdmin && isEditing && (
                          <tr key={`${tx.id}-edit`}>
                            <td
                              colSpan={8}
                              style={{
                                padding: "8px 16px 14px",
                                background: "rgba(58,77,181,0.03)",
                              }}
                            >
                              <div
                                style={{
                                  display: "grid",
                                  gridTemplateColumns:
                                    "repeat(auto-fit, minmax(140px, 1fr))",
                                  gap: 10,
                                  alignItems: "end",
                                }}
                              >
                                <div>
                                  <p
                                    style={{
                                      fontSize: 11,
                                      color: "var(--text-muted)",
                                      marginBottom: 4,
                                    }}
                                  >
                                    Amount (KES)
                                  </p>
                                  <input
                                    className="form-input"
                                    type="number"
                                    min="0.01"
                                    step="0.01"
                                    value={editForm.amount}
                                    onChange={(e) =>
                                      setEditForm((p) => ({
                                        ...p,
                                        amount: e.target.value,
                                      }))
                                    }
                                    style={{ fontSize: 13 }}
                                  />
                                </div>
                                <div>
                                  <p
                                    style={{
                                      fontSize: 11,
                                      color: "var(--text-muted)",
                                      marginBottom: 4,
                                    }}
                                  >
                                    Type
                                  </p>
                                  <select
                                    className="form-select"
                                    value={editForm.type}
                                    onChange={(e) =>
                                      setEditForm((p) => ({
                                        ...p,
                                        type: e.target.value,
                                      }))
                                    }
                                    style={{ fontSize: 13 }}
                                  >
                                    <option value="deposit">Deposit</option>
                                    <option value="withdrawal">
                                      Withdrawal
                                    </option>
                                    <option value="adjustment">
                                      Adjustment
                                    </option>
                                  </select>
                                </div>
                                <div>
                                  <p
                                    style={{
                                      fontSize: 11,
                                      color: "var(--text-muted)",
                                      marginBottom: 4,
                                    }}
                                  >
                                    Status
                                  </p>
                                  <select
                                    className="form-select"
                                    value={editForm.status}
                                    onChange={(e) =>
                                      setEditForm((p) => ({
                                        ...p,
                                        status: e.target.value,
                                      }))
                                    }
                                    style={{ fontSize: 13 }}
                                  >
                                    <option value="completed">Completed</option>
                                    <option value="pending_verification">Awaiting Verification</option>
                                    <option value="pending">Pending Approval</option>
                                    <option value="rejected">Rejected</option>
                                  </select>
                                </div>
                                <div>
                                  <p
                                    style={{
                                      fontSize: 11,
                                      color: "var(--text-muted)",
                                      marginBottom: 4,
                                    }}
                                  >
                                    Reference
                                  </p>
                                  <input
                                    className="form-input"
                                    value={editForm.reference}
                                    onChange={(e) =>
                                      setEditForm((p) => ({
                                        ...p,
                                        reference: e.target.value,
                                      }))
                                    }
                                    style={{ fontSize: 13 }}
                                  />
                                </div>
                                <div>
                                  <p
                                    style={{
                                      fontSize: 11,
                                      color: "var(--text-muted)",
                                      marginBottom: 4,
                                    }}
                                  >
                                    Description
                                  </p>
                                  <input
                                    className="form-input"
                                    value={editForm.description}
                                    onChange={(e) =>
                                      setEditForm((p) => ({
                                        ...p,
                                        description: e.target.value,
                                      }))
                                    }
                                    style={{ fontSize: 13 }}
                                  />
                                </div>
                                <div style={{ display: "flex", gap: 8 }}>
                                  <button
                                    className="btn btn-primary btn-sm"
                                    disabled={savingEdit}
                                    onClick={saveEdit}
                                    style={{ flex: 1 }}
                                  >
                                    {savingEdit ? (
                                      <div
                                        className="spinner"
                                        style={{ width: 12, height: 12 }}
                                      />
                                    ) : (
                                      <>
                                        <Check size={12} /> Save
                                      </>
                                    )}
                                  </button>
                                  <button
                                    className="btn btn-secondary btn-sm"
                                    onClick={() => setEditingTx(null)}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}

                        {/* Deposit verification / back-fill row */}
                        {(iCanVerify || iCanBackfill) && showVerifyRow && (
                          <tr key={`${tx.id}-verify`}>
                            <td
                              colSpan={8}
                              style={{
                                padding: "10px 16px 14px",
                                background: iCanBackfill
                                  ? "rgba(58,77,181,0.04)"
                                  : "rgba(230,144,10,0.05)",
                                borderLeft: iCanBackfill
                                  ? "3px solid var(--accent-blue, #3a4db5)"
                                  : "3px solid var(--accent-amber)",
                              }}
                            >
                              <div
                                style={{
                                  display: "flex",
                                  flexWrap: "wrap",
                                  gap: 10,
                                  alignItems: "flex-end",
                                }}
                              >
                                <div style={{ flex: "1 1 100%", marginBottom: 4 }}>
                                  <p
                                    style={{
                                      fontSize: 12,
                                      color: "var(--text-secondary)",
                                      margin: 0,
                                    }}
                                  >
                                    Member's reference (typed by depositor):{" "}
                                    <strong style={{ fontFamily: "var(--font-mono)" }}>
                                      {tx.reference || "—"}
                                    </strong>
                                  </p>
                                  <p
                                    style={{
                                      fontSize: 11,
                                      color: "var(--text-muted)",
                                      marginTop: 2,
                                    }}
                                  >
                                    {iCanBackfill
                                      ? "Back-fill: this deposit is already counted in the pool. Adding the bank code does not change equity or balances — it only records the bank-side reference for audit and reconciliation."
                                      : "Confirm the funds in the bank account, then enter the bank-side verification code below."}
                                  </p>
                                </div>
                                <div style={{ flex: "1 1 220px", minWidth: 180 }}>
                                  <p
                                    style={{
                                      fontSize: 11,
                                      color: "var(--text-muted)",
                                      marginBottom: 4,
                                    }}
                                  >
                                    Bank Verification Code
                                  </p>
                                  <input
                                    className="form-input"
                                    placeholder="e.g. BNK-2026-04-871234"
                                    value={verifyCode[tx.id] || ""}
                                    onChange={(e) =>
                                      setVerifyCode((c) => ({
                                        ...c,
                                        [tx.id]: e.target.value,
                                      }))
                                    }
                                    style={{ fontSize: 13 }}
                                    autoFocus
                                  />
                                </div>
                                <div style={{ display: "flex", gap: 8, flexWrap: 'wrap' }}>
                                  <button
                                    className="btn btn-primary btn-sm"
                                    disabled={verifyBusy[tx.id]}
                                    onClick={() =>
                                      iCanBackfill
                                        ? handleBackfillDeposit(tx)
                                        : handleVerifyDeposit(tx)
                                    }
                                    style={{
                                      display: "inline-flex",
                                      alignItems: "center",
                                      gap: 4,
                                    }}
                                  >
                                    {verifyBusy[tx.id] ? (
                                      <div
                                        className="spinner"
                                        style={{ width: 12, height: 12 }}
                                      />
                                    ) : (
                                      <>
                                        <ShieldCheck size={12} />{" "}
                                        {iCanBackfill
                                          ? "Save Bank Code"
                                          : "Confirm Verify"}
                                      </>
                                    )}
                                  </button>
                                  {!iCanBackfill && (
                                    <button
                                      className="btn btn-sm"
                                      onClick={() => {
                                        setVerifyingTx(null);
                                        setRejectingTx(tx.id);
                                      }}
                                      style={{
                                        background: 'transparent',
                                        color: 'var(--accent-red)',
                                        border: '1px solid var(--accent-red)',
                                        borderRadius: 6,
                                        fontWeight: 600,
                                      }}
                                      title="Funds didn't arrive — reject this deposit"
                                    >
                                      Reject…
                                    </button>
                                  )}
                                  <button
                                    className="btn btn-secondary btn-sm"
                                    onClick={() => {
                                      setVerifyingTx(null);
                                      setVerifyCode((c) => ({
                                        ...c,
                                        [tx.id]: "",
                                      }));
                                    }}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}

                        {/* Reject-reason row */}
                        {rejectingTx === tx.id && (
                          <tr key={`${tx.id}-reject`}>
                            <td
                              colSpan={8}
                              style={{
                                padding: '10px 16px 14px',
                                background: 'rgba(220,53,69,0.05)',
                                borderLeft: '3px solid var(--accent-red)',
                              }}
                            >
                              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'flex-end' }}>
                                <div style={{ flex: '1 1 100%', marginBottom: 4 }}>
                                  <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: 0 }}>
                                    Rejecting <strong>{tx.profiles?.name}</strong>'s deposit of{' '}
                                    <strong style={{ fontFamily: 'var(--font-mono)' }}>{formatCurrency(tx.amount)}</strong>.
                                  </p>
                                  <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
                                    Give a clear reason — the depositor will see it. Minimum 5 characters.
                                  </p>
                                </div>
                                <div style={{ flex: '1 1 280px', minWidth: 200 }}>
                                  <input
                                    className="form-input"
                                    placeholder="e.g. Funds did not arrive in the account / Duplicate of TX-1234"
                                    value={rejectReason[tx.id] || ''}
                                    onChange={e => setRejectReason(r => ({ ...r, [tx.id]: e.target.value }))}
                                    style={{ fontSize: 13 }}
                                    autoFocus
                                  />
                                </div>
                                <div style={{ display: 'flex', gap: 8 }}>
                                  <button
                                    className="btn btn-sm"
                                    disabled={rejectBusy[tx.id]}
                                    onClick={() => handleRejectDeposit(tx)}
                                    style={{
                                      background: 'var(--accent-red)',
                                      color: '#fff',
                                      border: 'none',
                                      borderRadius: 6,
                                      fontWeight: 600,
                                      padding: '6px 12px',
                                    }}
                                  >
                                    {rejectBusy[tx.id] ? (
                                      <div className="spinner" style={{ width: 12, height: 12 }} />
                                    ) : 'Confirm Reject'}
                                  </button>
                                  <button
                                    className="btn btn-secondary btn-sm"
                                    onClick={() => {
                                      setRejectingTx(null)
                                      setRejectReason(r => ({ ...r, [tx.id]: '' }))
                                    }}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}

                        {/* Approval panel */}
                        {isWithdrawalPending && isExpanded && (
                          <tr key={`${tx.id}-panel`}>
                            <td colSpan={8} style={{ padding: "0 16px 14px" }}>
                              <ApprovalPanel tx={tx} />
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile card list */}
            <div>
              {transactions.map((tx) => {
                const summary = getApprovalSummary(tx.id);
                const isWithdrawalPending =
                  tx.type === "withdrawal" && tx.status === "pending";
                const needsMyVote = canVote(tx.id);
                const isExpanded = expandedRows[tx.id];
                const isAwaitingVerification =
                  tx.type === "deposit" && tx.status === "pending_verification";
                const showVerifyRow = verifyingTx === tx.id;
                const iCanVerify = canVerifyDeposit(tx);
                const iCanBackfill = canBackfillDeposit(tx);
                return (
                  <div
                    key={`mob-${tx.id}`}
                    className="mobile-tx-card"
                    style={{
                      background:
                        highlightId === tx.id
                          ? "rgba(90,138,30,0.04)"
                          : needsMyVote || iCanVerify
                            ? "rgba(230,144,10,0.03)"
                            : undefined,
                      borderLeft:
                        highlightId === tx.id
                          ? "3px solid var(--olive)"
                          : needsMyVote || iCanVerify
                            ? "3px solid var(--accent-amber)"
                            : "3px solid transparent",
                      cursor: isWithdrawalPending ? "pointer" : "default",
                    }}
                    onClick={() => isWithdrawalPending && toggleExpand(tx.id)}
                  >
                    <div className="mobile-tx-card-row">
                      <div className="mobile-tx-card-member">
                        <MemberAvatar
                          name={tx.profiles?.name}
                          avatarUrl={tx.profiles?.avatar_url}
                          size={38}
                          fontSize={13}
                        />
                        <div className="mobile-tx-card-info">
                          <div className="mobile-tx-card-name">
                            {tx.profiles?.name
                              ?.split(" ")
                              .slice(0, 2)
                              .join(" ")}
                          </div>
                          {/* Refs stacked on two lines so neither gets ellipsized
                              by the narrow card width. Falls back to description
                              when there's no reference at all. */}
                          {tx.type === 'deposit' && (tx.reference || tx.bank_verification_code) ? (
                            <div className="mobile-tx-card-refs">
                              {tx.reference && (
                                <div className="mobile-tx-card-ref-line" title={tx.reference}>
                                  <span className="mobile-tx-card-ref-label">Dep:</span>{' '}
                                  <span className="mobile-tx-card-ref-value">{tx.reference}</span>
                                </div>
                              )}
                              {tx.bank_verification_code && (
                                <div
                                  className="mobile-tx-card-ref-line mobile-tx-card-ref-bank"
                                  title={`Bank verification code: ${tx.bank_verification_code}`}
                                >
                                  <span className="mobile-tx-card-ref-label">Bank:</span>{' '}
                                  <span className="mobile-tx-card-ref-value">
                                    ✓ {tx.bank_verification_code}
                                  </span>
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="mobile-tx-card-sub">
                              {tx.reference || tx.description || "—"}
                            </div>
                          )}
                        </div>
                      </div>
                      <span
                        className="mobile-tx-card-amount"
                        style={{
                          color:
                            tx.type === "deposit"
                              ? "var(--accent-emerald)"
                              : "var(--accent-red)",
                        }}
                      >
                        {tx.type === "deposit" ? "+" : "-"}
                        {formatCurrency(tx.amount)}
                      </span>
                    </div>
                    <div className="mobile-tx-card-meta">
                      <span
                        className={`badge badge-${tx.type === "deposit" ? "green" : tx.type === "withdrawal" ? "red" : "amber"}`}
                        style={{ fontSize: 10 }}
                      >
                        {tx.type}
                      </span>
                      <span
                        className={`badge ${getStatusBadge(tx.status)}`}
                        style={{ fontSize: 10 }}
                        title={tx.status}
                      >
                        {getStatusLabel(tx.status)}
                      </span>
                      {getApprovalBadges(tx).map((b, i) => (
                        <span
                          key={`appr-${i}`}
                          className={`badge ${badgeClass(b.kind)}`}
                          style={{ fontSize: 10, whiteSpace: 'nowrap' }}
                          title={
                            tx.bank_verification_code
                              ? `Bank ref: ${tx.bank_verification_code}`
                              : undefined
                          }
                        >
                          {b.label}
                        </span>
                      ))}
                      <span
                        style={{
                          fontSize: 11,
                          color: "var(--text-muted)",
                          marginLeft: "auto",
                        }}
                      >
                        {formatDateTime(tx.transaction_date)}
                      </span>
                      {isWithdrawalPending && (
                        <span
                          style={{ fontSize: 11, color: "var(--text-muted)" }}
                        >
                          {summary.approved.length}/{summary.total}{" "}
                          {isExpanded ? (
                            <ChevronUp size={13} />
                          ) : (
                            <ChevronDown size={13} />
                          )}
                        </span>
                      )}
                    </div>
                    {/* Admin actions on mobile */}
                    {isAdmin && (
                      <div
                        style={{ display: "flex", gap: 6, marginTop: 8 }}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          className="btn-row-edit"
                          style={{ flex: 1 }}
                          onClick={() => {
                            startEdit(tx);
                            toggleExpand(tx.id);
                          }}
                        >
                          <Edit2 size={11} /> Edit
                        </button>
                        <button
                          className="btn-row-delete"
                          style={{ flex: 1 }}
                          onClick={() =>
                            handleDelete(
                              tx.id,
                              tx.type,
                              tx.amount,
                              tx.profiles?.name,
                            )
                          }
                        >
                          <Trash2 size={11} /> Delete
                        </button>
                      </div>
                    )}

                    {/* Mobile verify / back-fill button + inline panel */}
                    {(iCanVerify || iCanBackfill) && (
                      <div
                        style={{ marginTop: 8 }}
                        onClick={(e) => e.stopPropagation()}
                      >
                        {!showVerifyRow ? (
                          <button
                            className="btn btn-sm"
                            style={{
                              width: "100%",
                              display: "inline-flex",
                              alignItems: "center",
                              justifyContent: "center",
                              gap: 6,
                              background: iCanBackfill
                                ? "transparent"
                                : "var(--olive)",
                              color: iCanBackfill
                                ? "var(--accent-blue, #3a4db5)"
                                : "#fff",
                              border: iCanBackfill
                                ? "1px solid var(--accent-blue, #3a4db5)"
                                : "none",
                              borderRadius: 6,
                              fontWeight: 600,
                              padding: "6px 10px",
                            }}
                            onClick={() => setVerifyingTx(tx.id)}
                          >
                            <ShieldCheck size={13} />{" "}
                            {iCanBackfill ? "Add Bank Code" : "Verify Deposit"}
                          </button>
                        ) : (
                          <div
                            style={{
                              background: iCanBackfill
                                ? "rgba(58,77,181,0.05)"
                                : "rgba(230,144,10,0.06)",
                              border: iCanBackfill
                                ? "1px solid rgba(58,77,181,0.22)"
                                : "1px solid rgba(230,144,10,0.22)",
                              borderRadius: 8,
                              padding: 10,
                            }}
                          >
                            <p
                              style={{
                                fontSize: 12,
                                color: "var(--text-secondary)",
                                marginBottom: 6,
                              }}
                            >
                              Member's ref:{" "}
                              <strong style={{ fontFamily: "var(--font-mono)" }}>
                                {tx.reference || "—"}
                              </strong>
                            </p>
                            {iCanBackfill && (
                              <p
                                style={{
                                  fontSize: 11,
                                  color: "var(--text-muted)",
                                  marginBottom: 8,
                                }}
                              >
                                Back-fill: this deposit is already counted.
                                Adding the code is record-keeping only.
                              </p>
                            )}
                            <input
                              className="form-input"
                              placeholder="Bank verification code"
                              value={verifyCode[tx.id] || ""}
                              onChange={(e) =>
                                setVerifyCode((c) => ({
                                  ...c,
                                  [tx.id]: e.target.value,
                                }))
                              }
                              style={{ fontSize: 13, marginBottom: 8 }}
                              autoFocus
                            />
                            <div style={{ display: "flex", gap: 6 }}>
                              <button
                                className="btn btn-primary btn-sm"
                                disabled={verifyBusy[tx.id]}
                                style={{ flex: 1 }}
                                onClick={() =>
                                  iCanBackfill
                                    ? handleBackfillDeposit(tx)
                                    : handleVerifyDeposit(tx)
                                }
                              >
                                {verifyBusy[tx.id] ? (
                                  <div
                                    className="spinner"
                                    style={{ width: 12, height: 12 }}
                                  />
                                ) : (
                                  <>
                                    <ShieldCheck size={12} />{" "}
                                    {iCanBackfill ? "Save" : "Confirm"}
                                  </>
                                )}
                              </button>
                              <button
                                className="btn btn-secondary btn-sm"
                                style={{ flex: 1 }}
                                onClick={() => {
                                  setVerifyingTx(null);
                                  setVerifyCode((c) => ({
                                    ...c,
                                    [tx.id]: "",
                                  }));
                                }}
                              >
                                Cancel
                              </button>
                            </div>
                            {!iCanBackfill && (
                              <button
                                className="btn btn-sm"
                                style={{
                                  marginTop: 8,
                                  width: '100%',
                                  background: 'transparent',
                                  color: 'var(--accent-red)',
                                  border: '1px solid var(--accent-red)',
                                  borderRadius: 6,
                                  fontWeight: 600,
                                  padding: '6px',
                                }}
                                onClick={() => {
                                  setVerifyingTx(null);
                                  setRejectingTx(tx.id);
                                }}
                              >
                                Reject this deposit…
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Mobile reject panel */}
                    {rejectingTx === tx.id && (
                      <div
                        style={{ marginTop: 8 }}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div
                          style={{
                            background: 'rgba(220,53,69,0.06)',
                            border: '1px solid rgba(220,53,69,0.22)',
                            borderRadius: 8,
                            padding: 10,
                          }}
                        >
                          <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 6 }}>
                            Reject <strong>{tx.profiles?.name?.split(' ')[0]}</strong>'s deposit of{' '}
                            <strong style={{ fontFamily: 'var(--font-mono)' }}>{formatCurrency(tx.amount)}</strong>?
                          </p>
                          <input
                            className="form-input"
                            placeholder="Reason (min 5 chars)"
                            value={rejectReason[tx.id] || ''}
                            onChange={e => setRejectReason(r => ({ ...r, [tx.id]: e.target.value }))}
                            style={{ fontSize: 13, marginBottom: 8 }}
                            autoFocus
                          />
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button
                              className="btn btn-sm"
                              disabled={rejectBusy[tx.id]}
                              style={{
                                flex: 1,
                                background: 'var(--accent-red)',
                                color: '#fff',
                                border: 'none',
                                borderRadius: 6,
                                fontWeight: 600,
                              }}
                              onClick={() => handleRejectDeposit(tx)}
                            >
                              {rejectBusy[tx.id] ? (
                                <div className="spinner" style={{ width: 12, height: 12 }} />
                              ) : 'Reject'}
                            </button>
                            <button
                              className="btn btn-secondary btn-sm"
                              style={{ flex: 1 }}
                              onClick={() => {
                                setRejectingTx(null)
                                setRejectReason(r => ({ ...r, [tx.id]: '' }))
                              }}
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* "Awaiting verification" notice when current user is not the verifier */}
                    {isAwaitingVerification && !iCanVerify && (
                      <div
                        style={{
                          marginTop: 8,
                          padding: "6px 10px",
                          background: "rgba(230,144,10,0.06)",
                          border: "1px solid rgba(230,144,10,0.18)",
                          borderRadius: 6,
                          fontSize: 11,
                          color: "var(--accent-amber)",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 5,
                        }}
                      >
                        <Clock size={11} />
                        {tx.user_id === profile?.id
                          ? "Awaiting admin verification"
                          : "Awaiting verification"}
                      </div>
                    )}

                    {isWithdrawalPending && isExpanded && (
                      <div
                        className="mobile-approval-panel"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <ApprovalPanel tx={tx} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <Pagination
              page={page}
              totalPages={totalPages}
              totalItems={totalCount}
              pageSize={PAGE_SIZE}
              onChange={setPage}
            />
          </>
        )}
      </div>

      {showAdd && (
        <AddTransactionModal
          onClose={() => setShowAdd(false)}
          onSuccess={fetchData}
        />
      )}
    </div>
  );
}
